# ARCANE LANGUAGE AUDIT — PHASE 6
## Parser scaffold and structural regression tests

**Status:** Prototype validated against the provisional Phase 2 audit notation only. Not a parser for spoken Arcane; not a certification of the complete grammar.

## Continuity correction
The recovered `Arcana pack.zip` already contains Phase 4 and Phase 5. Phase 4 explicitly retains v2.0's productive Construction morphology (Feet: frame + parameter vowel + relation coda), alongside the v3.0-L Expression subsystem. Therefore the next step is not to reconstruct morphology from scratch. It is to validate the existing two-subsystem bridge and build the missing parser/corpus tests.

## Scope
The prototype parses expressions written in the Phase 2 diagnostic notation:

`OPERATOR⟨argument₁, argument₂, …⟩`

Angle brackets and commas are audit notation, not spoken Arcane vocabulary. The parser builds nested trees, preserves argument order, rejects malformed grouping, and checks arity for the subset of operators whose provisional signatures are recorded in the script.

## Results
10/10 prototype regression tests passed:

- binary expression parsing;
- nested tree preservation;
- operand-order preservation;
- rejection of a missing argument;
- rejection of an unclosed expression;
- rejection of trailing tokens;
- fixed-arity checking;
- recursive arity checking;
- separation of syntax parsing from operator-signature validation;
- rejection of empty argument lists for known fixed-arity operators.

These are implementation-level passes for the prototype only. They do **not** establish type correctness, physical feasibility, spoken-surface uniqueness, or full-language completeness.

## What remains unimplemented
1. A complete and canonical signature registry for all formal operators.
2. A dimensional type system and unit-conversion rules.
3. Typed references, bindings, observation values, conditions and control blocks.
4. Canonical syntax for blocks using METO (BEGIN) and DOGU (END), including the Performed Arcana pitch-reset/lengthening mapping.
5. The modifier attachment rule from Phase 4 G-4, tested on nested expressions.
6. Compile-bridge validation from Formal expressions to Construction Feet, couplings, references, quantities and control.
7. A parser for the Vernacular register and grammar tests for all 25 Phase 5 examples.
8. Listener tests for near-collisions and prosodic distinctions. These cannot be replaced by a feature-distance heuristic.
9. End-to-end spell checks separating syntactic validity, typed semantic validity and physical feasibility.

## Important boundary
A parsed expression is not automatically a valid spell. The validation pipeline must remain:

`parse → type-check → resolve references/bindings → compile construction → feasibility-check → execute → observe/feedback`

Failure at a later stage must not be hidden by success at an earlier stage.

## Recommended next task
Phase 6B should define the operator signature registry and typed AST, starting with arithmetic and information operators. Then add dimensional checking, explicit error categories, and regression tests. Only after the Expression subsystem is stable should the compiler bridge be tested against the Phase 4 hand-flame example and other construction examples.
