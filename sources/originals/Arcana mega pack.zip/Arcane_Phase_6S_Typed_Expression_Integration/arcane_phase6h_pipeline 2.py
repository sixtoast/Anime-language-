#!/usr/bin/env python3
"""Arcane Phase 6H: narrow end-to-end parse/check/evaluate prototype.
Not a complete language implementation or a magic/construction executor.
"""
from dataclasses import dataclass
from decimal import Decimal
from pathlib import Path
import csv, sys
ROOT=Path(__file__).resolve().parent
LEXICON=ROOT/'Arcane_Lexicon_v5_draft.csv'
class ArcaneError(ValueError): pass
class ParseError(ArcaneError): pass
class TypeCheckError(ArcaneError): pass
class RuntimeArcaneError(ArcaneError): pass
@dataclass(frozen=True)
class Num: value: Decimal; unit: str
@dataclass(frozen=True)
class Word: form: str
@dataclass(frozen=True)
class Call: op: str; args: tuple
@dataclass(frozen=True)
class Block: expressions: tuple
DIGITS={'za':'0','ki':'1','to':'2','mu':'3','re':'4','sa':'5','fi':'6','du':'7','go':'8','pe':'9'}
UNITS={'ma','se','ke','ra','ku','sho','vo'}
ARITY={'frapa':2,'fraja':2,'frama':2,'frala':2,'frasha':1,'gran':2,'grat':2,'grash':1,'bek':2,'zet':2,'kole':2,'kwam':2,'kwat':1,'kwash':1}
ALIASES={'frata':'fraja','fraka':'frama','drim':'drum','dral':'dras','grak':'grash','kwak':'kwash'}
CONTROL={'bek','zet','kole'}
def forms():
 if not LEXICON.exists(): raise FileNotFoundError(LEXICON)
 with LEXICON.open(encoding='utf-8',newline='') as f: return {r['form'].strip().lower() for r in csv.DictReader(f) if r.get('form','').strip()}
FORMS=forms()
def parse(src):
 ts=[ALIASES.get(x.lower(),x.lower()) for x in src.split()]
 if not ts: raise ParseError('Empty input')
 i=0
 def peek(): return ts[i] if i<len(ts) else None
 def take():
  nonlocal i
  if peek() is None: raise ParseError('Unexpected end of input')
  x=ts[i]; i+=1; return x
 def number():
  ds=[]
  while peek() in DIGITS: ds.append(DIGITS[take()])
  if not ds: raise ParseError('Expected numeral digit')
  frac=None
  if peek()=='shi':
   take(); fs=[]
   while peek() in DIGITS: fs.append(DIGITS[take()])
   if not fs: raise ParseError('SHI must be followed by fractional digits')
   frac=''.join(fs)
  unit=peek()
  if unit not in UNITS: raise ParseError('Every numeral must terminate in a unit; use SHO for dimensionless values')
  take(); return Num(Decimal(''.join(ds)+(('.'+frac) if frac is not None else '')),unit)
 def identifier():
  ds=[]
  while peek() in DIGITS: ds.append(DIGITS[take()])
  if not ds or peek()!='sho': raise ParseError('Binding identifiers must be numerals closed by SHO')
  take(); return 'ID_'+''.join(ds)
 def expr():
  t=peek()
  if t is None: raise ParseError('Expected expression')
  if t in DIGITS: return number()
  if t in ('meto','dogu'): raise ParseError(f'{t.upper()} only valid as a control-block delimiter')
  if t in ARITY:
   op=take()
   if op=='kwam': return Call(op,(identifier(),expr()))
   if op=='kwat': return Call(op,(identifier(),))
   if op in CONTROL:
    cond=expr()
    if peek()!='meto': raise ParseError(f'{op.upper()} requires METO before its block')
    take(); body=[]
    while peek()!='dogu':
     if peek() is None: raise ParseError(f'{op.upper()} block missing DOGU')
     body.append(expr())
    take(); return Call(op,(cond,Block(tuple(body))))
   return Call(op,tuple(expr() for _ in range(ARITY[op])))
  w=take()
  if w in {'bool_true','bool_false','bool_a'}: return Word(w)  # test-harness fixtures, not canon-locked vocabulary
  if w not in FORMS: raise ParseError(f'Unknown lexical form {w!r}')
  if w in {'re','ra'}: raise ParseError(f'Ambiguous homophone {w.upper()}; fail-closed in Phase 6H')
  return Word(w)
 node=expr()
 if peek() is not None: raise ParseError('Trailing tokens after complete expression')
 return node
@dataclass(frozen=True)
class Type: kind:str; unit:str=''
def check(n,env=None):
 env={} if env is None else env
 if isinstance(n,Num): return Type('Number',n.unit)
 if isinstance(n,Word):
  if n.form in {'bool_true','bool_false','bool_a'}: return Type('Boolean')
  raise TypeCheckError(f'Unbound or semantically unresolved atom {n.form.upper()}')
 if isinstance(n,Block):
  local=dict(env); result=Type('Unit')
  for x in n.expressions: result=check(x,local)
  return result
 op,args=n.op,n.args
 if op=='kwam':
  name,val=args; typ=check(val,env); env[name]=typ; return typ
 if op=='kwat':
  if args[0] not in env: raise TypeCheckError(f'Unbound identifier {args[0]}')
  return env[args[0]]
 if op=='kwash': return check(args[0],env)
 if op in CONTROL:
  typ=check(args[0],env)
  if typ.kind!='Boolean': raise TypeCheckError(f'{op.upper()} condition must be Boolean')
  local=dict(env)
  for x in args[1].expressions: check(x,local)
  return Type('Unit')
 ts=[check(x,env) for x in args]
 if op in {'frapa','fraja'}:
  if any(t.kind!='Number' for t in ts): raise TypeCheckError(f'{op.upper()} requires numeric operands')
  if ts[0].unit!=ts[1].unit: raise TypeCheckError(f'{op.upper()} requires matching units, got {ts[0].unit} and {ts[1].unit}')
  return ts[0]
 if op=='frama':
  if any(t.kind!='Number' for t in ts): raise TypeCheckError('FRAMA requires numeric operands')
  if ts[0].unit!='sho' and ts[1].unit!='sho': raise TypeCheckError('FRAMA dimensional multiplication is not enabled in this subset')
  return ts[1] if ts[0].unit=='sho' else ts[0]
 if op=='frala':
  if any(t.kind!='Number' for t in ts): raise TypeCheckError('FRALA requires numeric operands')
  if ts[1].unit!='sho': raise TypeCheckError('FRALA divisor must be dimensionless in this subset')
  return ts[0]
 if op=='frasha':
  if ts[0].kind!='Number': raise TypeCheckError('FRASHA requires numeric operand')
  return ts[0]
 if op in {'gran','grat'}:
  if any(t.kind!='Boolean' for t in ts): raise TypeCheckError(f'{op.upper()} requires Boolean operands')
  return Type('Boolean')
 if op=='grash':
  if ts[0].kind!='Boolean': raise TypeCheckError('GRASH requires Boolean operand')
  return Type('Boolean')
 raise TypeCheckError(f'No checker signature enabled for {op.upper()}')
def evaluate(n,env=None,budget=1000):
 env={} if env is None else env; steps=[0]
 def ev(x):
  steps[0]+=1
  if steps[0]>budget: raise RuntimeArcaneError('Evaluation step budget exceeded')
  if isinstance(x,Num): return (x.value,x.unit)
  if isinstance(x,Word):
   if x.form in {'bool_true','bool_a'}: return (True,'bool')
   if x.form=='bool_false': return (False,'bool')
   raise RuntimeArcaneError(f'Unbound or unresolved atom {x.form.upper()}')
  if isinstance(x,Block):
   out=None
   for e in x.expressions: out=ev(e)
   return out
  op,args=x.op,x.args
  if op=='kwam': env[args[0]]=ev(args[1]); return env[args[0]]
  if op=='kwat':
   if args[0] not in env: raise RuntimeArcaneError(f'Unbound identifier {args[0]}')
   return env[args[0]]
  if op=='kwash': return ev(args[0])
  if op=='bek':
   c=ev(args[0])[0]
   if not isinstance(c,bool): raise RuntimeArcaneError('BEK condition must be Boolean')
   return ev(args[1]) if c else None
  if op in {'zet','kole'}:
   out=None
   while True:
    c=ev(args[0])[0]
    if not isinstance(c,bool): raise RuntimeArcaneError(f'{op.upper()} condition must be Boolean')
    if (op=='zet' and not c) or (op=='kole' and c): return out
    out=ev(args[1])
  vals=[ev(a) for a in args]
  if op=='frapa': return (vals[0][0]+vals[1][0],vals[0][1])
  if op=='fraja': return (vals[0][0]-vals[1][0],vals[0][1])
  if op=='frama': return (vals[0][0]*vals[1][0],vals[1][1] if vals[0][1]=='sho' else vals[0][1])
  if op=='frala':
   if vals[1][0]==0: raise RuntimeArcaneError('Division by zero')
   return (vals[0][0]/vals[1][0],vals[0][1])
  if op=='frasha': return (abs(vals[0][0]),vals[0][1])
  if op=='gran': return (vals[0][0] and vals[1][0],'bool')
  if op=='grat': return (vals[0][0] or vals[1][0],'bool')
  if op=='grash': return (not vals[0][0],'bool')
  raise RuntimeArcaneError(f'No evaluator signature enabled for {op.upper()}')
 return ev(n)
def tests():
 out=[]
 def test(name,fn):
  try: ok,detail=fn(); out.append((name,bool(ok),str(detail)))
  except Exception as e: out.append((name,False,f'{type(e).__name__}: {e}'))
 def success(src,expected):
  tree=parse(src); typ=check(tree); val=evaluate(tree); return val==expected, f'{typ}; value={val}'
 def fails(src,stage,msg):
  try:
   n=parse(src)
   if stage=='type': check(n)
   elif stage=='runtime': check(n); evaluate(n)
   else: return False,'Expected failure but succeeded'
  except Exception as e: return msg.lower() in str(e).lower(),f'{type(e).__name__}: {e}'
  return False,'Expected failure but succeeded'
 test('end-to-end addition',lambda:success('frapa ki sho to sho',(Decimal(3),'sho')))
 test('nested arithmetic',lambda:success('frapa frama ki sho to sho fraja mu sho za sho',(Decimal(5),'sho')))
 test('legacy alias',lambda:success('frata mu sho za sho',(Decimal(3),'sho')))
 test('unit mismatch caught by checker',lambda:fails('frapa ki ma to se','type','matching units'))
 test('unterminated numeral rejected by parser',lambda:fails('frapa ki to','parse','terminate in a unit'))
 test('missing METO rejected by parser',lambda:fails('bek bool_a frapa ki sho to sho dogu','parse','requires meto'))
 test('missing DOGU rejected by parser',lambda:fails('bek bool_a meto frapa ki sho to sho','parse','missing dogu'))
 test('unbound binding rejected by checker',lambda:fails('kwat ki sho','type','unbound identifier'))
 test('stored binding roundtrip',lambda:success('kwam ki sho frapa ki sho to sho',(Decimal(3),'sho')))
 test('Boolean NOT',lambda:success('grash bool_false',(True,'bool')))
 test('Boolean AND',lambda:success('gran bool_true bool_true',(True,'bool')))
 test('Boolean OR',lambda:success('grat bool_false bool_true',(True,'bool')))
 test('division by zero caught at runtime',lambda:fails('frala ki sho za sho','runtime','division by zero'))
 test('unknown lexical form rejected',lambda:fails('notarealword','parse','unknown lexical form'))
 test('trailing expression rejected',lambda:fails('ki sho to sho','parse','trailing tokens'))
 return out
if __name__=='__main__':
 results=tests()
 for i,(name,ok,detail) in enumerate(results,1): print(f'{i:02d}. {"PASS" if ok else "FAIL"} — {name}: {detail}')
 print(f'RESULT: {sum(x[1] for x in results)}/{len(results)} passed')
 sys.exit(0 if all(x[1] for x in results) else 1)
