"""Compatibility reconstruction of Arcane Phase 4 lexicon tools.

Reconstructed from the archived PDF printout and Phase 4 documentation. This is
not the missing original module; differences should be reviewed before canon use.
"""
STOPS, NASALS, FRICS, LIQS, GLIDES = set('pbtdkg'), set('mnŋ'), set('fvzshʃ'), set('lr'), set('wj')
CONSONANTS = STOPS | NASALS | FRICS | LIQS | GLIDES
VOWELS = set('aeiouə')
CODAS = set('mnŋptksʃlr')
NO_ONSET = {'ŋ'}
ONSET_CLUSTERS = set('pr br tr dr kr gr kw gw tw fr fl ʃr pl bl kl gl'.split())
FRAMES = set('ptkbdgfsʃhmnŋlrwj')
PLACE = {**{c:'lab' for c in 'pbmfvw'}, **{c:'alv' for c in 'tdnszlr'}, **{c:'pal' for c in 'ʃj'}, **{c:'vel' for c in 'kgŋ'}, 'h':'glo'}
MANNER = {**{c:'stop' for c in STOPS}, **{c:'nasal' for c in NASALS}, **{c:'fric' for c in FRICS}, **{c:'liq' for c in LIQS}, **{c:'glide' for c in GLIDES}}
VOICELESS = set('ptkfsʃh')
HEIGHT = {'i':2,'u':2,'e':1,'o':1,'ə':1,'a':0}
BACK = {'i':0,'e':0,'ə':1,'a':1,'o':2,'u':2}

def ph(word):
    return list(word.lower().replace('sh','ʃ').replace('ng','ŋ'))

def syllabify(word):
    p=ph(word); errs=[]; nuclei=[i for i,c in enumerate(p) if c in VOWELS]
    if not nuclei: return [], ['no vowel']
    for c in p:
        if c not in CONSONANTS and c not in VOWELS: errs.append(f'unknown phoneme {c!r}')
    sylls=[]; prev_end=0
    for k,n in enumerate(nuclei):
        seg=p[prev_end:n]
        if k==0: onset,coda_prev=seg,[]
        else:
            if n-nuclei[k-1]==1: errs.append('adjacent vowels not allowed in lexicon')
            onset=[]; coda_prev=[]
            for cut in range(len(seg)+1):
                cand=seg[cut:]
                if not cand or (len(cand)==1 and cand[0] not in NO_ONSET) or ''.join(cand) in ONSET_CLUSTERS:
                    onset,coda_prev=cand,seg[:cut]; break
            if len(coda_prev)>1: errs.append(f'coda cluster {"".join(coda_prev)!r}')
            sylls[-1][2]=coda_prev
        if len(onset)==1 and onset[0] in NO_ONSET: errs.append('ŋ in onset')
        if len(onset)>1 and ''.join(onset) not in ONSET_CLUSTERS: errs.append(f'illegal onset {"".join(onset)!r}')
        sylls.append([onset,p[n],[]]); prev_end=n+1
    tail=p[prev_end:]
    if len(tail)>1: errs.append(f'coda cluster {"".join(tail)!r}')
    sylls[-1][2]=tail
    for _,_,co in sylls:
        for c in co:
            if c not in CODAS: errs.append(f'illegal coda {c!r}')
    return sylls,errs

def csub(a,b):
    if a==b:return 0.0
    if a in VOWELS and b in VOWELS:return .75*abs(HEIGHT[a]-HEIGHT[b])+.75*abs(BACK[a]-BACK[b])
    if (a in VOWELS)!=(b in VOWELS):return 3.5
    if {a,b}=={'l','r'}:return 1.0
    return (1.0 if PLACE.get(a)!=PLACE.get(b) else 0.0)+(1.5 if MANNER.get(a)!=MANNER.get(b) else 0.0)+(1.0 if (a in VOICELESS)!=(b in VOICELESS) else 0.0)

def dist(w1,w2,indel=1.5):
    a,b=ph(w1),ph(w2); D=[[0.0]*(len(b)+1) for _ in range(len(a)+1)]
    for i in range(1,len(a)+1):D[i][0]=i*indel
    for j in range(1,len(b)+1):D[0][j]=j*indel
    for i in range(1,len(a)+1):
        for j in range(1,len(b)+1):D[i][j]=min(D[i-1][j]+indel,D[i][j-1]+indel,D[i-1][j-1]+csub(a[i-1],b[j-1]))
    return D[-1][-1]
