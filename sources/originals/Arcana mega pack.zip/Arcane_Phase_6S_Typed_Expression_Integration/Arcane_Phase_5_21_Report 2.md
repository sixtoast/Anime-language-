# Arcane Phase 5.21 — Evidence-Bounded Construction Conformance Fixtures

**Status:** fixture validation executed. **Canon changed:** no. **General parser:** not implemented.

## 1. Result

The validator completed **11 PASS, 0 FAIL, 3 BLOCKED** checks. These results apply only to the narrowly defined fixtures below. They do not establish that Performed Arcana as a whole has a unique parse.

| Result | Count | Interpretation |
|---|---:|---|
| PASS | 11 | The four lexical records match their expected source-backed readings; four explicit-slot lookups resolve; two no-slot checks preserve ambiguity; the documented hand-flame transcription matches its token sequence. |
| FAIL | 0 | No assertion inside this limited fixture suite failed. |
| BLOCKED | 3 | Tests requiring a complete construction grammar or universal register rule cannot responsibly be decided from current evidence. |

## 2. Tests run

| Test | Status | What was actually tested |
|---|---|---|
| P521-LEX-re-DIGIT | PASS | Lexicon contains `re` / DIGIT / `4`. |
| P521-LEX-ra-UNIT | PASS | Lexicon contains `ra` / UNIT / `radian`. |
| P521-LEX-re-FUSED-REF | PASS | Lexicon contains `re` / FUSED-REF / `TARGET-surface`. |
| P521-LEX-ra-FUSED-REF | PASS | Lexicon contains `ra` / FUSED-REF / `TARGET-path`. |
| P521-SLOT-01 | PASS | Given the DIGIT slot, `re` resolves to `4`. |
| P521-SLOT-02 | PASS | Given the FUSED-REF slot, `re` resolves to `TARGET-surface`. |
| P521-SLOT-03 | PASS | Given the UNIT slot, `ra` resolves to `radian`. |
| P521-SLOT-04 | PASS | Given the FUSED-REF slot, `ra` resolves to `TARGET-path`. |
| P521-AMB-01 | PASS | Without a slot, the lookup exposes multiple readings for `re`; it does not guess. |
| P521-AMB-02 | PASS | Without a slot, the lookup exposes multiple readings for `ra`; it does not guess. |
| P521-HF-01 | PASS | Token sequence matches the Phase 4 hand-flame transcription. This is a transcription check, not a grammar parse. |
| P521-GRAMMAR-01 | BLOCKED | Full spoken construction parser is absent; Phase 4 explicitly says no whole-spell grammar-level parse was run. |
| P521-WRONG-SLOT-01 | BLOCKED | Complete productive construction grammar and all relevant argument signatures are not established here, so universal wrong-slot rejection cannot be asserted. |
| P521-MIXED-REGISTER-01 | BLOCKED | Shared numerals/units occur in the documented Performed hand-flame example. A blanket Shared/Performed prohibition would contradict that evidence. |

## 3. Canonical hand-flame transcription used

`mel · po da za shi to za ma · kan ken · he ha · sa shi za se · kas`

Phase 4's accompanying interpretation identifies, broadly: an anchored surface reference; position and a 0.20 m value; `kan` and `ken` construction Feet; `he` and `ha` couplings; a 5.0 s duration; and `kas` release. The Phase 4 document warns that the example's parameters do not fully specify a flame and that no whole-spell grammar parse was performed. This phase preserves those caveats.

The fixture validator normalises the written transcription into tokens and checks equality against the recovered sequence. It does **not** prove that a speaker will pronounce it unambiguously, that a listener will parse it correctly, or that it creates a physically feasible flame.

## 4. Important implementation boundary

The small validator resolves a form only after the caller supplies an explicit lexical class/slot. This is a test harness for the documented homographs, not a parser that discovers the slot from the utterance. Therefore, its slot tests demonstrate that the lexicon supports distinct readings when the slot is already known; they do not demonstrate that spoken syntax always identifies that slot.

Likewise, the no-slot tests deliberately preserve multiple readings. This implements the anti-guessing principle at the lexical lookup layer, but it does not enforce the canonical unique-parse rule over arbitrary Arcane expressions.

## 5. Decisions

- **P5.21-D1 — Keep `re` and `ra`.** Their different readings are documented and can be resolved when slot information is supplied. No legal ambiguous construction has yet been demonstrated that requires renaming.
- **P5.21-D2 — Do not claim parser conformance.** A full grammar parser remains a separate deliverable.
- **P5.21-D3 — Do not add blanket register exclusion.** The existing hand-flame example uses Shared lexical material inside Performed Arcana.
- **P5.21-D4 — Preserve provisional status.** The parameter-vowel map, h-domain map, complete MEL landmark system, and productive boundary rules are not upgraded by these tests.
- **P5.21-D5 — Keep failure and blocked distinct.** A blocked test means evidence or implementation is insufficient; it is not a grammar failure.

## 6. Next phase: Phase 5.22

The next useful step is to formalise only the minimum grammar needed for a tiny executable subset:

1. define the construction-clause boundary and the reference slot;
2. specify exactly where quantity numerals and unit tokens can occur;
3. specify the legal token classes and order for the hand-flame fixture, without assuming the physical effect is complete;
4. define a small parser that returns either one parse tree, an ambiguity error, or an unsupported/blocked construction;
5. test malformed variants and nested/modified constructions against that limited grammar;
6. retain all unsupported forms as unsupported rather than guessing their intended interpretation.

Only after that subset works should it be expanded. This is safer than writing a broad parser around grammar rules that remain undocumented.

## 7. Reproduction

Run:

```bash
python arcane_phase_5_21_fixtures.py
```

The script reads `Arcane_Lexicon_v5_draft.csv` from the same directory and writes `Arcane_Phase_5_21_Results.json`. The report and script are included with the source documents in the package.
