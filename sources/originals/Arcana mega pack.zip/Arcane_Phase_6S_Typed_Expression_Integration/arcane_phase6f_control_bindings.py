#!/usr/bin/env python3
"""Arcane Phase 6F: bounded control flow and binding semantics prototype.
Audit notation only. Implements only the subset grounded in Phase 4 G-2/G-5/G-6
and Phase 4's KWAM/KWAT/KWASH descriptions. Not a surface-grammar parser or spell engine.
"""
from dataclasses import dataclass
from pathlib import Path
import sys
from arcane_phase6c_operator_registry import Parser, Atom, Call, Type, Q, BOOL, check, TypeCheckError, ParseError
from arcane_phase6d_lexicon_bridge import load_lexicon, alias_map, normalise_ast
from arcane_phase6e_runtime_evaluator import Quantity, Vector, Relation, UnitSymbol, Runtime, ENV, EvaluationError, eval_ast, show

class ControlError(ValueError): pass
@dataclass
class State:
    values: dict
    types: dict
    steps: int = 0
    max_steps: int = 100

def id_name(node):
    if not isinstance(node, Atom):
        raise ControlError('Binding identifier must be a single audit-symbol atom such as ID_1; numeric SHO-closed surface identifiers are not parsed here')
    if not (node.value.startswith('ID_') and node.value[3:].isdigit()):
        raise ControlError('Binding identifier must use audit notation ID_n; this is not a new Arcane word')
    return node.value

def type_of_value(v):
    if isinstance(v, Quantity): return Type('Quantity', v.dims)
    if isinstance(v, Vector): return Type('Vector', v.dims)
    if isinstance(v, bool): return BOOL
    if isinstance(v, Relation): return Type('RelationCriterion')
    if isinstance(v, UnitSymbol): return Type('UnitSymbol')
    raise ControlError(f'Unsupported binding value type: {type(v).__name__}')

def is_block(node):
    return isinstance(node, Call) and node.operator == 'METO'

def infer(node, st):
    if isinstance(node, Atom):
        if node.value in st.types: return st.types[node.value]
        raise TypeCheckError(f'Unknown symbol or unbound identifier: {node.value}')
    op, args = node.operator, node.args
    if op == 'KWAT':
        if len(args)!=1: raise TypeCheckError('KWAT expects one binding identifier')
        name=id_name(args[0])
        if name not in st.types: raise TypeCheckError(f'Unbound reference: {name}')
        return st.types[name]
    if op == 'KWAM':
        if len(args)!=2: raise TypeCheckError('KWAM expects identifier and value expression')
        name=id_name(args[0]); t=infer(args[1],st)
        st.types[name]=t
        return t
    if op == 'KWAK':
        if len(args)!=1: raise TypeCheckError('KWASH expects one live expression')
        return infer(args[0],st)
    if op in ('BEK','ZET','KOLE'):
        if len(args)!=2: raise TypeCheckError(f'{op} expects condition and block')
        if infer(args[0],st).kind!='Boolean': raise TypeCheckError(f'{op} condition must be Boolean')
        if not is_block(args[1]): raise TypeCheckError(f'{op} requires a METO block')
        result=Type('Unit')
        for expr in args[1].args: result=infer(expr,st)
        return result
    if op == 'METO':
        result=Type('Unit')
        for expr in args: result=infer(expr,st)
        return result
    if op == 'WEKI':
        raise TypeCheckError('WEKI iteration is blocked: collection, item binding and ordering signatures are not defined in recovered canon')
    # Type-check the ordinary operator after replacing extension expressions with typed placeholders.
    placeholder_types={}; rewritten=[]
    for i,arg in enumerate(args):
        t=infer(arg,st); key=f'__ARG_{i}'
        placeholder_types[key]=t; rewritten.append(Atom(key))
    env=dict(placeholder_types)
    return check(Call(op,tuple(rewritten)), env)

def evaluate(node, st):
    st.steps += 1
    if st.steps > st.max_steps: raise ControlError(f'Evaluation step budget exceeded ({st.max_steps}); possible non-terminating control flow')
    if isinstance(node, Atom):
        if node.value in st.values: return st.values[node.value]
        raise EvaluationError(f'Unknown runtime symbol or unbound identifier: {node.value}')
    op,args=node.operator,node.args
    if op=='KWAT':
        if len(args)!=1: raise EvaluationError('KWAT expects one binding identifier')
        name=id_name(args[0])
        if name not in st.values: raise EvaluationError(f'Unbound reference: {name}')
        return st.values[name]
    if op=='KWAM':
        if len(args)!=2: raise EvaluationError('KWAM expects identifier and value expression')
        name=id_name(args[0]); val=evaluate(args[1],st)
        st.values[name]=val; st.types[name]=type_of_value(val)
        return val
    if op=='KWAK':
        if len(args)!=1: raise EvaluationError('KWASH expects one live expression')
        # No memoisation: evaluate against current state on each invocation.
        return evaluate(args[0],st)
    if op=='METO':
        out=None
        for expr in args: out=evaluate(expr,st)
        return out
    if op in ('BEK','ZET','KOLE'):
        if len(args)!=2: raise EvaluationError(f'{op} expects condition and block')
        if not is_block(args[1]): raise EvaluationError(f'{op} requires a METO block')
        out=None
        if op=='BEK':
            if not isinstance(evaluate(args[0],st),bool): raise EvaluationError('BEK condition must be Boolean')
            condition=evaluate(args[0],st)
            if not isinstance(condition,bool): raise EvaluationError('BEK condition must be Boolean')
            return evaluate(args[1],st) if condition else None
        if op=='ZET':
            while True:
                cond=evaluate(args[0],st)
                if not isinstance(cond,bool): raise EvaluationError('ZET condition must be Boolean')
                if not cond: break
                out=evaluate(args[1],st)
            return out
        if op=='KOLE':
            while True:
                cond=evaluate(args[0],st)
                if not isinstance(cond,bool): raise EvaluationError('KOLE condition must be Boolean')
                if cond: break
                out=evaluate(args[1],st)
            return out
    if op=='WEKI': raise EvaluationError('WEKI execution blocked: collection semantics are unresolved')
    vals=[evaluate(arg,st) for arg in args]
    tmp={}; ttmp={}; atoms=[]
    for i,val in enumerate(vals):
        k=f'__ARG_{i}'; tmp[k]=val; ttmp[k]=type_of_value(val); atoms.append(Atom(k))
    check(Call(op,tuple(atoms)),ttmp)
    return eval_ast(Call(op,tuple(atoms)),tmp)

def parse(source, lexicon=None):
    rows=load_lexicon() if lexicon is None else lexicon
    return normalise_ast(Parser(source).parse(), alias_map(rows))

def run(source, env=None, max_steps=100):
    values=dict(ENV if env is None else env)
    types={k:type_of_value(v) for k,v in values.items()}
    st=State(values,types,0,max_steps)
    ast=parse(source)
    # Static pass uses a separate binding-type map so checking does not execute assignments.
    static=State(dict(values),dict(types),0,max_steps)
    infer(ast,static)
    return evaluate(ast,st), st

def tests():
    out=[]
    def add(i,name,fn):
        try: ok,detail=fn()
        except Exception as e: ok,detail=False,f'{type(e).__name__}: {e}'
        out.append((i,name,'PASS' if ok else 'FAIL',str(detail)))
    def eq(src,want):
        got,st=run(src); return got==want, f'{src} -> {show(got) if got is not None else None}; expected {show(want) if want is not None else None}'
    def err(src,needle,max_steps=100):
        try: run(src,max_steps=max_steps)
        except Exception as e: return needle.lower() in str(e).lower(), f'{type(e).__name__}: {e}'
        return False,'No error raised'
    add('6F-01','BEK executes block when condition true',lambda:eq('BEK⟨BOOL_A, METO⟨FRAPA⟨A, B⟩⟩⟩',Quantity(5,(0,0,0,0))))
    add('6F-02','BEK skips block when condition false',lambda:eq('BEK⟨BOOL_FALSE, METO⟨FRAPA⟨A, B⟩⟩⟩',None))
    add('6F-03','BEK rejects non-Boolean condition',lambda:err('BEK⟨A, METO⟨B⟩⟩','condition must be Boolean'))
    add('6F-04','BEK requires explicit METO block',lambda:err('BEK⟨BOOL_A, A⟩','METO block'))
    add('6F-05','KWAM stores a value',lambda:eq('KWAM⟨ID_1, FRAPA⟨A, B⟩⟩',Quantity(5,(0,0,0,0))))
    add('6F-06','KWAT reads a stored binding',lambda:(lambda v,st:(v==Quantity(5,(0,0,0,0)) and st.values['ID_1']==v,'stored value retrieved'))(*run('METO⟨KWAM⟨ID_1, FRAPA⟨A, B⟩⟩, KWAT⟨ID_1⟩⟩')))
    add('6F-07','KWAT rejects an unbound identifier',lambda:err('KWAT⟨ID_9⟩','Unbound reference'))
    add('6F-08','KWAM identifier syntax is restricted to audit ID_n form',lambda:err('KWAM⟨A, B⟩','audit notation ID_n'))
    add('6F-09','KWASH evaluates expression without memoising',lambda:(lambda first,second:(first==Quantity(5,(0,0,0,0)) and second==Quantity(6,(0,0,0,0)),'live expression changes with current binding'))(*[run('KWASH⟨FRAPA⟨KWAT⟨ID_1⟩, A⟩⟩',env={**ENV,'ID_1':Quantity(n,(0,0,0,0))})[0] for n in (3,4)]))
    add('6F-10','ZET exits when condition becomes false',lambda:(lambda v,st:(v==Quantity(3,(0,0,0,0)) and st.values['ID_1']==Quantity(3,(0,0,0,0)),'bounded while loop increments ID_1 from 0 to 3'))(*run('ZET⟨DRAL⟨KWAT⟨ID_1⟩, B, LT⟩, METO⟨KWAM⟨ID_1, FRAPA⟨KWAT⟨ID_1⟩, ONE⟩⟩⟩⟩',env={**ENV,'ONE':Quantity(1,(0,0,0,0)),'ID_1':Quantity(0,(0,0,0,0))})))
    add('6F-11','KOLE exits when condition becomes true',lambda:(lambda v,st:(st.values['ID_1']==Quantity(3,(0,0,0,0)),'until loop stops at condition true'))(*run('KOLE⟨DRAL⟨KWAT⟨ID_1⟩, B, GE⟩, METO⟨KWAM⟨ID_1, FRAPA⟨KWAT⟨ID_1⟩, ONE⟩⟩⟩⟩',env={**ENV,'ONE':Quantity(1,(0,0,0,0)),'ID_1':Quantity(0,(0,0,0,0))})))
    add('6F-12','ZET catches possible infinite loop by step budget',lambda:err('ZET⟨BOOL_A, METO⟨A⟩⟩','step budget',max_steps=12))
    add('6F-13','KOLE initially true executes zero iterations',lambda:(lambda v,st:(st.values['ID_1']==Quantity(3,(0,0,0,0)),'already-true condition stops immediately'))(*run('KOLE⟨DRAL⟨KWAT⟨ID_1⟩, A, GE⟩, METO⟨KWAM⟨ID_1, FRAPA⟨KWAT⟨ID_1⟩, B⟩⟩⟩⟩',env={**ENV,'ID_1':Quantity(3,(0,0,0,0))})))
    add('6F-14','WEKI remains blocked without collection signature',lambda:err('WEKI⟨A, METO⟨B⟩⟩','collection'))
    add('6F-15','Nested conditional executes correctly',lambda:eq('BEK⟨BOOL_A, METO⟨BEK⟨BOOL_FALSE, METO⟨A⟩⟩, B⟩⟩',Quantity(3,(0,0,0,0))))
    add('6F-16','Assignment rejects later incompatible arithmetic',lambda:err('METO⟨KWAM⟨ID_1, LEN_A⟩, FRAPA⟨KWAT⟨ID_1⟩, TIME_A⟩⟩','matching dimensions'))
    add('6F-17','Binding stores typed vector values',lambda:(lambda v,st:(v==ENV['VEC_LEN_A'],'vector binding retains vector type'))(*run('METO⟨KWAM⟨ID_2, VEC_LEN_A⟩, KWAT⟨ID_2⟩⟩')))
    add('6F-18','Missing body value returns Unit-like None for skipped IF',lambda:eq('BEK⟨BOOL_FALSE, METO⟨A⟩⟩',None))
    return out
if __name__=='__main__':
    results=tests()
    for r in results: print(' | '.join(r))
    print(f'RESULT: {sum(r[2]=="PASS" for r in results)}/{len(results)} passed')
