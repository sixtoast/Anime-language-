Arcane Phase 6S — Typed expression integration

This is a provisional reference implementation, not canonical Arcane syntax and not the historical Phase 6H runtime.

Run all combined tests from this directory:
python -m unittest -v test_arcane_reference_runtime test_phase6q_grammar test_phase6r_dimensions test_phase6s_typed_runtime

Expected result in this package: 68 tests passed.

Main files:
- arcane_typed_runtime.py: typed evaluator bridge
- arcane_dimensions.py: Phase 6R dimension model
- arcane_reference_runtime.py: Phase 6P expression parser/evaluator
- test_phase6s_typed_runtime.py: new integration tests
- PHASE_6S_TEST_OUTPUT.txt: recorded test run
- ARCANE_PHASE_6S_REPORT.md: scope and limitations

QuantityLiteral is a programmatic test AST node. No canonical surface syntax for units or quantities is asserted.
