# Arcane Phase 5.11 — Typed Expression Audit Harness

**Status:** 14/14 implemented checks pass. This is a typed audit harness, not a canonical Arcane compiler. It uses Phase 2's angle-bracket notation only as metanotation and does not introduce spoken forms.

## Scope

This phase begins the next recommended step from Phase 5.10: a small expression parser and typed arithmetic layer. It covers nested audit expressions, fixed arity, rejection of malformed grouping, dimensional arithmetic, comparison compatibility, and division by zero.

## Implemented checks

- Addition and subtraction require compatible dimensions and frame tags.
- Multiplication adds dimension exponents; division subtracts them.
- Length × length produces area dimensions; length ÷ time produces velocity dimensions.
- Division by zero is rejected.
- Comparisons require matching types and frame tags and a known relation operator (`NADI`, `DOFA`, `GUWI`).
- The audit parser preserves nested argument structure and rejects unclosed brackets, trailing tokens, unknown operators, missing arguments and extra arguments.
- Exact rational values are used in arithmetic fixtures.

## Deliberate limits

1. `FRAPA` and `FRALA` are the canonical Phase 3/4 roots. Where Phase 4 renamed sibling roots, the test harness does not silently rewrite the canonical lexicon; the implementation's comments acknowledge aliases where applicable.
2. The parser uses Phase 2 audit punctuation (`⟨`, `⟩`, commas), not the spoken or written surface grammar.
3. It does not yet parse numeral sequences directly inside expressions or connect them to the Phase 5.10 numeral parser.
4. It does not implement vector types, general affine frames, uncertainty, angle conversions, information/mana dimensions, temporal/control operators, or Construction Feet.
5. It does not compile an expression to a mana configuration and makes no physical-feasibility claims.
6. Signature coverage is intentionally a tiny subset. An operator is not considered validated merely because its name appears in a signature table.

## Decision ledger

**D-055 — PROVISIONAL:** use a recursively nested AST for the Phase 2 audit notation; this is a testing representation, not surface Arcane.

**D-056 — PROVISIONAL:** arithmetic type checking uses dimension vectors and explicit frame tags; mismatches reject instead of coercing.

**D-057 — UNRESOLVED:** reconcile canonical renamed forms and alias policy in the machine-readable signature inventory before extending the parser.

**D-058 — UNRESOLVED:** integrate numeral closure with expression parsing only after the token-boundary convention has been specified and tested.

## Result

14/14 harness tests pass. This validates the limited parser and arithmetic functions included in the implementation only. It does not validate the full language or spoken parse uniqueness.

## Recommended next phase

Phase 5.12 should establish one machine-readable operator registry from the canonical Phase 2, Phase 3 and Phase 4 evidence: canonical form, historical aliases, arity, input/output types, dimensional rules, evaluation timing, failure behavior and confidence/status. Then generate tests from that registry rather than maintaining independent signature lists.
