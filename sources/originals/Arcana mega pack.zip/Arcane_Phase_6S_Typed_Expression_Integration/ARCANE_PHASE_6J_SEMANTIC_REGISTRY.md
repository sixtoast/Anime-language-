# Arcane Phase 6J — Source-backed Semantic Registry

**Status:** registry assembled from the recovered project archive; no canon changes made.

## What this phase did

Phase 6J extracts lexical status and glosses from `Arcane_Lexicon_v5_draft.csv` and cross-references recovered Phase 4/5 audits, the continuity recovery audit, the decision ledger and the grammar test register. The resulting CSV contains every lexicon row, including duplicate surface forms, with separate fields for source status, proposed signature, evidence, confidence/status and unresolved issue. It intentionally does not infer signatures from glosses.

## Critical source-backed findings

1. **`FRASHA` semantic mismatch:** the recovered lexicon and continuity audit gloss it as *negate*, but Phase 6H's evaluator implements absolute value (`abs`). This is an implementation/specification mismatch and should be corrected only after checking the authoritative Phase 3 definitions. Until resolved, `FRASHA` must not be described as verified end-to-end semantics.
2. **`SHO`, `METO`, `DOGU` status conflict:** Phase 4 grammar depends on SHO as the dimensionless numeral closure and describes METO/DOGU as block delimiters, while the Phase 5 draft lexicon marks all three `PROPOSED`. Their canonical status needs an explicit ledger reconciliation.
3. **`KOLE` remains proposed:** Phase 4 names UNTIL/KOLE, but the current lexicon still marks it proposed. Phase 6H's implementation must remain provisional and gated.
4. **Operator signatures remain incomplete:** Phase 4 G-1 states that every head has a fixed arity and typed signature, but the recovered decision ledger D-008 explicitly proposes defining operator-specific signatures. These statements can coexist only if the rule is canonical while the full inventory remains incomplete.
5. **Historical names need version-aware treatment:** the recovery audit contains historical spellings such as FRATA/FRAKA/GRAK/KWAK, while v3.0-L uses renamed forms FRAJA/FRAMA/GRASH/KWASH. Compatibility aliases should be explicit and versioned, not silently treated as canonical vocabulary.
6. **Information units remain unresolved:** Phase 4 says VO is a bit but no information dimension is assigned (D-015). No physical or algebraic combination rule should be invented.
7. **Near-collision and operational tests remain open:** the test register calls for robustness testing of FRAPA/FRAJA/FRAMA-family contrasts, GRAN/GRAT/GRAK-family contrasts, and DREM/DRIM. These are not passed merely because parser unit tests pass.

## Registry status categories

- `ESTABLISHED_*`: the form/gloss is directly supported by the recovered source; this does **not** automatically mean its complete executable signature is known.
- `*_UNRESOLVED`: source evidence is insufficient to lock arity, types or runtime semantics.
- `PROPOSED_*`: the lexicon or ledger has not promoted the item to canon.
- `*_CONFLICT*`: recovered documents disagree or implementation conflicts with the recovered gloss.

## Recommended corrective sequence

1. Correct or quarantine the FRASHA evaluator mismatch after checking the authoritative source definition.
2. Reconcile statuses for SHO, METO, DOGU and KOLE in the decision ledger and lexicon; do not silently promote them.
3. Add a versioned operator-signature table with argument types, return type, dimensional constraints, evaluation order, error behaviour and source citation.
4. Add semantic tests from source examples, including near-collision checks, and label unrun human-listener tests as OPEN.
5. Only then extend unit algebra or connect these operators to Construction compilation.

## Scope limitations

This is a source reconciliation and registry phase, not a complete compiler. It does not prove phonological intelligibility, physical feasibility, mana accounting, targeting or construction execution.
