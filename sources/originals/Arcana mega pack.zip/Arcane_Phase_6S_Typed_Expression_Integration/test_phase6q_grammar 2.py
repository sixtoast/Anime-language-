"""Phase 6Q grammar-conformance tests for the provisional parenthesized harness.

These tests do not establish Arcane's canonical surface syntax. They validate only
its explicitly documented Phase 6P test notation.
"""
import unittest
from decimal import Decimal
from arcane_reference_runtime import (
    parse, run, show_ast, ArcaneParseError, ArcaneArityError,
    ArcaneTypeError, ArcaneEvaluationError, Number, Boolean, Call,
)

class TestPhase6QGrammar(unittest.TestCase):
    # T-001: arity in the reference notation
    def test_t001_binary_operator_accepts_two_arguments(self):
        self.assertEqual(run('(frapa 2 3)'), Decimal('5'))

    def test_t001_missing_argument_is_rejected(self):
        with self.assertRaises(ArcaneArityError): parse('(frapa 2)')

    def test_t001_extra_argument_is_rejected(self):
        with self.assertRaises(ArcaneArityError): parse('(frapa 1 2 3)')

    # T-002: order preserved in FRAJA; historical FRATA alias is not assumed.
    def test_t002_operand_order_is_preserved_for_fraja(self):
        self.assertEqual(run('(fraja 9 4)'), Decimal('5'))
        self.assertEqual(run('(fraja 4 9)'), Decimal('-5'))

    # T-003: explicit nesting builds different ASTs and results.
    def test_t003_nested_grouping_changes_ast(self):
        left = parse('(fraja 2 (frapa 3 4))')
        right = parse('(frapa (fraja 2 3) 4)')
        self.assertNotEqual(show_ast(left), show_ast(right))

    def test_t003_nested_grouping_changes_result(self):
        self.assertEqual(run('(fraja 2 (frapa 3 4))'), Decimal('-5'))
        self.assertEqual(run('(frapa (fraja 2 3) 4)'), Decimal('3'))

    # T-004: unsupported infix forms cannot silently acquire an interpretation.
    def test_t004_ambiguous_unparenthesized_infix_is_rejected(self):
        with self.assertRaises(ArcaneParseError): parse('2 fraja 3 frapa 4')

    def test_t004_trailing_expression_is_rejected(self):
        with self.assertRaises(ArcaneParseError): parse('(frapa 1 2) 3')

    # Lexer and structural integrity cases.
    def test_empty_source_rejected(self):
        with self.assertRaises(ArcaneParseError): parse('')

    def test_whitespace_only_source_rejected(self):
        with self.assertRaises(ArcaneParseError): parse('   \n  ')

    def test_unclosed_call_rejected(self):
        with self.assertRaises(ArcaneParseError): parse('(frapa 1 2')

    def test_unexpected_closing_parenthesis_rejected(self):
        with self.assertRaises(ArcaneParseError): parse(')')

    def test_missing_operator_rejected(self):
        with self.assertRaises(ArcaneParseError): parse('(')

    def test_unknown_operator_rejected(self):
        with self.assertRaises(ArcaneParseError): parse('(kole true)')

    def test_boolean_literal_case_is_normalized(self):
        self.assertIs(run('(grash FALSE)'), True)

    def test_leading_and_internal_whitespace_supported(self):
        self.assertEqual(run('  ( frapa   2   3 )  '), Decimal('5'))

    def test_numeric_boolean_type_mismatch_rejected(self):
        with self.assertRaises(ArcaneTypeError): run('(gran true 1)')

    def test_division_by_zero_rejected(self):
        with self.assertRaises(ArcaneEvaluationError): run('(frala 2 0)')

if __name__ == '__main__':
    unittest.main(verbosity=2)
