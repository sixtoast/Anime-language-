# Arcane Phase 5.22 — Bounded Construction Parser

**Status:** first parser implemented for one documented construction profile. **Canon changed:** no. **General parser:** still not implemented.

## Outcome

The parser accepts the recovered Phase 4 hand-flame transcription only under a deliberately narrow profile. It returns a structured parse tree and rejects malformed variants with explicit error codes. It does not infer missing grammar or interpret a rejection as proof that the utterance is invalid in every possible Arcane construction.

Automated test run: **17 PASS, 0 FAIL, 17 total**.

## What it parses

`mel · po da za shi to za ma · kan ken · he ha · sa shi za se · kas`

The tree records:

- `mel` as the documented anchor token, with its full landmark semantics explicitly unresolved;
- `po da za shi to za ma` as a position role, +Y axis and a metre-closed quantity;
- `kan ken` as the documented example Foot sequence;
- `he ha` as the documented coupling sequence, retaining provisional domain interpretations;
- `sa shi za se` as a duration quantity in seconds;
- `kas` as the release token.

The quantity parser enforces Phase 4 G-2: a numeral ends in a unit; decimal separator `shi` requires digits on both sides; unknown digits and multiple decimal separators are rejected. The profile enforces metre for its position quantity and seconds for its duration quantity.

## Critical boundary

This is a **fixture-profile parser**, not the general Arcane grammar. It currently recognises one exact six-phrase construction profile. It does not prove all Performed Arcana can be parsed, does not implement all formal typed expressions, and does not evaluate physical feasibility. Unknown or unsupported construction patterns receive explicit errors instead of a guessed parse.

A profile-specific rejection means “not accepted by this implemented subset”, not necessarily “ungrammatical in Arcane”.

## Test coverage

| `valid canonical fixture` | PASS | `PARSED_SUBSET` |
| `missing phrase` | PASS | `E-PHRASE-COUNT` |
| `empty phrase` | PASS | `E-EMPTY-PHRASE` |
| `unknown anchor` | PASS | `E-ANCHOR` |
| `unknown role` | PASS | `E-SPATIAL` |
| `unknown axis` | PASS | `E-SPATIAL` |
| `quantity missing unit` | PASS | `E-QTY-UNIT` |
| `bad digit` | PASS | `E-QTY-DIGIT` |
| `bad decimal no whole digits` | PASS | `E-QTY-DECIMAL` |
| `bad decimal no fractional digits` | PASS | `E-QTY-DECIMAL` |
| `multiple decimals` | PASS | `E-QTY-DECIMAL` |
| `wrong position unit` | PASS | `E-POSITION-UNIT` |
| `wrong foot profile` | PASS | `E-FOOT-PROFILE` |
| `wrong coupling profile` | PASS | `E-COUPLING-PROFILE` |
| `wrong duration unit` | PASS | `E-DURATION-UNIT` |
| `missing release` | PASS | `E-RELEASE` |
| `rejected unclosed phrase boundaries` | PASS | `E-PHRASE-COUNT` |

## Decisions

- **P5.22-D1 — Accept the parser as a bounded implementation only.** No general grammar conformance claim.
- **P5.22-D2 — Preserve explicit phrase boundaries.** The documented middle dots are required in this profile; omitted boundaries are rejected rather than reconstructed by guesswork.
- **P5.22-D3 — Treat number/unit parsing as a reusable component.** Unit closure and decimal validation are implemented; dimensional analysis beyond the fixture's metre/second constraints remains future work.
- **P5.22-D4 — Keep provisional semantics provisional.** `mel` anchoring, parameter-vowel mapping and h-coupling domains are not upgraded to canon by the parser.
- **P5.22-D5 — Separate syntax from physics.** A successful parse says the tokens fit this profile; it does not establish that a flame is physically produced.

## Phase 5.23 next

1. Extract reusable lexer, quantity parser, error model and AST into a small package.
2. Add a formal-expression parser with typed prefix signatures, starting from Phase 2's explicit bracket notation as audit metalanguage—not as spoken Arcane.
3. Add a static type checker for dimensions and fixed-arity operators, with unresolved signatures rejected as unsupported.
4. Connect formal expressions to construction profiles only through an explicit compile-bridge mapping.
5. Add a test corpus that distinguishes syntax rejection, type rejection, ambiguity, unsupported grammar and physical-feasibility failure.

## Reproduction

```bash
python arcane_phase_5_22_parser.py --test
python arcane_phase_5_22_parser.py
```

The second command parses the canonical fixture and prints a JSON parse tree. To try other input, pass the full construction as a single quoted argument, preserving the middle-dot separators.
