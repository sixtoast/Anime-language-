# Arcane Phase 5.12 — Canonical Operator Registry

**Status: PROVISIONAL REGISTRY; not a canon rewrite.**

## Purpose

Consolidate the Phase 2 signature proposals with Phase 4's renames and the v4/v5 lexicon drafts. This registry is a single audit source for spellings, aliases, arity, types, dimensional behaviour, evaluation, failure conditions, evidence and open questions. It does not pretend that every operator contract has been recovered.

## Source-priority rule

Where Phase 4 explicitly renamed a Phase 2/v3.0-L form, the Phase 4 spelling is the canonical candidate and the earlier form is retained as a source-compatibility alias: `FRATA → FRAJA`, `FRAKA → FRAMA`, `DRIM → DRUM`, `DRAL → DRAS`, `GRAK → GRASH`, and `KWAK → KWASH`. This follows the recovery pack's rule to preserve old forms as aliases unless an inconsistency is demonstrated. Do not emit aliases as canonical spellings in new formal material.

## Core safeguards

- `FRAPA`, `FRAJA`, `FRAMA`, `FRALA`, and `FRASHA` are registry forms for arithmetic, but signatures remain provisional pending complete semantic-kind and dimensional rules.
- `DRAS` requires a relation criterion; Phase 4 relation values (`NADI`, `DOFA`, `GUWI`) are still proposed, not canon.
- `SIMA` requires a physical measurement pathway. Its exact surface arity is unresolved.
- `GAMA` changes symbolic assignment only. Assignment is not physical causation.
- `KWAM` creates a binding, not a physical object. Its identifier is a numeral closed by `SHO` under Phase 4 G-2.
- `KWASH` is the Phase 4 canonical candidate for live evaluation; sampling and evaluation timing remain open.
- `BEK` and `ZET` must be reconciled with Phase 4's block grammar (`METO`/`DOGU`) and condition semantics. Do not use the earlier two-argument sketch to bypass block structure.
- `KREN`, `TRAK`, `FREM`, `SHREN`, `BRAN`, and `VARE` belong to the Construction/Foot layer or its macro bridge. Their exact v2.0 expansion contracts must be recovered before they are marked complete.
- `LABU` and the Phase 4 temporal/constraint roots are tracked as proposed only. Their presence in a draft lexicon is not evidence of canonical acceptance.

## Validation

The accompanying harness checks registry uniqueness, alias reconciliation, required operator coverage, source/status completeness, proposed-vs-canon separation, and key safety invariants. It reports **19/19 checks passed**. These are registry consistency checks, not proof that all signatures are correct, that a compiler exists, or that the spoken forms are distinguishable to listeners.

## Decision ledger

- **D-051 — PROVISIONAL:** Use Phase 4 spellings as canonical candidates for explicitly renamed roots; preserve old spellings as aliases.
- **D-052 — PROVISIONAL:** Keep operator contracts in one machine-readable registry with explicit OPEN/PROVISIONAL status.
- **D-053 — OPEN:** Finalise DRAS relation-criterion encoding and accept/reject the proposed relation roots.
- **D-054 — OPEN:** Recover exact v2.0 Foot/macro contracts for KREN/TRAK/FREM/SHREN/BRAN/VARE.
- **D-055 — OPEN:** Specify block result semantics and evaluation timing for BEK/ZET/KOLE/WEKI/RUKI.
- **D-056 — OPEN:** Determine whether information has a dimension and define the role of VO without guessing.
- **D-057 — OPEN:** Define SIMA sampling/provenance and KWASH repeated evaluation semantics.

## Next phase

Phase 5.13 should not invent more words. It should build a minimal typed abstract syntax tree and a compile-time validator that reads this registry, rejects OPEN signatures in strict mode, and tests full nested expressions against the registry. Keep the construction layer separate from the expression layer until the v2.0 morphology source is fully recovered.
