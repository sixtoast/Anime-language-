#!/usr/bin/env python3
"""Evidence-bounded Arcane Phase 5.21 fixture validator.

This is intentionally NOT a complete Arcane parser. It validates only documented
lexical readings, the exact Phase 4 hand-flame token sequence, and whether a
caller supplied a declared lexical slot. It never infers undocumented grammar.
"""
import csv, json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LEXICON = ROOT / 'Arcane_Lexicon_v5_draft.csv'
EXPECTED_HAND_FLAME = [
    'mel', 'po', 'da', 'za-shi-to-za', 'ma',
    'kan', 'ken', 'he', 'ha', 'sa-shi-za', 'se', 'kas'
]

with LEXICON.open(encoding='utf-8-sig', newline='') as f:
    rows = list(csv.DictReader(f))

def entries(form):
    return [r for r in rows if r.get('form', '').strip().lower() == form.lower()]

def resolve(form, slot):
    """Resolve only when the explicitly supplied slot matches one inventory row."""
    candidates = [r for r in entries(form) if r.get('cls', '').strip().upper() == slot.upper()]
    if len(candidates) == 1:
        return {'status': 'PASS', 'form': form, 'slot': slot,
                'gloss': candidates[0].get('gloss'), 'register': candidates[0].get('register')}
    if not candidates:
        return {'status': 'REJECT', 'form': form, 'slot': slot,
                'reason': 'No lexicon entry for this form in the explicitly supplied slot.'}
    return {'status': 'BLOCKED', 'form': form, 'slot': slot,
            'reason': 'More than one candidate remains in this slot.'}

results = []
# Lexical provenance checks
for form, cls, gloss in [('re', 'DIGIT', '4'), ('ra', 'UNIT', 'radian'),
                         ('re', 'FUSED-REF', 'TARGET-surface'),
                         ('ra', 'FUSED-REF', 'TARGET-path')]:
    found = [r for r in entries(form) if r.get('cls', '').strip().upper() == cls]
    passed = len(found) == 1 and found[0].get('gloss', '').strip() == gloss
    results.append({'id': f'P521-LEX-{form}-{cls}', 'status': 'PASS' if passed else 'FAIL',
                    'expected': {'form': form, 'class': cls, 'gloss': gloss},
                    'matches': len(found)})

# Slot supplied => inventory resolution; no slot supplied => ambiguity must remain visible.
for test_id, form, slot, expected in [
    ('P521-SLOT-01', 're', 'DIGIT', '4'),
    ('P521-SLOT-02', 're', 'FUSED-REF', 'TARGET-surface'),
    ('P521-SLOT-03', 'ra', 'UNIT', 'radian'),
    ('P521-SLOT-04', 'ra', 'FUSED-REF', 'TARGET-path'),
]:
    r = resolve(form, slot)
    passed = r['status'] == 'PASS' and r.get('gloss') == expected
    results.append({'id': test_id, 'status': 'PASS' if passed else 'FAIL', 'detail': r})

for test_id, form in [('P521-AMB-01', 're'), ('P521-AMB-02', 'ra')]:
    candidates = entries(form)
    distinct = {(r.get('cls'), r.get('gloss')) for r in candidates}
    status = 'PASS' if len(distinct) >= 2 else 'FAIL'
    results.append({'id': test_id, 'status': status,
                    'detail': 'Without a syntactic slot, lexical lookup must preserve multiple readings; no guess is made.',
                    'readings': sorted([{'class': c, 'gloss': g} for c, g in distinct], key=lambda x: (x['class'] or '', x['gloss'] or ''))})

# Verify exact documented hand-flame token sequence against Phase 4 source transcription.
# Token grouping below is transcription-normalisation only; no full parse is claimed.
source_sequence = 'mel · po da za shi to za ma · kan ken · he ha · sa shi za se · kas'
normalised = [x for x in source_sequence.replace('·', ' ').split()]
expected_flat = ['mel','po','da','za','shi','to','za','ma','kan','ken','he','ha','sa','shi','za','se','kas']
results.append({'id': 'P521-HF-01', 'status': 'PASS' if normalised == expected_flat else 'FAIL',
                'detail': 'Exact Phase 4 transcription tokens match. This checks transcription only, not grammar or physical feasibility.',
                'actual': normalised})

# Explicitly blocked tests, retained to prevent overclaiming.
for test_id, reason in [
    ('P521-GRAMMAR-01', 'Full spoken construction parse is not implemented; Phase 4 explicitly says no grammar-level parse of the whole hand-flame spell was run.'),
    ('P521-WRONG-SLOT-01', 'Cannot reject every competing slot use without the complete productive construction grammar and argument signatures.'),
    ('P521-MIXED-REGISTER-01', 'Shared numerals/units appear in the documented Performed hand-flame example; a blanket prohibition would contradict evidence.'),
]:
    results.append({'id': test_id, 'status': 'BLOCKED', 'detail': reason})

summary = {
    'phase': '5.21',
    'title': 'Evidence-bounded construction conformance fixtures',
    'scope': 'Lexical provenance, declared-slot lookup, ambiguity visibility, and transcription check only.',
    'is_general_parser': False,
    'canon_changed': False,
    'counts': {s: sum(1 for r in results if r['status'] == s) for s in ['PASS','FAIL','BLOCKED','REJECT']},
    'results': results,
}
(ROOT / 'Arcane_Phase_5_21_Results.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding='utf-8')
print(json.dumps(summary['counts',] if False else summary['counts'], indent=2))
if summary['counts']['FAIL']:
    raise SystemExit(1)
