# ARCANE LANGUAGE AUDIT — PHASE 5.16
## Construction contract recovery and compiler-boundary specification

**Status:** Evidence-led recovery draft. No new lexical or morphological rule is promoted to canon in this phase.

## 1. Purpose

Phase 5.16 continues from the supplied `Arcana pack.zip`. Its task is to make the Construction subsystem implementable without pretending that the missing original v2.0 rules have been recovered.

The controlling architecture from Phase 4 is:

- **Expression system:** computes values, resolves references, selects targets and controls timing.
- **Construction system:** uses v2.0 Feet, couplings and scoped references to specify mana operations.
- **Compile bridge:** maps a semantically valid expression into a construction without changing its meaning.

This is a documented architecture. A complete parser and verified compiler bridge are not present in the recovered pack.

## 2. Evidence ledger

| ID | Evidence in recovered pack | Safe conclusion | Status |
|---|---|---|---|
| C-01 | Phase 4 §3.1 | Construction and Expression are separate subsystems. | CANON in Phase 4 |
| C-02 | Phase 4 §3.1 and lexicon tools | A Foot is one syllable with frame consonant + parameter vowel + optional relation coda. | Structural rule documented; semantics incomplete |
| C-03 | Phase 4 §3.3 | Intended performed order: reference, spatial role/vector, Feet, couplings, quantity, control, release. | Documented ordering; general parser unverified |
| C-04 | Phase 4 §3.3 | A reference persists until replaced. | Documented; exact scope transitions need tests |
| C-05 | Phase 4 §3.3 | `me` is described as SELF-surface; bare `MI`, `NI`, `RI` default to volume scope and perform as `mə`, `nə`, `rə`. | Documented; anatomical landmark inventory absent |
| C-06 | Phase 4 §3.3 | Parameter vowel mapping to property families is explicitly PROVISIONAL. | Do not lock |
| C-07 | Phase 4 §3.3 | Mapping from physical coupling vector to `h`-domains is explicitly PROVISIONAL. | Do not lock |
| C-08 | Phase 4 §8 | Hand-flame example is tokenised, but energy magnitude, extent and coupled matter are unspecified; full grammar parse not run. | Example is not a validated spell |
| C-09 | Recovery Audit and Decision Ledger D-006/D-007 | Full v2.0 morphology and exact `h` coupling, MEL anchoring, KAN/KEN/KAS rules were not recovered. | UNRESOLVED |
| C-10 | Phase 2 §2 and §5 | Angle-bracket expression notation is audit notation, not established spoken Arcane. | Provisional test notation only |
| C-11 | Phase 4 §9 | Existing checks are mostly token/shape checks; full-spell typed parsing and feasibility were not checked. | Validation gap |
| C-12 | Phase 5 §8 | Vernacular mechanical checks do not validate the Construction compiler. | Separate subsystem |

## 3. Construction pipeline contract

The following is an implementation boundary, not a claim that all grammar rules are already known:

1. **Parse surface tokens** into typed tokens and candidate clauses.
2. **Resolve context**: reference, frame, scope, bindings and any required pathway context.
3. **Validate Construction structure**: Foot shape, ordering, required slots, control scope and release.
4. **Resolve provisional semantics** only when an explicitly labelled provisional profile is selected; never silently treat it as canonical.
5. **Type-check quantities** and validate dimensions/units.
6. **Compile to an intermediate construction representation** preserving references, geometry, temporal structure, boundaries, mechanism and control.
7. **Run physical feasibility checks** against the v3.0 magic constraints: mana, coupling, energy, information, control, temporal/causal feasibility, stability and material constraints.
8. **Reject or emit a diagnostic** if any required rule is missing, ambiguous or infeasible. Never guess a meaning.

The compiler must not infer that a token such as `KAN` means “fire”; Phase 4 explicitly rejects that interpretation.

## 4. Required intermediate representation (IR)

The compiler bridge should emit a structured object with these fields, where values may be unresolved during parsing:

- `reference`: resolved entity/reference and scope
- `frame`: coordinate/reference frame
- `spatial_role`: direction or relation, if present
- `feet`: ordered list of parsed Foot structures (`frame`, `parameter_vowel`, `relation_coda`)
- `couplings`: explicitly encoded coupling domains
- `quantities`: numeric values with units and dimensions
- `control`: conditions, loops, constraints, timing and state transitions
- `release`: release operation/state, if required
- `mechanism`: explicit physical mechanism or unresolved marker
- `provenance`: source rule and confidence/status for every interpretation
- `diagnostics`: missing fields, ambiguity, type errors and feasibility failures

**Important:** This is a proposed software data structure, not new Arcane vocabulary or a new spell rule.

## 5. Fail-closed rules

The compiler must reject, rather than repair by guesswork, at least these cases:

- Foot-shaped token with no known or selected semantic mapping.
- Required reference, frame, pathway, quantity, coupling or control field absent.
- Multiple possible parses or modifier attachments.
- A parameter-vowel or coupling mapping used as canon while its status is PROVISIONAL.
- Numeral not closed by a valid unit in formal/performed grammar, except where a documented exception applies.
- Unit/dimension mismatch or invalid arithmetic signature.
- Release/trigger lifecycle inconsistent with the construction.
- Effect specified without a mechanism or necessary resource accounting.
- A macro whose expansion cannot pass the same parse, type and feasibility checks.

## 6. Hand-flame example: correct current verdict

Recovered token sequence:

`mel · po da za shi to za ma · kan ken · he ha · sa shi za se · kas`

Phase 4 reports tokenisation/legality checks but explicitly says the result may not be a flame and leaves energy magnitude, extent and coupled matter unspecified. Accordingly, the compiler must currently classify this as:

**TOKENISED / PARTIALLY STRUCTURED / NOT PROVEN WELL-TYPED / NOT PHYSICALLY VALIDATED.**

It must not label it “successful fire spell”.

## 7. Next source-recovery action

The current zip contains Phase 1, Phase 2, Phase 4, Phase 5, lexicon drafts, the lexicon tools PDF and the Phase 4 finalisation script as a PDF. It does not contain a standalone complete v2.0 specification or a Phase 3 source document. Therefore exact v2.0 rules cannot be faithfully restored from this pack alone.

Continue in this order:

1. Extract and preserve all surviving v2.0 fragments from Phase 4 and the scripts.
2. Build a rule-by-rule comparison between the recovered fragment, current Phase 4 interpretation and unresolved ledger entries.
3. Keep original rule, auditor inference and replacement proposal in separate columns.
4. If no original evidence exists, request approval for a replacement rule instead of asserting it was recovered.
5. Implement the parser only against the explicitly approved contract; keep provisional semantics behind a versioned profile.

## 8. Phase 5.16 exit criteria

This phase is complete as a recovery specification, not as a language implementation. The following remain open:

- complete surface grammar and unique-parse parser;
- original v2.0 semantics and full landmark inventory;
- canonical parameter-vowel and `h`-coupling mappings;
- fully specified KAN/KEN/KAS and MEL semantics;
- typed end-to-end parse of the hand-flame example;
- physical feasibility validation and adversarial regression corpus;
- spoken/listener testing.

**Decision:** Keep the two-subsystem architecture. Do not lock the provisional mappings. Do not claim the language is fully working until parser, compiler and feasibility tests pass on a meaningful corpus.
