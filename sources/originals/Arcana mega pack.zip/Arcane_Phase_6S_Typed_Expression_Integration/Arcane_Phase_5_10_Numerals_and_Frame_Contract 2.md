# Arcane Phase 5.10 — Numeral Closure and Coordinate-Frame Contract

**Status:** audit implementation passes its 19 defined tests; proposed frame contract remains provisional. This phase does not overwrite Phase 4 or claim that a complete spoken Arcane parser exists.

## 1. Scope and source priority

Phase 4 is the controlling source for this phase. It establishes that every numeral is closed by a unit, `SHO` is the dimensionless unit, and a binding identifier is a numeral closed by `SHO`. It also establishes the canonical unit spellings `MA`, `SE`, `KE`, `RA`, and `KU`, and the frame-transform root `LABU` as proposed in the Phase 4 ledger. The recovered sources do not fully specify a spoken tokenizer or actual transform operands, so this phase tests a token-level audit representation rather than silently inventing surface grammar.

## 2. Numeral closure rules implemented for audit

1. A quantity consists of digit tokens, optionally one `SHI` decimal marker, and exactly one terminal unit token.
2. Canonical digits are `ZA KI TO MU RE SA FI DU GO PE` = 0–9.
3. `SHI` must have at least one digit on both sides; repeated, leading, or trailing decimal markers are rejected.
4. The terminal unit is one of `MA`, `SE`, `KE`, `RA`, `KU`, or `SHO`.
5. `SHO` yields a dimensionless quantity and may close a binding identifier.
6. In the audit token stream, `KWAM KI SHO TO MU MA` is segmented as binding identifier 1 followed by value 23 MA; `KWAM KI TO SHO MU MA` is identifier 12 followed by value 3 MA. This follows the Phase 4 identifier rule. It is not yet proof that the continuous spoken stream has a verified acoustic boundary; Phase 4 already identifies unit-fall/lengthening as provisional prosody requiring listener testing.
7. Values are stored as exact rational numbers in the test harness, so `ZA SHI TO ZA MA` evaluates to exactly 1/5 MA (0.20 m), not a floating-point approximation.

The harness treats the tokens as already segmented. It does not claim to solve recognition of homophones, coarticulation, prosodic boundaries, or full expression parsing.

## 3. Type consequences

Unit closure tells us the declared unit, but it does not by itself implement dimensional algebra or physical feasibility. The audit maps the canonical units to provisional semantic dimensions:

- `MA` → length
- `SE` → time
- `KE` → mass
- `RA` → angle
- `KU` → temperature
- `SHO` → dimensionless

This mapping is a software-test table, not a new lexicon. `RA` is kept semantically tagged as angle despite the mathematical convention that radians are dimensionless. No conversions between units are introduced because the recovered canonical inventory supplies only one unit per listed dimension. Temperature offsets, derived units, uncertainty, significant-figure propagation, and information/mana dimensions remain outside scope.

## 4. Coordinate-frame contract proposed for implementation

The test harness establishes only general mathematical requirements for a frame-transform implementation:

- A transform must identify source frame and destination frame explicitly.
- A 3×3 orthogonal matrix may represent a rotation or reflection of vector components; its columns/rows must be orthonormal.
- The determinant distinguishes proper rotations (+1) from handedness-changing reflections (−1).
- A transform and its inverse must compose to the identity.
- Orthogonal transforms preserve vector length and dot products.
- A coordinate transform changes representation, not the physical vector or object by itself.
- Positions and displacements must not be conflated. A full affine transform for positions requires an origin/translation term; a free displacement vector does not acquire that translation.
- Cross products are frame-sensitive. The world-frame physical right-hand rule remains the Phase 4 D-017 rule; a left-handed coordinate convention requires the corresponding sign/basis handling. Do not apply a second sign flip if the basis matrix already accounts for handedness.

**Not yet defined:** the actual world-to-caster basis matrix, origin relationship, the exact arguments/signature of `LABU`, whether `FE` is the source frame, destination frame, or frame context, and how frame values are encoded in surface Arcane. Therefore general transforms remain provisional. The test matrices are mathematical fixtures, not canonical worldbuilding constants.

## 5. Test results

19/19 tests passed in the included reference harness:

- 12 numeral/identifier checks: integer and decimal closure, `SHO`, unit classification, malformed numeral rejection, and identifier/value segmentation.
- 7 matrix/vector checks: identity, rotation, reflection, malformed matrix rejection, vector transform, inverse transform, and length preservation.

These results validate only the functions and fixtures in `arcane_phase510_numerals_frames.py`. They are not a compiler test, listener test, or full language validation.

## 6. Decision ledger additions

**D-051 — PROVISIONAL:** use exact rational values for numeral parsing in the audit harness; no change to canonical numeral lexemes.

**D-052 — CANONICAL SOURCE RESTATEMENT:** each numeral closes with a unit; `SHO` is dimensionless; binding identifiers are `SHO`-closed numerals. This restates Phase 4 D-019 rather than creating a new rule.

**D-053 — PROVISIONAL:** frame transforms must declare source and destination frames and satisfy orthogonality/inverse checks when represented as pure rotations/reflections. Affine position transforms require a translation component.

**D-054 — UNRESOLVED:** actual `LABU` signature and canonical world/caster/local transform values must be recovered or explicitly decided before the frame subsystem can be locked.

## 7. Recommended Phase 5.11

Build a small typed expression parser around the Phase 2 signatures and Phase 4 numeral boundaries. Start with arithmetic and binding expressions, and reject unknown arity, missing units, type mismatches, and ambiguous parses. Keep Construction Feet and Expression operators separate, then test the compile bridge on more than the single Phase 4 hand-flame example. Do not add vocabulary until the Phase 4/5 lexicon and aliases have been collision-checked.
