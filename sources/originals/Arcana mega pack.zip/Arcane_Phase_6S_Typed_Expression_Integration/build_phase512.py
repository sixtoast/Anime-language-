import csv,json,zipfile,os
from pathlib import Path
base=Path('/mnt/data')
rows=[]
def add(form,gloss,arity,inputs,output,dim,status,source,aliases='',evals='',failure='',notes=''):
 rows.append(dict(form=form,gloss=gloss,arity=arity,inputs=inputs,output=output,dimensional_rule=dim,status=status,source=source,aliases=aliases,evaluation=evals,failure=failure,notes=notes))
# Expression operators: conservative contracts, explicitly provisional where evidence incomplete
add('frapa','add',2,'Quantity[d] × Quantity[d]','Quantity[d]','same dimensions required; unit conversion allowed','CANON form; signature PROVISIONAL','v3.0-L; Phase 2','', 'eager, pure','reject dimension mismatch','Addition is not defined for arbitrary semantic kinds.')
add('fraja','subtract',2,'Quantity[d] × Quantity[d]','Quantity[d]','same dimensions required','RENAMED form; signature PROVISIONAL','Phase 4 §5; v4/v5 lexicon','frata','eager, pure','reject dimension mismatch','Old form retained as alias for source compatibility; canonical output spelling is fraja.')
add('frama','multiply',2,'Quantity[d1] × Quantity[d2]','Quantity[d1·d2]','dimensions multiply','RENAMED form; signature PROVISIONAL','Phase 4 §5; v4/v5 lexicon','fraka','eager, pure','reject unsupported semantic kinds','Old form retained as alias; dimensional algebra required.')
add('frala','divide',2,'Quantity[d1] × Quantity[d2]','Quantity[d1/d2]','dimensions divide; zero denominator invalid','CANON form; signature PROVISIONAL','v3.0-L; Phase 2','', 'eager, pure','division by zero rejects','Dimensionless ratio is possible when dimensions cancel.')
add('frasha','negate',1,'Numeric quantity or numeric scalar','Same type as input','preserve dimensions','CANON form; signature PROVISIONAL','v3.0-L; Phase 2','', 'eager, pure','reject non-numeric input','Do not confuse with negative-number marker if grammar gives it a distinct role.')
add('dran','magnitude',1,'Vector with defined norm','Scalar magnitude','output carries input vector dimension','CANON form; signature PROVISIONAL','v3.0-L; Phase 2','', 'eager, pure','reject unsupported vector/kind','Norm and metric/frame assumptions need formal definition.')
add('drem','dot product',2,'Vector[d1, frame] × Vector[d2, same frame]','Scalar','dimensions multiply','CANON form; signature PROVISIONAL','v3.0-L; Phase 2','', 'eager, pure','reject frame mismatch','Coordinate-frame metric assumptions need definition.')
add('drum','cross product',2,'Vector[d1, frame] × Vector[d2, same frame]','Vector[d1·d2, frame]','dimensions multiply','RENAMED form; signature PROVISIONAL','Phase 4 §5; v4/v5 lexicon','drim','eager, pure','reject non-3D or frame mismatch','Handedness convention must be specified by frame.')
add('dras','compare',3,'Comparable × Comparable × RelationCriterion','Boolean','values must be comparable under declared relation','RENAMED form; signature PROVISIONAL','Phase 4 §5; v4/v5 lexicon','dral','eager, pure','reject missing/invalid criterion or incompatible values','Relation values proposed in Phase 4 remain PROPOSED until accepted.')
add('nes','read',1,'AvailableInformationReference','RetrievedInformation','no new information without a physical/source pathway','CANON form; signature OPEN','v3.0-L; Phase 2','', 'retrieve referenced available information','reject unavailable/out-of-scope reference','Does not measure or infer.')
add('sima','measure',2,'TargetProperty × MeasurementPathway','Observation','observation records uncertainty/resolution and provenance','CANON form; signature OPEN','v3.0-L; Phase 2','', 'acquisition event; sampling policy must be explicit','reject absent pathway/sensor/context','Conceptually requires target/property, interaction, sensor, resolution and available information; surface arity unresolved.')
add('gama','assign',2,'BindingOrSymbolicDestination × Value','Assignment/UpdatedSymbolicState','no direct physical effect','CANON form; signature PROVISIONAL','v3.0-L; Phase 2','', 'updates symbolic state only','reject invalid destination/type','ASSIGN ≠ CAUSE.')
add('dave','infer',2,'Evidence × InferenceModel','HypothesisOrInferredValue','uncertainty/provenance should be retained','CANON form; signature OPEN','v3.0-L; Phase 2','', 'inference under model','reject missing evidence/model','Inference is not guaranteed truth.')
add('kwam','bind',2,'DimensionlessIdentifier × Expression','BindingDeclaration','identifier ends in SHO under Phase 4 G-2','CANON form; signature PROVISIONAL','v3.0-L; Phase 2; Phase 4 G-2','', 'declare binding in scope','reject duplicate/invalid identifier or invalid expression','Creates a symbolic binding, not a physical object.')
add('kwat','reference binding',1,'DimensionlessIdentifier','BoundValueOrExpression','preserves referenced value type','CANON form; signature PROVISIONAL','v3.0-L; Phase 2; Phase 4 G-2','', 'retrieve binding from scope','reject unbound/out-of-scope identifier','')
add('kwash','live evaluation',1,'LiveExpressionOrReference','CurrentValue','preserves expression type and units','RENAMED form; signature OPEN','Phase 4 §5; v4/v5 lexicon','kwak','sampling/evaluation timing must be defined','reject stale/missing context or failed expression','Old form retained as alias; continuous/repeated sampling semantics unresolved.')
add('gran','AND',2,'Boolean × Boolean','Boolean','not applicable','CANON form; signature PROVISIONAL','v3.0-L; Phase 2','', 'short-circuit policy unresolved','reject non-Boolean inputs','Binary only unless a separate n-ary rule is accepted.')
add('grat','OR',2,'Boolean × Boolean','Boolean','not applicable','CANON form; signature PROVISIONAL','v3.0-L; Phase 2','', 'short-circuit policy unresolved','reject non-Boolean inputs','Binary only unless a separate n-ary rule is accepted.')
add('grash','NOT',1,'Boolean','Boolean','not applicable','RENAMED form; signature PROVISIONAL','Phase 4 §5; v4/v5 lexicon','grak','eager Boolean negation','reject non-Boolean input','Canonical formal form is grash; grak retained as alias.')
add('bek','IF',2,'Condition × Block','ControlExpression/ExecutionResult','not applicable','CANON lexical form; signature OPEN','v3.0-L; Phase 2; Phase 4 G-5/G-6','', 'condition evaluated before block; exact branch/result semantics open','reject non-Boolean condition or malformed block','Phase 4 says blocks use BEGIN/METO and END/DOGU; not just two arbitrary arguments.')
add('zet','WHILE',2,'Condition × Block','ControlExpression/ExecutionResult','not applicable','CANON lexical form; signature OPEN','v3.0-L; Phase 2; Phase 4 G-5/G-6','', 're-evaluate condition each iteration; sampling/timing/termination need constraints','reject malformed block or invalid condition','')
# construction verbs/macros
for f,g in [('kren','establish'),('trak','alter'),('frem','maintain'),('shren','release'),('bran','couple'),('vare','prefer')]:
 add(f,g,'macro/foot-defined','Construction-system typed operands; exact signature not recovered','Construction/constraint result','subject to construction mechanism and feasibility','CANON lexical form; macro contract OPEN','Magic v3.0 §26; Phase 4 §3.2','', 'must expand to valid v2.0 Foot/construction','reject expansion that lacks valid construction','These are not ordinary arithmetic operators; their exact foot mappings must be recovered from v2.0 before locking.')
# audit additions from phase 4 (not accepted as canonical)
for f,g,arity,inputs,out in [
 ('labu','frame transform','OPEN','Frame × Frame × TransformSpecification','TransformedPositionOrVector'),('shasu','delay','OPEN','TemporalValue × Duration','TemporalValue'),('wela','duration','OPEN','TemporalBlockOrEvent × Duration','ConstrainedBlock'),('vitu','repetition interval','OPEN','DurationOrSchedule','TemporalConstraint'),('showa','deadline','OPEN','EventOrBlock × TimePoint','ConstrainedBlock'),('meto','block open','delimiter','none','BlockBoundary'),('dogu','block close','delimiter','none','BlockBoundary'),('mosha','hard requirement','OPEN','ConditionOrConstraint','Constraint'),('lisho','preserve invariant','OPEN','Block × Invariant','ConstrainedBlock'),('vobi','within tolerance','OPEN','Value × Tolerance','Constraint'),('nadi','equal relation','value','none','RelationCriterion'),('dofa','less-than relation','value','none','RelationCriterion'),('guwi','greater-than relation','value','none','RelationCriterion')]:
 add(f,g,arity,inputs,out,'not defined','PROPOSED; NOT CANON','Phase 4 lexicon draft','', 'not fully specified','reject from executable canonical profile until contract approved','Included for gap tracking only; do not treat as locked.')
# write csv and json
csvp=base/'Arcane_Phase_5_12_Operator_Registry.csv'
with csvp.open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
(base/'Arcane_Phase_5_12_Operator_Registry.json').write_text(json.dumps({'phase':'5.12','status':'PROVISIONAL REGISTRY','authority':'Phase 4 spellings take precedence where a rename is recorded; older forms are aliases, not competing canonical definitions.','operators':rows},indent=2))
# tests: validate inventory and rules
checks=[]
def test(name,cond,detail=''):
 checks.append((name,bool(cond),detail))
forms=[r['form'] for r in rows]
test('unique registry forms',len(forms)==len(set(forms)),f'{len(forms)} entries')
test('renamed subtract canonical form',next(r for r in rows if r['form']=='fraja')['aliases']=='frata')
test('renamed multiply canonical form',next(r for r in rows if r['form']=='frama')['aliases']=='fraka')
test('renamed cross canonical form',next(r for r in rows if r['form']=='drum')['aliases']=='drim')
test('renamed compare canonical form',next(r for r in rows if r['form']=='dras')['aliases']=='dral')
test('renamed NOT canonical form',next(r for r in rows if r['form']=='grash')['aliases']=='grak')
test('renamed live evaluation canonical form',next(r for r in rows if r['form']=='kwash')['aliases']=='kwak')
test('Phase 2 arithmetic operators present',all(x in forms for x in ['frapa','fraja','frama','frala','frasha']))
test('Phase 2 info operators present',all(x in forms for x in ['nes','sima','gama','dave']))
test('binding operators present',all(x in forms for x in ['kwam','kwat','kwash']))
test('logic operators present',all(x in forms for x in ['gran','grat','grash','bek','zet']))
test('construction verbs reconciled',all(x in forms for x in ['kren','trak','frem','shren','bran','vare']))
test('all entries include source and status',all(r['source'] and r['status'] for r in rows))
test('proposed Phase 4 items not mislabeled canon',all(next(r for r in rows if r['form']==x)['status'].startswith('PROPOSED') for x in ['labu','shasu','wela','vitu','showa','meto','dogu','mosha','lisho','vobi','nadi','dofa','guwi']))
test('assignment explicitly non-causal','ASSIGN ≠ CAUSE' in next(r for r in rows if r['form']=='gama')['notes'])
test('binding explicitly symbolic','not a physical object' in next(r for r in rows if r['form']=='kwam')['notes'])
test('SIMA physical pathway required','pathway' in next(r for r in rows if r['form']=='sima')['failure'])
test('DRAL renamed contract points to relation criterion','RelationCriterion' in next(r for r in rows if r['form']=='dras')['inputs'])
test('macro verbs remain unexpanded until v2 recovery',all(next(r for r in rows if r['form']==x)['status'].endswith('OPEN') for x in ['kren','trak','frem','shren','bran','vare']))
(base/'Arcane_Phase_5_12_Test_Results.txt').write_text('\n'.join(('PASS' if ok else 'FAIL')+'\t'+n+(('\t'+d) if d else '') for n,ok,d in checks)+f'\nRESULT: {sum(ok for _,ok,_ in checks)}/{len(checks)} PASS\n')
report='''# Arcane Phase 5.12 — Canonical Operator Registry

**Status: PROVISIONAL REGISTRY; not a canon rewrite.**

## Purpose

Consolidate the Phase 2 signature proposals with Phase 4's renames and the v4/v5 lexicon drafts. This registry is a single audit source for spellings, aliases, arity, types, dimensional behaviour, evaluation, failure conditions, evidence and open questions. It does not pretend that every operator contract has been recovered.

## Source-priority rule

Where Phase 4 explicitly renamed a Phase 2/v3.0-L form, the Phase 4 spelling is the canonical candidate and the earlier form is retained as a source-compatibility alias: `FRATA → FRAJA`, `FRAKA → FRAMA`, `DRIM → DRUM`, `DRAL → DRAS`, `GRAK → GRASH`, and `KWAK → KWASH`. This follows the recovery pack's rule to preserve old forms as aliases unless an inconsistency is demonstrated. Do not emit aliases as canonical spellings in new formal material.

## Core safeguards

- `FRAPA`, `FRAJA`, `FRAMA`, `FRALA`, and `FRASHA` are registry forms for arithmetic, but signatures remain provisional pending complete semantic-kind and dimensional rules.
- `DRAS` requires a relation criterion; Phase 4 relation values (`NADI`, `DOFA`, `GUWI`) are still proposed, not canon.
- `SIMA` requires a physical measurement pathway. Its exact surface arity is unresolved.
- `GAMA` changes symbolic assignment only. Assignment is not physical causation.
- `KWAM` creates a binding, not a physical object. Its identifier is a numeral closed by `SHO` under Phase 4 G-2.
- `KWASH` is the Phase 4 canonical candidate for live evaluation; sampling and evaluation timing remain open.
- `BEK` and `ZET` must be reconciled with Phase 4's block grammar (`METO`/`DOGU`) and condition semantics. Do not use the earlier two-argument sketch to bypass block structure.
- `KREN`, `TRAK`, `FREM`, `SHREN`, `BRAN`, and `VARE` belong to the Construction/Foot layer or its macro bridge. Their exact v2.0 expansion contracts must be recovered before they are marked complete.
- `LABU` and the Phase 4 temporal/constraint roots are tracked as proposed only. Their presence in a draft lexicon is not evidence of canonical acceptance.

## Validation

The accompanying harness checks registry uniqueness, alias reconciliation, required operator coverage, source/status completeness, proposed-vs-canon separation, and key safety invariants. It reports **19/19 checks passed**. These are registry consistency checks, not proof that all signatures are correct, that a compiler exists, or that the spoken forms are distinguishable to listeners.

## Decision ledger

- **D-051 — PROVISIONAL:** Use Phase 4 spellings as canonical candidates for explicitly renamed roots; preserve old spellings as aliases.
- **D-052 — PROVISIONAL:** Keep operator contracts in one machine-readable registry with explicit OPEN/PROVISIONAL status.
- **D-053 — OPEN:** Finalise DRAS relation-criterion encoding and accept/reject the proposed relation roots.
- **D-054 — OPEN:** Recover exact v2.0 Foot/macro contracts for KREN/TRAK/FREM/SHREN/BRAN/VARE.
- **D-055 — OPEN:** Specify block result semantics and evaluation timing for BEK/ZET/KOLE/WEKI/RUKI.
- **D-056 — OPEN:** Determine whether information has a dimension and define the role of VO without guessing.
- **D-057 — OPEN:** Define SIMA sampling/provenance and KWASH repeated evaluation semantics.

## Next phase

Phase 5.13 should not invent more words. It should build a minimal typed abstract syntax tree and a compile-time validator that reads this registry, rejects OPEN signatures in strict mode, and tests full nested expressions against the registry. Keep the construction layer separate from the expression layer until the v2.0 morphology source is fully recovered.
'''
(base/'Arcane_Phase_5_12_Operator_Registry.md').write_text(report)
# include source documents and lexicons in zip
files=[csvp,base/'Arcane_Phase_5_12_Operator_Registry.json',base/'Arcane_Phase_5_12_Operator_Registry.md',base/'Arcane_Phase_5_12_Test_Results.txt',base/'build_phase512.py']
for x in ['Arcane_Language_Audit_Phase_2.docx','Arcane_Language_Audit_Phase_4.docx','Arcane_Language_Audit_Phase_5.docx','Arcane_Lexicon_v4_draft.csv','Arcane_Lexicon_v5_draft.csv']:
 files.append(base/x)
with zipfile.ZipFile(base/'Arcane_Phase_5_12_Operator_Registry_Package.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in files:z.write(p,arcname=p.name)
print(f'{sum(ok for _,ok,_ in checks)}/{len(checks)} checks')
for n,ok,d in checks: print(('PASS' if ok else 'FAIL'),n,d)
