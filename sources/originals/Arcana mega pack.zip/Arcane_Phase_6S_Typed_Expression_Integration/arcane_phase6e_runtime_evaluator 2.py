#!/usr/bin/env python3
"""Arcane Phase 6E: runtime numeric/vector evaluator.
Audit notation only; values are test fixtures, not new Arcane vocabulary or spell execution.
"""
from dataclasses import dataclass
from math import sqrt, isfinite
from typing import Union
from arcane_phase6c_operator_registry import Parser, Atom, Call, Type, Q, BOOL, TypeCheckError, check
from arcane_phase6d_lexicon_bridge import load_lexicon, alias_map, normalise_ast, semantic_id_for_form

class EvaluationError(ValueError): pass
@dataclass(frozen=True)
class Quantity:
    value: float
    dims: tuple
@dataclass(frozen=True)
class Vector:
    components: tuple
    dims: tuple
@dataclass(frozen=True)
class Relation:
    value: str
@dataclass(frozen=True)
class UnitSymbol:
    name: str
Runtime = Union[Quantity, Vector, bool, Relation, UnitSymbol]

# Runtime test environment uses explicit SI-like base units: m, s, kg, K.
ENV = {
 'A': Quantity(2.0,(0,0,0,0)), 'B': Quantity(3.0,(0,0,0,0)), 'A_ZERO': Quantity(0.0,(0,0,0,0)),
 'LEN_A': Quantity(5.0,(1,0,0,0)), 'LEN_B': Quantity(2.0,(1,0,0,0)),
 'TIME_A': Quantity(4.0,(0,1,0,0)), 'MASS_A': Quantity(3.0,(0,0,1,0)),
 'VEL_A': Quantity(6.0,(1,-1,0,0)), 'FORCE_A': Quantity(8.0,(1,-2,1,0)),
 'ENERGY_A': Quantity(12.0,(2,-2,1,0)), 'TEMP_A': Quantity(300.0,(0,0,0,1)),
 'VEC_LEN_A': Vector((3.0,4.0,0.0),(1,0,0,0)),
 'VEC_VEL_A': Vector((1.0,2.0,2.0),(1,-1,0,0)),
 'BOOL_A': True, 'BOOL_FALSE': False,
 'LT': Relation('LT'), 'LE': Relation('LE'), 'EQ': Relation('EQ'),
 'NE': Relation('NE'), 'GE': Relation('GE'), 'GT': Relation('GT'),
 'MA': UnitSymbol('MA'), 'SE': UnitSymbol('SE'),
}

def finite(x, where):
    if not isfinite(x): raise EvaluationError(f'{where}: result is not finite')
    return x

def eval_ast(node, env=None):
    env = ENV if env is None else env
    if isinstance(node, Atom):
        if node.value not in env: raise EvaluationError(f'Unknown runtime symbol: {node.value}')
        return env[node.value]
    op=node.operator; args=[eval_ast(a,env) for a in node.args]
    def arity(n):
        if len(args)!=n: raise EvaluationError(f'{op} expects {n} arguments; got {len(args)}')
    def quantity(x):
        if not isinstance(x,Quantity): raise EvaluationError(f'{op} expects numeric quantities')
        return x
    def vector(x):
        if not isinstance(x,Vector): raise EvaluationError(f'{op} expects vectors')
        if len(x.components)!=3: raise EvaluationError(f'{op} requires 3D vectors')
        return x
    if op in ('FRAPA','FRATA'):
        arity(2); x,y=map(quantity,args)
        if x.dims!=y.dims: raise EvaluationError(f'{op} requires matching dimensions')
        v=x.value+y.value if op=='FRAPA' else x.value-y.value
        return Quantity(finite(v,op),x.dims)
    if op in ('FRAKA','FRALA'):
        arity(2); x,y=map(quantity,args)
        if op=='FRALA' and y.value==0: raise EvaluationError('FRALA division by zero')
        v=x.value*y.value if op=='FRAKA' else x.value/y.value
        dims=tuple(a+b if op=='FRAKA' else a-b for a,b in zip(x.dims,y.dims))
        return Quantity(finite(v,op),dims)
    if op=='FRASHA':
        arity(1); x=quantity(args[0]); return Quantity(finite(-x.value,op),x.dims)
    if op=='DRAN':
        arity(1); x=vector(args[0]); return Quantity(finite(sqrt(sum(c*c for c in x.components)),op),x.dims)
    if op=='DREM':
        arity(2); x,y=map(vector,args)
        return Quantity(finite(sum(a*b for a,b in zip(x.components,y.components)),op),tuple(a+b for a,b in zip(x.dims,y.dims)))
    if op=='DRIM':
        arity(2); x,y=map(vector,args)
        c=(x.components[1]*y.components[2]-x.components[2]*y.components[1], x.components[2]*y.components[0]-x.components[0]*y.components[2], x.components[0]*y.components[1]-x.components[1]*y.components[0])
        return Vector(tuple(finite(v,op) for v in c),tuple(a+b for a,b in zip(x.dims,y.dims)))
    if op=='DRAL':
        arity(3); x,y=map(quantity,args[:2]); r=args[2]
        if x.dims!=y.dims: raise EvaluationError('DRAL requires matching dimensions')
        if not isinstance(r,Relation): raise EvaluationError('DRAL third argument must be a relation criterion')
        return {'LT':x.value<y.value,'LE':x.value<=y.value,'EQ':x.value==y.value,'NE':x.value!=y.value,'GE':x.value>=y.value,'GT':x.value>y.value}[r.value]
    if op in ('GRAN','GRAT'):
        arity(2); x,y=args
        if not isinstance(x,bool) or not isinstance(y,bool): raise EvaluationError(f'{op} expects Boolean values')
        return x and y if op=='GRAN' else x or y
    if op=='GRAK':
        arity(1); x=args[0]
        if not isinstance(x,bool): raise EvaluationError('GRAK expects a Boolean value')
        return not x
    if op in ('BEK','ZET','KWAM','KWAT','KWAK','NES','SIMA','GAMA','DAVE'):
        raise EvaluationError(f'{op} runtime semantics are unresolved; execution blocked')
    raise EvaluationError(f'No runtime evaluator registered for {op}')

def parse_and_eval(source, env=None, aliases=None):
    aliases = alias_map(load_lexicon()) if aliases is None else aliases
    runtime_env = ENV if env is None else env
    ast=normalise_ast(Parser(source).parse(),aliases)
    # Derive a type environment from the exact runtime bindings, preventing the two
    # environments from drifting apart and allowing tests to exercise real runtime errors.
    type_env = {}
    for name, value in runtime_env.items():
        if isinstance(value, Quantity): type_env[name] = Type('Quantity', value.dims)
        elif isinstance(value, Vector): type_env[name] = Type('Vector', value.dims)
        elif isinstance(value, bool): type_env[name] = BOOL
        elif isinstance(value, Relation): type_env[name] = Type('RelationCriterion')
        elif isinstance(value, UnitSymbol): type_env[name] = Type('UnitSymbol')
    check(ast, type_env)
    return eval_ast(ast,runtime_env)

def show(v):
    if isinstance(v,Quantity): return f'{v.value:g} [{v.dims}]'
    if isinstance(v,Vector): return f'vector{v.components} [{v.dims}]'
    return repr(v)

def tests():
    tests=[]
    def add(i,name,fn):
        try: ok,detail=fn()
        except Exception as e: ok,detail=False,f'{type(e).__name__}: {e}'
        tests.append((i,name,'PASS' if ok else 'FAIL',str(detail)))
    def result(src, expected, desc):
        got=parse_and_eval(src)
        return got==expected, f'{src} -> {show(got)}; expected {show(expected) if not isinstance(expected,bool) else expected}'
    def raises(src, needle):
        try: parse_and_eval(src)
        except Exception as e: return needle.lower() in str(e).lower(), f'{type(e).__name__}: {e}'
        return False,'No error raised'
    add('6E-01','Addition evaluates values',lambda:result('FRAPA⟨LEN_A, LEN_B⟩',Quantity(7,(1,0,0,0)),'add'))
    add('6E-02','Subtraction current lexical form FRAJA evaluates',lambda:result('FRAJA⟨LEN_A, LEN_B⟩',Quantity(3,(1,0,0,0)),'subtract'))
    add('6E-03','Multiplication current lexical form FRAMA evaluates',lambda:result('FRAMA⟨LEN_A, LEN_B⟩',Quantity(10,(2,0,0,0)),'multiply'))
    add('6E-04','Division produces velocity dimensions',lambda:result('FRALA⟨LEN_A, TIME_A⟩',Quantity(1.25,(1,-1,0,0)),'divide'))
    add('6E-05','Division by zero rejected at runtime',lambda:raises('FRALA⟨LEN_A, A_ZERO⟩','division by zero'))
    add('6E-06','Negation evaluates numeric value',lambda:result('FRASHA⟨ENERGY_A⟩',Quantity(-12,(2,-2,1,0)),'negation'))
    add('6E-07','Vector magnitude computes 3-4-5 triangle',lambda:result('DRAN⟨VEC_LEN_A⟩',Quantity(5,(1,0,0,0)),'magnitude'))
    add('6E-08','Dot product evaluates component products',lambda:result('DREM⟨VEC_LEN_A, VEC_VEL_A⟩',Quantity(11,(2,-1,0,0)),'dot'))
    add('6E-09','Cross product returns 3D vector',lambda:result('DRUM⟨VEC_LEN_A, VEC_VEL_A⟩',Vector((8,-6,2),(2,-1,0,0)),'cross'))
    add('6E-10','Comparison evaluates true',lambda:result('DRAS⟨LEN_A, LEN_B, GT⟩',True,'compare'))
    add('6E-11','Comparison evaluates false',lambda:result('DRAS⟨LEN_A, LEN_B, LT⟩',False,'compare'))
    add('6E-12','Boolean AND evaluates',lambda:result('GRAN⟨BOOL_A, BOOL_FALSE⟩',False,'and'))
    add('6E-13','Boolean OR evaluates',lambda:result('GRAT⟨BOOL_A, BOOL_FALSE⟩',True,'or'))
    add('6E-14','Boolean NOT current lexical form GRASH evaluates',lambda:result('GRASH⟨BOOL_A⟩',False,'not'))
    add('6E-15','Unknown runtime symbol rejected',lambda:raises('FRAPA⟨LEN_A, MISSING⟩','Unknown symbol'))
    add('6E-16','Incompatible dimensions rejected before evaluation',lambda:raises('FRAPA⟨LEN_A, TIME_A⟩','matching dimensions'))
    add('6E-17','Unresolved conditional remains blocked',lambda:raises('BEK⟨BOOL_A, A⟩','unresolved'))
    add('6E-18','Unit symbol cannot be evaluated as a quantity',lambda:raises('FRAPA⟨MA, SE⟩','expects Quantity'))
    return tests
if __name__=='__main__':
    r=tests()
    for x in r: print(' | '.join(x))
    print(f'RESULT: {sum(x[2]=="PASS" for x in r)}/{len(r)} passed')
