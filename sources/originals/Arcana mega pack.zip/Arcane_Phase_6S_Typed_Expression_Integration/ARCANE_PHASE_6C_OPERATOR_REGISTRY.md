# ARCANE LANGUAGE AUDIT — PHASE 6C
## Operator registry, comparison criteria, and vector dimensional rules

**Status:** Provisional executable audit model. The prototype passes 17/17 listed tests. This is not a production compiler, a validation of spoken Arcane, or automatic promotion of these rules to canon.

## 1. Scope and change control

Phase 6C extends the Phase 6B diagnostic checker. It resolves two concrete implementation defects in the audit scaffold:

1. A three-dimensional cross product (`DRIM`) must return a vector, not a scalar.
2. `DRAL` needs a typed relation criterion and compatible operands to produce a Boolean result.

The audit notation remains `OPERATOR⟨argument₁, argument₂, …⟩`. Names such as `LT`, `LE`, `EQ`, `NE`, `GE`, and `GT` are **meta-level test tokens**, not newly approved Arcane vocabulary. Their spoken or formal Arcane encodings remain undecided.

## 2. Provisional signature registry

| Operator | Proposed audit signature | Result | Status |
|---|---|---|---|
| `FRAPA` | Quantity[d] × Quantity[d] | Quantity[d] | Implemented; dimensional compatibility required |
| `FRATA` | Quantity[d] × Quantity[d] | Quantity[d] | Implemented; dimensional compatibility required |
| `FRAKA` | Quantity[d₁] × Quantity[d₂] | Quantity[d₁+d₂] | Implemented dimensional rule |
| `FRALA` | Quantity[d₁] × Quantity[d₂] | Quantity[d₁−d₂] | Implemented dimensional rule; runtime zero check absent |
| `FRASHA` | Quantity[d] | Quantity[d] | Implemented |
| `DRAN` | Vector[d] | Quantity[d] | Implemented provisionally; supported vector spaces/norm remain to be specified |
| `DREM` | Vector[d₁] × Vector[d₂] | Quantity[d₁+d₂] | Implemented provisionally |
| `DRIM` | 3D Vector[d₁] × 3D Vector[d₂] | 3D Vector[d₁+d₂] | Implemented dimensional result; explicit 3D shape is not yet enforced by the prototype |
| `DRAL` | Quantity[d] × Quantity[d] × RelationCriterion | Boolean | Implemented for audit criteria; criterion tokens are not canonical Arcane forms |
| `GRAN` | Boolean × Boolean | Boolean | Implemented |
| `GRAT` | Boolean × Boolean | Boolean | Implemented |
| `GRAK` | Boolean | Boolean | Implemented |
| `SIMA` | Target/property/pathway/sensor/resolution information | Observation | Blocked; exact argument encoding unresolved |
| `NES` | Available-information reference | Retrieved information | Blocked; scope/access rules unresolved |
| `GAMA` | Destination/reference × value | Symbolic assignment | Blocked; environment and scope semantics unresolved |
| `DAVE` | Evidence × inference model/rule | Hypothesis/inferred value | Blocked; uncertainty and model typing unresolved |
| `KWAM` | Binding identifier × expression | Binding declaration | Blocked; identifier and scope rules unresolved |
| `KWAT` | Binding identifier | Bound value/expression | Blocked in Phase 6C; lookup and validity rules unresolved |
| `KWAK` | Live expression/reference | Current evaluated value | Blocked; sampling/evaluation timing unresolved |
| `BEK` | Conditional control | Control expression | Blocked; branch structure and evaluation semantics unresolved |
| `ZET` | Repeated control | Control expression | Blocked; termination, timing and invariants unresolved |

Here `d` denotes a dimension exponent vector. In this prototype the basis is length, time, mass and temperature: `(L,T,M,Θ)`. The dimensional arithmetic is an audit convenience, not a complete physical unit system.

## 3. DRAL criteria

The prototype accepts these audit-only relation criteria:

- `LT`: less than
- `LE`: less than or equal to
- `EQ`: equal to
- `NE`: not equal to
- `GE`: greater than or equal to
- `GT`: greater than

`DRAL` checks that both operands are quantities of matching dimensions and that the third argument is a `RelationCriterion`, then returns `Boolean`. This phase checks typing only; it does **not** evaluate numeric values or implement tolerance rules for measurements. The actual Arcane representations of these criteria are unresolved.

## 4. DRIM dimensional result

For input vectors whose components have dimensions `d₁` and `d₂`, the cross-product components have dimensions `d₁+d₂`. The output is a vector. The current prototype checks the vector category and dimensional tuple but does not encode a distinct vector-space shape, coordinate frame, handedness convention, or orientation metadata. Those details must be added before treating the signature as complete.

## 5. Test results

| Test | Result | Purpose |
|---|---|---|
| 6B-01 | PASS | Addition preserves compatible dimensions |
| 6B-02 | PASS | Length plus time rejected |
| 6B-03 | PASS | Length × length yields area dimension |
| 6B-04 | PASS | Length ÷ time yields velocity dimension |
| 6B-05 | PASS | Negation preserves dimensions |
| 6B-06 | PASS | Unit symbols are not quantity values |
| 6B-07 | PASS | Incorrect fixed arity rejected |
| 6B-08 | PASS | Unknown symbol rejected |
| 6B-09 | PASS | Unresolved DAVE remains blocked |
| 6B-10 | PASS | Boolean AND returns Boolean |
| 6B-11 | PASS | Boolean/numeric mismatch rejected |
| 6B-12 | PASS | Dot-product dimensions combine |
| 6C-13 | PASS | Cross product returns a vector category |
| 6C-14 | PASS | Typed comparison returns Boolean |
| 6C-15 | PASS | Comparison of incompatible dimensions rejected |
| 6C-16 | PASS | Invalid comparison criterion type rejected |
| 6C-17 | PASS | IF semantics remain blocked rather than guessed |

**Result: 17/17 prototype tests passed.** A pass means the code behaved as expected for that test, including deliberately blocking incomplete semantics. It does not mean all listed operators are implemented or the language is complete.

## 6. Known limitations

- `DRIM` does not yet enforce three-component vectors, coordinate frames, or handedness.
- `DRAN`'s supported norms and input spaces are not canonically specified.
- Numeric values are not evaluated; this is a type checker, not an interpreter.
- Unit conversion, scale factors, affine units, angle semantics and conversion errors are absent.
- `FRALA` does not yet check a numeric zero denominator.
- `DRAL` criterion tokens are diagnostic placeholders, not lexical decisions.
- `SIMA`, `NES`, `GAMA`, `DAVE`, `KWAM`, `KWAT`, `KWAK`, `BEK`, and `ZET` are not silently assigned incomplete semantics.
- Parsing and typing do not establish physical feasibility or spoken-surface uniqueness.

## 7. Recommended Phase 6D

1. Add value-level evaluation separately from type checking.
2. Define a typed representation for vector dimension, coordinate frame and component count; enforce the 3D precondition for `DRIM`.
3. Define unit conversion and dimensionless/angle policies.
4. Specify `KWAM`/`KWAT`/`KWAK` environment, scope, liveness and errors.
5. Specify `BEK` and `ZET` control-flow semantics, including termination guarantees and failure behaviour.
6. Validate Formal-to-Construction compilation against recovered Phase 4 examples without changing the existing morphology.

## 8. Required pipeline boundary

`parse → type-check → resolve references/bindings → compile Construction representation → physical feasibility-check → execute → observe/feedback`

Each stage must report its own failures. A successful parse or type check must never be reported as a successful spell.
