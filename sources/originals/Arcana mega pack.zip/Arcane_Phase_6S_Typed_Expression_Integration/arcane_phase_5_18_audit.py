#!/usr/bin/env python3
"""Phase 5.18: reproducible static audit of Phase 5 vernacular examples and merged lexicon.
This is a source-audit harness, not a full Arcane parser or a canon change.
"""
import ast, csv, json, sys
from collections import defaultdict
from pathlib import Path

BASE = Path(__file__).resolve().parent
LEX = Path(sys.argv[1]) if len(sys.argv) > 1 else BASE / 'Arcane_Lexicon_v5_draft.csv'
SRC = Path(sys.argv[2]) if len(sys.argv) > 2 else BASE / 'phase5_vernacular.py'

with LEX.open(encoding='utf-8-sig', newline='') as f:
    rows = list(csv.DictReader(f))
source = SRC.read_text(encoding='utf-8')
tree = ast.parse(source)

def assignment(name):
    for node in tree.body:
        if isinstance(node, (ast.Assign, ast.AnnAssign)):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            if any(isinstance(t, ast.Name) and t.id == name for t in targets):
                try: return ast.literal_eval(node.value)
                except Exception: return None
    return None

# Extract the concept keys from literal cl(..., [...]) declarations.
concept_keys = set()
for node in ast.walk(tree):
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'cl' and len(node.args) >= 3:
        try:
            items = ast.literal_eval(node.args[2])
            concept_keys.update(k for k, _ in items)
        except Exception:
            pass
shared = assignment('SHARED') or {}
alias = assignment('ALIAS') or {}
sentences = assignment('S') or []
idioms = assignment('IDIOMS') or []

results=[]
def add(test, status, detail, severity='blocking'):
    results.append({'test':test,'status':status,'detail':detail,'severity':severity})

# Required CSV columns and entry completeness.
required={'form','gloss','cls','register','status','source','note'}
missing_cols=required-set(rows[0].keys()) if rows else required
add('P5.18-01 CSV schema', 'PASS' if not missing_cols else 'FAIL',
    f'{len(rows)} rows; missing columns: {sorted(missing_cols)}')
empty=[i+2 for i,r in enumerate(rows) if not r.get('form','').strip() or not r.get('gloss','').strip()]
add('P5.18-02 Lexical entry completeness','PASS' if not empty else 'FAIL',
    f'{len(empty)} entries missing form/gloss; CSV line numbers: {empty[:30]}')

# Duplicate forms are reported with context; current two duplicates are source-backed cross-register forms.
by_form=defaultdict(list)
for r in rows: by_form[r.get('form','').strip().lower()].append(r)
dups={k:v for k,v in by_form.items() if k and len(v)>1}
intentional={'re','ra'}
unexpected={k:v for k,v in dups.items() if k not in intentional}
detail=[]
for form, entries in sorted(dups.items()):
    detail.append(form+': '+' | '.join(f"{e['gloss']} ({e['cls']}, {e['register']}, {e['status']}, source={e['source']})" for e in entries))
add('P5.18-03 Homograph inventory','PASS' if not unexpected and set(dups)<=intentional else 'FAIL',
    f'{len(dups)} duplicated spellings; {len(unexpected)} outside the documented review set. ' + '; '.join(detail),
    'review' if dups and not unexpected else 'blocking')

# A homograph is not deemed safe merely because it has two registers; enforce an explicit register gate.
for form in sorted(dups):
    regs={r['register'] for r in dups[form]}
    statuses={r['status'] for r in dups[form]}
    add(f'P5.18-04-{form} Register separation', 'BLOCKED',
        f'{form!r} appears in registers {sorted(regs)} with statuses {sorted(statuses)}. Safety requires a normative rule preventing mixed-register executable parsing and a test showing it is enforced; CSV labels alone do not prove this.')

# Static audit of keys used in example sentence fixtures.
import re
# The Phase 5 source builds part of its key inventory dynamically (for example,
# cl("V", ..., [(k, k.lower()) for k in [...]]), so supplement AST extraction
# with literal uppercase concept keys and known lower-case closed-class tokens.
concept_source=source.split('GL =',1)[0]
source_keys=set(re.findall(r'\"([A-Z][A-Z0-9_-]*)\"', concept_source))
known=concept_keys | set(shared) | set(alias) | source_keys | {'·','not','and','if','before','now','2'}
unknown=[]
for name, keys, english in sentences:
    for key in keys:
        if key not in known:
            unknown.append({'sentence':name,'key':key,'english':english})
add('P5.18-05 Sentence fixture key coverage','PASS' if not unknown else 'FAIL',
    f'{len(sentences)} sentence fixtures; {len(unknown)} unresolved keys: '+json.dumps(unknown,ensure_ascii=False))

# Ensure every referenced shared/alias mapping has a resolvable target in the merged lexicon or concept keys.
forms={r['form'].strip().lower() for r in rows}
missing_shared={k:v for k,v in shared.items() if str(v).lower() not in forms}
add('P5.18-06 Shared vocabulary targets','PASS' if not missing_shared else 'FAIL',
    f'{len(missing_shared)} shared mappings do not point to a lexicon form: {missing_shared}')

# Check source has all named fixture arrays and the declared seed is stable, but do not assert listener quality.
idiom_count = len(re.findall(r'\(\"(?:Old news|Up to date|All talk|Hard to judge|Out of energy)\"', source))
add('P5.18-07 Source fixture availability','PASS' if sentences and idiom_count == 5 and concept_keys else 'FAIL',
    f'{len(concept_keys)} AST-extracted concept keys (partial due dynamic declarations); {len(sentences)} sentence fixtures; {idiom_count} idiom fixtures.')
add('P5.18-08 Naturalness / listener comprehension','NOT TESTED',
    'Cannot be established by static source checks. Requires speakers/listeners and a recorded protocol.')
add('P5.18-09 Spoken unique-parse validation','BLOCKED',
    'No complete parser, authoritative register-switching rule, or spoken-boundary specification is present in this source package.')

counts={s:sum(x['status']==s for x in results) for s in ('PASS','FAIL','BLOCKED','NOT TESTED')}
report={'title':'Arcane Phase 5.18 static audit','input_lexicon':LEX.name,'input_source':SRC.name,'counts':counts,'results':results,
        'decision':'DO NOT MARK PHASE 5 COMPLETE: source fixture contains unresolved lexical references and register/homograph enforcement remains unproven.'}
out=BASE/'Arcane_Phase_5_18_Results.json'
out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for x in results: print(f"{x['status']:10} {x['test']}: {x['detail']}")
print('COUNTS',json.dumps(counts))
print('RESULTS',out)
if counts['FAIL']: sys.exit(1)
