# Arcane Phase 5.17 — Construction Grammar Test Harness

**Status:** first executable baseline; not a complete parser and not a canon revision.  
**Input:** `Arcane_Lexicon_v5_draft.csv` from the supplied Arcana pack.  
**Purpose:** turn recovered, evidence-backed rules into reproducible checks while refusing to invent missing v2.0 morphology.

## Results

The test runner executes 13 checks. It distinguishes **PASS**, **FAIL**, **BLOCKED BY MISSING SPECIFICATION**, and **NOT YET TESTED**. Blocked and untested checks are never counted as passes.

The current run reports:

- **3 PASS** — form/gloss completeness, status provenance present, documented digit spellings present.
- **1 FAIL** — duplicate spellings exist in the combined lexicon.
- **6 BLOCKED** — reference persistence/replacement, Construction ordering, Foot morphology, canonical h-coupling mapping, expression-level numeral/unit validation.
- **3 NOT YET TESTED** — complete hand-flame typing/feasibility, physical mechanism/conservation checks, vernacular parser/listener validation.

See `Arcane_Phase_5_17_Test_Results.json` for the complete machine-readable run.

## Concrete finding: two homographs

The combined Phase 5 lexicon contains two duplicated forms:

| Form | Entry A | Entry B | Risk |
|---|---|---|---|
| `re` | `4` — DIGIT, Shared, CANON | `TARGET-surface` — FUSED-REF, Performed, CANON (v2.0) | In a performed sequence, an isolated `re` could be read as the digit or fused reference unless position/context is formally defined and enforced. |
| `ra` | `radian` — UNIT, Shared, CANON | `TARGET-path` — FUSED-REF, Performed, CANON (v2.0) | A quantity/unit position may help distinguish these, but this has not been demonstrated by a complete parser. |

These may be intended cross-system homographs, not necessarily errors. **Do not rename either form yet.** The safe next step is to record the intended register/slot restrictions and test them against actual valid Construction examples. If the same surface sequence remains ambiguous in a legal context, then a rename or explicit disambiguation rule is required. Existing forms should remain aliases if changed, per the project's rename policy.

## What the harness can and cannot establish

It can check exact CSV properties and assert that documented forms are present. It cannot currently parse a whole spell because the supplied recovery pack lacks a complete executable grammar, full original v2.0 morphology, definitive Foot inventories, and canonical parameter/coupling maps.

The Phase 4 specification itself labels parameter-vowel and `h`-coupling maps **PROVISIONAL**. The harness therefore blocks tests that would otherwise quietly elevate them to canon. Likewise, the hand-flame example remains tokenised and partially structured, but not proven well-typed or physically feasible.

## Phase 5.17 recommendation

1. Resolve the two homographs by specifying their legal register/slot contexts; do not change spelling without evidence.
2. Recover the missing v2.0 morphology and examples, or explicitly author a new owner-approved replacement spec rather than pretending recovery succeeded.
3. Create a small, explicit grammar fixture corpus: valid and invalid examples for reference persistence, scope replacement, Foot structure, ordering, unit closure and release.
4. Implement a parser only after those token classes and boundaries are authoritative.
5. Keep syntax/type validation separate from physical feasibility and listener testing.

## Exit status

The current harness exits non-zero because the duplicate spellings are a demonstrated lexicon-level issue requiring adjudication. This is intentional: it prevents a green build from implying the language is ready when a concrete ambiguity risk remains.
