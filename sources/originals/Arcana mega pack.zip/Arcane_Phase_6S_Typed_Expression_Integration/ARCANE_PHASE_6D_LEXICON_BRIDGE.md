# ARCANE LANGUAGE AUDIT — PHASE 6D
## Lexicon-to-operator reconciliation

**Status:** Provisional integration audit. This phase reconciles the typed checker’s abstract operator IDs with the actual Phase 4/5 lexicon. It does not promote proposed lexicon entries or incomplete semantics to canon.

## 1. Why this phase was necessary

The Phase 6C checker uses the abstract names inherited from v3.0-L, including `FRATA`, `FRAKA`, `DRIM`, `DRAL`, `GRAK`, and `KWAK`. The recovered Phase 4/5 lexicon records renames:

| Semantic operator ID used by the checker | Current Phase 4/5 form | Earlier form retained as alias |
|---|---|---|
| `FRATA` — subtract | `fraja` | `frata` |
| `FRAKA` — multiply | `frama` | `fraka` |
| `DRIM` — cross product | `drum` | `drim` |
| `DRAL` — compare | `dras` | `dral` |
| `GRAK` — NOT | `grash` | `grak` |
| `KWAK` — live evaluation | `kwash` | `kwak` |

This distinction is crucial: **semantic operator IDs are stable implementation labels; lexicon forms are language forms**. The compiler bridge must not assume they are identical.

## 2. Source-grounded rules

- The Phase 4 report says renamed forms retain old forms as aliases.
- The Phase 5 CSV is the consolidated 255-row lexicon with register and status columns.
- The bridge derives aliases only from explicit `note` entries beginning `was ...`; it does not invent historical forms.
- Lexical presence is not the same as an executable signature. For example, `BEK`, `ZET`, `KWAM`, `KWAT`, and `KWAK` remain semantically blocked where their execution rules are unresolved.
- The `Phase 4/5` spellings are preserved as forms, but their statuses remain those recorded in the lexicon. Proposed entries are not silently promoted.

## 3. Test results

The accompanying script checks the 255-row inventory, verifies semantic-ID-to-form mappings, recovers explicit rename aliases, checks alias targets exist, normalises current lexical forms into stable semantic IDs in the AST, and type-checks representative expressions written with the current Phase 4/5 forms. It also asserts that having a lexicon entry does not itself unblock incomplete execution semantics.

**Expected regression suite: 16 tests.** Run:

```bash
python arcane_phase6d_lexicon_bridge.py
```

This is a static integration check. It is not a spoken parser, listener study, full compiler, or physical spell feasibility test.

## 4. Architecture after reconciliation

`surface form → lexical lookup/alias normalisation → semantic operator ID → parse → type-check → resolve bindings → Construction compilation → physical feasibility → execution → observation/feedback`

Alias normalisation must happen before operator dispatch, while preserving the source form for diagnostics and historical records. A warning can note when a legacy alias was used, but the alias remains accepted as Phase 4 specified.

## 5. Issues this phase does not resolve

1. The full parser still uses audit notation rather than the actual Formal/Performed surface grammar.
2. The Construction bridge remains validated only by the Phase 4 hand-flame tokenisation example; complete Formal-to-Construction compilation is not established.
3. The dimension system lacks information/mana dimensions, unit scale factors, affine units, and a full angle policy.
4. Vector shape and coordinate frame are not enforced by the Phase 6C type object.
5. `BEK`, `ZET`, `KWAM`, `KWAT`, `KWASH`, `SIMA`, `NES`, `GAMA`, and `DAVE` need operational definitions before execution.
6. Proposed Phase 4 time/set/control words need status-aware signatures and must not be treated as canon solely because they appear in the lexicon.

## 6. Change-control decision

**Decision:** Adopt a two-name implementation model for the audit tooling: stable semantic IDs for operator rules, and lexicon spellings (including explicit legacy aliases) for language-facing lookup. This is an integration decision for tooling, not a new Arcane linguistic rule. The canonical spelling/status of each entry continues to be governed by the Phase 4/5 lexicon and decision ledger.

## 7. Next phase

Phase 6E should implement a small value evaluator for numeric quantities and vectors, while using the reconciled names. It should define explicit runtime errors (division by zero, missing binding, invalid vector shape, incompatible frames) and keep runtime evaluation separate from type checking and physical feasibility.
