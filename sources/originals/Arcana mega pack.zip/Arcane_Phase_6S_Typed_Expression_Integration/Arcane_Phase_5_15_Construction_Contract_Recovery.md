# Arcane Phase 5.15 — Construction Contract Recovery Matrix

**Status:** source-recovery audit; no canon promoted and no spell execution enabled.

## Purpose

Phases 5.10–5.14 built useful audit prototypes, but the full construction system is the principal blocker to an end-to-end compiler. This phase extracts only what the recovered Phase 2 and Phase 4 documents actually support, distinguishes structural rules from provisional semantics, and records the missing evidence.

## Key findings

1. Phase 4 defines a two-subsystem architecture: Construction (Feet, couplings, scoped references) and Expression (typed operators for values, targets, conditions and timing).
2. The construction ordering is stated as **reference → spatial role/vector → Feet → couplings → quantity → control → release**. This is an order statement, not a complete grammar.
3. A Foot is described as **frame + parameter vowel + relation coda**, with CVC shape. The Phase 4 lexical legality tests support shape checking, not full semantic execution.
4. Parameter-vowel mappings and h-domain coupling mappings are explicitly provisional. They must not be treated as locked physics.
5. KREN is explicitly proposed and needs owner confirmation. TRAK/BRAN are described more clearly, but their complete expansion contracts remain unavailable. FREM and SHREN appear in a worked example, which is not enough to establish all general cases. VARE is described as a soft-requirement modifier, but its conflict/failure semantics remain open.
6. The hand-flame sequence is tokenised but not fully specified: Phase 4 explicitly leaves energy magnitude, extent and matter coupling parameters unspecified and says no whole-spell grammar parse or feasibility test was run. It is therefore not a valid end-to-end demonstration.
7. The supplied recovery pack does not contain a standalone complete v2.0 construction specification. The exact full coda mapping, h-coupling contracts, MEL landmark anchoring and complete KAN/KEN/KAS rules remain source gaps.

## Safe implementation boundary

The current safe boundary is a **construction token/shape audit and evidence registry**. It is not safe to compile a typed AST into executable Feet or to claim a spell is physically feasible. The bridge should remain blocked until the source grammar is recovered or replaced by an explicit, owner-approved specification with distinguishing tests.

## Next action

Recover the missing v2.0 specification from the original chat/source files if available. If it cannot be recovered, create a separate proposed replacement spec (not a silent reconstruction), obtain explicit owner approval, and test it against the Phase 4 hand-flame example plus positive/negative cases for each Foot family, coupling domain, reference anchor and release path.

## Evidence matrix

See `Arcane_Phase_5_15_Construction_Contract_Matrix.csv` for item-level source, status, executable boundary and gaps.

## Decision ledger additions

- **D-059 — SOURCE GAP:** full original v2.0 morphology is not present in the recovered source pack; do not fabricate it.
- **D-060 — BOUNDARY:** construction order is documented, but does not by itself define a parseable complete grammar.
- **D-061 — PROVISIONAL:** parameter-vowel and h-domain mappings remain provisional as explicitly labelled in Phase 4.
- **D-062 — BLOCKED:** no AST-to-Construction compiler or spell-execution claim until the construction grammar and bridge are source-backed or explicitly owner-approved.
