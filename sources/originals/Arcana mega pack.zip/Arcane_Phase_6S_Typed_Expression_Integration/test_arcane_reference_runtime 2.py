import unittest
from decimal import Decimal
from arcane_reference_runtime import (run, parse, show_ast, ArcaneArityError,
    ArcaneParseError, ArcaneTypeError, ArcaneEvaluationError)

class ReferenceRuntimeTests(unittest.TestCase):
    def test_frpa_binary_addition(self): self.assertEqual(run('(frapa 2 3)'), Decimal('5'))
    def test_fraja_operand_order(self):
        self.assertEqual(run('(fraja 9 4)'), Decimal('5'))
        self.assertEqual(run('(fraja 4 9)'), Decimal('-5'))
    def test_nested_grouping_changes_tree_and_result(self):
        a=parse('(fraja 2 (frapa 3 4))')
        b=parse('(frapa (fraja 2 3) 4)')
        self.assertNotEqual(show_ast(a), show_ast(b))
        self.assertEqual(run('(fraja 2 (frapa 3 4))'), Decimal('-5'))
        self.assertEqual(run('(frapa (fraja 2 3) 4)'), Decimal('3'))
    def test_rejects_missing_binary_arg(self):
        with self.assertRaises(ArcaneArityError): parse('(frapa 2)')
    def test_rejects_extra_binary_arg(self):
        with self.assertRaises(ArcaneArityError): parse('(frapa 1 2 3)')
    def test_frasha_negates_positive(self): self.assertEqual(run('(frasha 5)'), Decimal('-5'))
    def test_frasha_negates_negative(self): self.assertEqual(run('(frasha -5)'), Decimal('5'))
    def test_frasha_zero(self): self.assertEqual(run('(frasha 0)'), Decimal('0'))
    def test_boolean_and(self): self.assertIs(run('(gran true false)'), False)
    def test_boolean_or(self): self.assertIs(run('(grat true false)'), True)
    def test_boolean_not(self): self.assertIs(run('(grash false)'), True)
    def test_rejects_numeric_boolean_mismatch(self):
        with self.assertRaises(ArcaneTypeError): run('(gran true 1)')
    def test_rejects_boolean_arithmetic(self):
        with self.assertRaises(ArcaneTypeError): run('(frapa true 1)')
    def test_rejects_unknown_operator(self):
        with self.assertRaises(ArcaneParseError): parse('(kole true)')
    def test_rejects_division_by_zero(self):
        with self.assertRaises(ArcaneEvaluationError): run('(frala 2 0)')
    def test_rejects_trailing_expression(self):
        with self.assertRaises(ArcaneParseError): parse('(frapa 1 2) 3')

if __name__=='__main__': unittest.main(verbosity=2)
