#!/usr/bin/env python3
"""Arcane Phase 5.17 — evidence-bounded Construction test harness.

This deliberately does NOT pretend to parse or validate a complete spell. It tests
only rules that can be mechanically checked from the supplied Phase 4/5 lexicon
and the documented Construction contract. Unknown morphology is BLOCKED, not guessed.
Usage: python arcane_phase_5_17_harness.py [path/to/Arcane_Lexicon_v5_draft.csv]
"""
from __future__ import annotations
import csv, json, re, sys
from collections import Counter
from pathlib import Path

DEFAULT = Path(__file__).with_name('Arcane_Lexicon_v5_draft.csv')
STATUS = {'PASS':'PASS', 'FAIL':'FAIL', 'BLOCKED':'BLOCKED BY MISSING SPECIFICATION', 'NOT_TESTED':'NOT YET TESTED'}

class Test:
    def __init__(self, code, name, status, detail, evidence):
        self.code, self.name, self.status, self.detail, self.evidence = code, name, status, detail, evidence
    def as_dict(self):
        return {'id':self.code,'test':self.name,'status':STATUS[self.status],'detail':self.detail,'basis':self.evidence}

def load(path):
    with open(path, newline='', encoding='utf-8-sig') as f:
        rows = list(csv.DictReader(f))
    if not rows: raise ValueError('Lexicon CSV is empty')
    required = {'form','gloss','cls','status','source'}
    missing = required - set(rows[0])
    if missing: raise ValueError('Missing required CSV columns: '+', '.join(sorted(missing)))
    return rows

def run(path):
    rows = load(path)
    tests=[]
    forms=[r['form'].strip() for r in rows]
    nonempty=[x for x in forms if x]
    duplicates={f:n for f,n in Counter(nonempty).items() if n>1}
    duplicate_detail=[]
    for spelling, count in sorted(duplicates.items()):
        entries=[f"{r.get('gloss','')} [{r.get('cls','')}; {r.get('register','shared')}; {r.get('status','')}]" for r in rows if r.get('form','').strip()==spelling]
        duplicate_detail.append(f"{spelling}: "+' vs '.join(entries))
    tests.append(Test('P5.17-L01','Homographs are either disambiguated by a proven grammar or explicitly approved','FAIL' if duplicates else 'PASS',
      f'{len(nonempty)} non-empty entries; {len(duplicates)} duplicated spellings'+(('; '+'; '.join(duplicate_detail)) if duplicates else ''),
      'Direct exact-string check of the supplied Phase 5 lexicon CSV. Duplicate forms may be intentional, but no executable grammar test currently proves contextual disambiguation.'))
    blank=[i+2 for i,r in enumerate(rows) if not r.get('form','').strip() or not r.get('gloss','').strip()]
    tests.append(Test('P5.17-L02','Lexicon form and gloss are populated','FAIL' if blank else 'PASS',
      f'{len(blank)} rows missing form or gloss'+(f'; CSV lines {blank[:20]}' if blank else ''),
      'Direct CSV completeness check; does not validate meaning.'))
    statuses=Counter((r.get('status') or '').strip() for r in rows)
    tests.append(Test('P5.17-L03','Lexicon status provenance remains visible','PASS' if all((r.get('status') or '').strip() for r in rows) else 'FAIL',
      'Status counts: '+json.dumps(dict(statuses),ensure_ascii=False,sort_keys=True),
      'Checks only that each entry declares a status; does not promote proposals to canon.'))
    # Exact canonical numeral and unit forms explicitly listed in v3.0-L / Phase 4.
    by_gloss={}
    for r in rows: by_gloss.setdefault(r['gloss'].strip().lower(), []).append(r['form'].strip())
    expected={'0':'za','1':'ki','2':'to','3':'mu','4':'re','5':'sa','6':'fi','7':'du','8':'go','9':'pe'}
    mismatches=[]
    for gloss, form in expected.items():
        found=by_gloss.get(gloss,[])
        if form not in found: mismatches.append(f'{gloss}: expected {form}, found {found or "<missing>"}')
    tests.append(Test('P5.17-N01','Canonical digit spellings are present','FAIL' if mismatches else 'PASS',
      '; '.join(mismatches) if mismatches else 'All ten digit glosses map to their documented forms.',
      'v3.0-L digit table; exact presence check against supplied CSV.'))
    # Reference persistence is a declared rule but a parser/state model does not exist yet.
    tests.append(Test('P5.17-C01','Reference persists until replaced','BLOCKED',
      'Rule is documented, but the source pack does not define a complete token grammar or executable reference-state transition model; no valid end-to-end fixture can yet be parsed.',
      'Phase 4 §3.3 states persistence; Phase 5.16 recovery matrix identifies full parser as missing.'))
    tests.append(Test('P5.17-C02','Reference replacement resets current target','BLOCKED',
      'Expected behaviour is implied by “persists until replaced”, but replacement token boundaries, scope encoding and invalid replacement handling are not fully specified.',
      'Phase 4 §3.3; exact v2.0 morphology unavailable in supplied archive.'))
    tests.append(Test('P5.17-C03','Construction ordering is enforced','BLOCKED',
      'Intended order is documented (reference → spatial role/vector → Feet → couplings → quantity → control → release), but token classes and legal repetition/cardinality rules are incomplete.',
      'Phase 4 §3.3. This is an ordering contract, not a parser pass.'))
    tests.append(Test('P5.17-C04','Foot morphology parses frame + parameter vowel + optional relation coda','BLOCKED',
      'The shape is documented, but the exact legal frame inventory, vowel-to-property mappings and coda inventory are not sufficiently canonical to validate arbitrary Feet.',
      'Phase 4 §§3.3 and 12 mark parameter mapping provisional and exact v2.0 details unrecovered.'))
    tests.append(Test('P5.17-C05','h-coupling mappings are canonical','BLOCKED',
      'Phase 4 labels the mechanical/thermal/electromagnetic/chemical/biological/informational/mana mappings PROVISIONAL; the harness must not silently treat them as canon.',
      'Phase 4 §3.3; Phase 5.16 recovery report C-07.'))
    tests.append(Test('P5.17-C06','Numeral closure and dimensional units are validated in a complete expression','BLOCKED',
      'Phase 4 says numerals close with units and SHO closes dimensionless numerals, but this harness lacks the operator signature table and parser needed to validate expression-level quantities.',
      'Phase 4 §6 G-2; formal operator signatures and full parser are not included as an executable grammar.'))
    tests.append(Test('P5.17-S01','Hand-flame example is fully well-typed and feasible','NOT_TESTED',
      'Known verdict remains: tokenised and partially structured; not proven well-typed and not physically validated. No result is inferred from lexical legality.',
      'Phase 4 §8 explicitly says no whole-spell grammar parse was run and required energy, extent and coupled matter are unspecified.'))
    tests.append(Test('P5.17-S02','Physical mechanism and conservation are independently checked','NOT_TESTED',
      'No resource/mechanism feasibility engine or canonical spell IR is present in the recovery archive.',
      'Grammar Consistency Test Register T-013/T-014; Phase 5.16 recommended separate syntax and physical-feasibility layers.'))
    tests.append(Test('P5.17-V01','Vernacular parser and naturalness are validated','NOT_TESTED',
      'The Phase 5 samples are word-defined and mechanically checked, but no machine parser or listener results are included.',
      'Phase 5 §8 and §10.'))
    return tests

def main():
    path=Path(sys.argv[1]) if len(sys.argv)>1 else DEFAULT
    results=run(path)
    counts=Counter(t.status for t in results)
    report={'phase':'5.17','title':'Construction Grammar Test Harness — evidence-bounded baseline',
      'input':str(path),'tests_total':len(results),'counts':{STATUS[k]:counts.get(k,0) for k in STATUS},
      'scope_warning':'This is a baseline audit harness, not a complete Arcane parser. BLOCKED and NOT YET TESTED are not passes.',
      'results':[t.as_dict() for t in results]}
    print(json.dumps(report,indent=2,ensure_ascii=False))
    # Exit nonzero only for demonstrated defects, not unresolved spec gaps.
    return 1 if counts['FAIL'] else 0
if __name__=='__main__': raise SystemExit(main())
