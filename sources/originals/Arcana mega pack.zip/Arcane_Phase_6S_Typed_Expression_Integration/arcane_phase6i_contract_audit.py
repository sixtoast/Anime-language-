#!/usr/bin/env python3
"""Arcane Phase 6I: executable contract and dimensional-safety audit.

This audit tests only behaviour explicitly implemented in the Phase 6H subset.
It deliberately does not infer canonical meanings for unresolved units/operators.
"""
from decimal import Decimal
import arcane_phase6h_pipeline as arc

CASES = []
def add(name, fn):
    try:
        passed, detail = fn()
        CASES.append((name, bool(passed), str(detail)))
    except Exception as exc:
        CASES.append((name, False, f'{type(exc).__name__}: {exc}'))

def expect_value(source, expected):
    node = arc.parse(source)
    typ = arc.check(node)
    value = arc.evaluate(node)
    return value == expected, f'type={typ}; value={value!r}; expected={expected!r}'

def expect_error(source, stage, fragment):
    try:
        node = arc.parse(source)
        if stage == 'type':
            arc.check(node)
        elif stage == 'runtime':
            arc.check(node); arc.evaluate(node)
        else:
            return False, 'invalid test stage'
    except Exception as exc:
        return fragment.lower() in str(exc).lower(), f'{type(exc).__name__}: {exc}'
    return False, 'expression unexpectedly succeeded'

# Arithmetic: values and preserved unit labels.
add('addition preserves SHO', lambda: expect_value('frapa ki sho to sho', (Decimal(3), 'sho')))
add('subtraction preserves SHO', lambda: expect_value('fraja mu sho ki sho', (Decimal(2), 'sho')))
add('dimensionless multiplication', lambda: expect_value('frama ki sho to sho', (Decimal(2), 'sho')))
add('dimensionless divisor', lambda: expect_value('frala mu sho to sho', (Decimal('1.5'), 'sho')))
add('absolute value preserves unit', lambda: expect_value('frasha za ma', (Decimal(0), 'ma')))
add('addition rejects different unit labels', lambda: expect_error('frapa ki ma to se', 'type', 'matching units'))
add('subtraction rejects different unit labels', lambda: expect_error('fraja ki ma to se', 'type', 'matching units'))
add('multiplication rejects two labelled units', lambda: expect_error('frama ki ma to se', 'type', 'dimensional multiplication'))
add('division rejects labelled divisor', lambda: expect_error('frala ki ma to se', 'type', 'divisor must be dimensionless'))
add('division by zero is runtime error', lambda: expect_error('frala ki sho za sho', 'runtime', 'division by zero'))

# Boolean checks use explicitly documented test fixtures only.
add('NOT true fixture', lambda: expect_value('grash bool_true', (False, 'bool')))
add('NOT false fixture', lambda: expect_value('grash bool_false', (True, 'bool')))
add('AND rejects number operands', lambda: expect_error('gran ki sho to sho', 'type', 'Boolean'))
add('OR rejects number operands', lambda: expect_error('grat ki sho to sho', 'type', 'Boolean'))
add('IF rejects non-Boolean condition', lambda: expect_error('bek ki sho meto frapa ki sho to sho dogu', 'type', 'Boolean'))

# Syntax and fail-closed checks.
add('unclosed numeral rejected', lambda: expect_error('frapa ki to', 'type', 'terminate in a unit'))
add('malformed decimal rejected', lambda: expect_error('frapa za shi ma ki sho', 'type', 'fractional digits'))
add('unknown word rejected', lambda: expect_error('notarealword', 'type', 'Unknown lexical form'))
add('trailing expression rejected', lambda: expect_error('ki sho to sho', 'type', 'Trailing tokens'))
add('missing block opener rejected', lambda: expect_error('bek bool_true frapa ki sho to sho dogu', 'type', 'requires METO'))
add('missing block closer rejected', lambda: expect_error('bek bool_true meto frapa ki sho to sho', 'type', 'missing DOGU'))
add('unbound reference rejected', lambda: expect_error('kwat ki sho', 'type', 'Unbound identifier'))

if __name__ == '__main__':
    for i, (name, ok, detail) in enumerate(CASES, 1):
        print(f'{i:02d}. {"PASS" if ok else "FAIL"} — {name}: {detail}')
    print(f'RESULT: {sum(ok for _, ok, _ in CASES)}/{len(CASES)} passed')
    raise SystemExit(0 if all(ok for _, ok, _ in CASES) else 1)
