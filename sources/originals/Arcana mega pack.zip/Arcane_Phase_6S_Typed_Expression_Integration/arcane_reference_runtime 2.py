#!/usr/bin/env python3
"""Arcane Phase 6P reference runtime (NEW, provisional subset; not recovered historical code).

Syntax is an explicit test notation: (operator argument ...), decimal literals, true/false.
Only source-backed operator glosses are implemented. Signatures and dimensional rules remain
provisional where the contract registry says they are open. This is a harness, not canon.
"""
from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal, DivisionByZero, InvalidOperation
import re
from typing import Union

class ArcaneRuntimeError(Exception): pass
class ArcaneParseError(ArcaneRuntimeError): pass
class ArcaneArityError(ArcaneRuntimeError): pass
class ArcaneTypeError(ArcaneRuntimeError): pass
class ArcaneEvaluationError(ArcaneRuntimeError): pass

@dataclass(frozen=True)
class Number:
    value: Decimal
@dataclass(frozen=True)
class Boolean:
    value: bool
@dataclass(frozen=True)
class Call:
    operator: str
    args: tuple['Expr', ...]
Expr = Union[Number, Boolean, Call]

TOKEN_RE = re.compile(r"\s*(\(|\)|[^\s()]+)")
OPS = {"frapa", "fraja", "frama", "frala", "frasha", "gran", "grat", "grash"}
ARITY = {"frapa": 2, "fraja": 2, "frama": 2, "frala": 2, "frasha": 1,
         "gran": 2, "grat": 2, "grash": 1}

def tokenize(source: str) -> list[str]:
    toks=[]; pos=0
    while pos < len(source):
        m=TOKEN_RE.match(source,pos)
        if not m:
            if source[pos:].strip()=="": break
            raise ArcaneParseError(f"unexpected character at offset {pos}")
        toks.append(m.group(1)); pos=m.end()
    return toks

def parse(source: str) -> Expr:
    tokens=tokenize(source); i=0
    def atom() -> Expr:
        nonlocal i
        if i>=len(tokens): raise ArcaneParseError("unexpected end of input")
        t=tokens[i]; i+=1
        if t == "(":
            if i>=len(tokens): raise ArcaneParseError("missing operator")
            op=tokens[i].lower(); i+=1
            if op not in OPS: raise ArcaneParseError(f"unknown operator: {op}")
            args=[]
            while i<len(tokens) and tokens[i] != ")": args.append(atom())
            if i>=len(tokens): raise ArcaneParseError("missing closing parenthesis")
            i+=1
            if len(args)!=ARITY[op]:
                raise ArcaneArityError(f"{op} expects {ARITY[op]} argument(s), got {len(args)}")
            return Call(op,tuple(args))
        if t==")": raise ArcaneParseError("unexpected closing parenthesis")
        if t.lower() in ("true","false"): return Boolean(t.lower()=="true")
        try: return Number(Decimal(t))
        except InvalidOperation: raise ArcaneParseError(f"unsupported literal: {t}")
    if not tokens: raise ArcaneParseError("empty input")
    tree=atom()
    if i != len(tokens): raise ArcaneParseError("extra input after expression")
    return tree

def show_ast(expr: Expr):
    if isinstance(expr, Number): return ("number", str(expr.value))
    if isinstance(expr, Boolean): return ("boolean", expr.value)
    return (expr.operator, *(show_ast(x) for x in expr.args))

def evaluate(expr: Expr) -> Union[Decimal,bool]:
    if isinstance(expr, Number): return expr.value
    if isinstance(expr, Boolean): return expr.value
    vals=[evaluate(a) for a in expr.args]; op=expr.operator
    if op in ("frapa","fraja","frama","frala","frasha"):
        if not all(isinstance(v,Decimal) for v in vals): raise ArcaneTypeError(f"{op} requires numeric arguments")
        if op=="frapa": return vals[0]+vals[1]
        if op=="fraja": return vals[0]-vals[1]
        if op=="frama": return vals[0]*vals[1]
        if op=="frala":
            if vals[1]==0: raise ArcaneEvaluationError("frala division by zero")
            return vals[0]/vals[1]
        return -vals[0]  # FRASHA follows source gloss 'negate', not abs().
    if op in ("gran","grat","grash"):
        if not all(isinstance(v,bool) for v in vals): raise ArcaneTypeError(f"{op} requires Boolean arguments")
        if op=="gran": return vals[0] and vals[1]
        if op=="grat": return vals[0] or vals[1]
        return not vals[0]
    raise ArcaneEvaluationError(f"operator not implemented: {op}")

def run(source: str): return evaluate(parse(source))
