# Arcane Phase 5.14 — Signature Resolution Gate

**Status:** evidence matrix and executable-profile gate; no canon promoted.

## Purpose

Phase 5.14 does not guess missing operator semantics. It identifies the smallest decisions needed to make the next compiler layer safe. Phase 5.12's registry remains provisional and Phase 5.13 remains an audit-only parser.

## Priority contract matrix

| Form | Known from recovered sources | Still unresolved | Minimum evidence/test before lock | Current gate |
|---|---|---|---|---|
| DRAS (alias DRAL) | Comparison family; Phase 4 records DRAS as renamed form | Whether relation is an explicit third operand, an operator family, or a predicate encoding; equality/order domain and mixed-unit conversion | Source-backed examples for equality, less-than, greater-than; dimension mismatch; NaN/unknown values if representable | BLOCKED / signature provisional |
| SIMA | Measurement; distinct from NES/read and DAVE/infer | Surface arity and measurement-pathway representation; sensor/source, resolution, uncertainty, provenance, sampling time | One physical measurement example with target/property/pathway and explicit failure when no pathway exists | BLOCKED / signature open |
| KWASH (alias KWAK) | Live evaluation; alias rename recorded | Sampling cadence/event, snapshot vs repeated evaluation, stale data, errors, side effects | Tests showing when reevaluation occurs, stale/missing context rejection, and no accidental physical effect from observation alone | BLOCKED / signature open |
| BEK | IF; condition and block semantics; Phase 4 G-5/G-6 block delimiters METO/DOGU; condition fires when whole condition becomes true | Exact block AST, else branch (if any), return/control result, onset semantics interaction | Parse and execute-free trace for true/false conditions, malformed block, nested IF, edge-triggered RUKI | BLOCKED / signature open |
| ZET | WHILE; condition re-evaluated; block form required | Evaluation timing, termination/iteration bounds, interruption/failure semantics, relationship to sampling | Trace showing pre-check/iteration order, false-at-entry, false-after-one-iteration, bound exceeded | BLOCKED / signature open |
| KREN / TRAK / FREM / SHREN / BRAN / VARE | Construction-system roots/verbs and distinct from expression operators | Exact v2.0 Foot/frame/coupling expansion and operand typing | Recover source grammar; demonstrate each macro expands to valid construction with explicit resource/effect contract | BLOCKED / macro contract open |
| LABU | Proposed frame transform in Phase 4 draft | Canonical status, source/destination frame, point vs vector semantics, affine translation | Frame identity, inverse, composition, point translation, vector no-translation tests; source-backed signature decision | NOT EXECUTABLE / proposed |

## Source priority and decisions

1. Phase 2 has priority for original signatures and semantic contracts.
2. Phase 4 rename decisions are respected: `DRAS` is canonical with `DRAL` as an alias; `KWASH` canonical with `KWAK` alias. Likewise `FRAJA/FRATA`, `FRAMA/FRAKA`, `DRUM/DRIM`, `BEN/REN`, and `GRASH/GRAK`.
3. A lexicon entry proves a form/gloss was proposed or recorded; it does not by itself prove argument structure or execution semantics.
4. An audit harness passing tests proves only the tested implementation behaves as coded. It does not prove the source contract is correct.
5. Construction verbs remain separate from typed expression operators until the recovered v2.0 grammar and compiler bridge are available.

## Executable-profile policy

An operator may enter a future executable profile only when all are true:

- canonical form and alias policy are unambiguous;
- argument structure and arity are source-backed;
- input/output semantic types and dimensional/frame rules are defined;
- evaluation timing and side effects are defined where relevant;
- invalid, unavailable, and physically infeasible cases fail explicitly;
- at least one positive and one negative distinguishing test pass;
- the Construction-to-Expression bridge and physical feasibility layer accept the resulting AST.

No operator in this phase is promoted to canon. No spell execution is authorised by these audit files.

## Current language-completeness assessment

The project is past pure brainstorming: it has a canonical architecture, a substantial lexicon draft, recorded rename decisions, a registry, numeral/frame test harnesses, and a limited typed AST prototype. It is **not yet a fully working language implementation**.

| Layer | Assessment | Why |
|---|---|---|
| Core language/magic concept | Strongly specified | Separation of language, spell, mana, energy, coupling and effect is explicit |
| Lexicon | Partial-to-substantial draft | Forms exist, but coverage and vernacular naturalness are not independently validated |
| Phonology/phonotactics | Partly specified | Mechanical legality can be checked; pronunciation/listener testing is absent |
| Surface grammar and unique parsing | Incomplete | Full production parser and spoken boundary/ambiguity tests are absent |
| Operator signatures/type system | In progress | Registry exists; many signatures remain OPEN/PROVISIONAL/PROPOSED |
| Numerals and units | Prototype tested | Exact-value harness exists; complete grammar integration and information/mana dimensions remain open |
| Frames and construction morphology | Incomplete | Transform mathematics tested, but canonical basis/origins and v2.0 Foot/h-coupling details are unrecovered |
| Compiler to construction/mana instructions | Not yet demonstrated | AST prototype does not compile to canonical Feet/couplings or enforce full physical feasibility |
| Runtime/spell execution | Not demonstrated | No end-to-end spell runtime with resource accounting and failure behaviour has been validated |
| Human usability | Untested | No listener comprehension, learnability, or real-time casting tests |

### Practical estimate

A single percentage would be misleading because a large lexicon does not compensate for an incomplete parser or compiler. For planning, describe the project as **midway through specification recovery, but early in implementation readiness**. The front-end audit prototypes are useful scaffolding; the end-to-end system is not close enough to call operational until the canonical grammar, operator contracts, construction bridge, and runtime all pass integrated tests.

The next evidence-driven milestone is not adding more roots. It is recovering the Phase 2 contracts and producing a minimal end-to-end vertical slice: one unambiguous surface expression → typed AST → valid construction representation → feasibility/resource check → deterministic simulated result or explicit rejection.
