# Arcane Phase 6F — Control Flow and Bindings

Status: **prototype / provisional semantics**. This phase recovers and implements a narrow executable subset based on Phase 4's G-2, G-5 and G-6, plus its explicit KWAM/KWAT/KWASH descriptions. It does not replace the canonical grammar or claim full language completion.

## Source-grounded decisions used

- Phase 4 G-5: IF, WHILE, UNTIL and EACH take a condition then a block; blocks open with `METO` (BEGIN) and close with `DOGU` (END). A one-clause block may omit delimiters in Performed speech.
- Phase 4 G-6: IF fires when its whole condition becomes true; ONSET (`RUKI`) makes one inner term edge-based; WHILE runs while true; UNTIL stops when true.
- Phase 4 D-037 / L-15: `KWASH` is the current formal live-evaluation form (legacy `KWAK`); `KWAM` and `KWAT` combine for locked values.
- Phase 3/Phase 4 audit semantics: `KWAM` takes identifier + expression; `KWAT` reads an identifier; `KWASH` evaluates a live expression. Exact surface encoding and scope are not fully specified.

## Implemented subset

- `BEK⟨condition, METO⟨body...⟩⟩`: condition must be Boolean; body runs only when true.
- `ZET⟨condition, METO⟨body...⟩⟩`: reevaluates the condition before each iteration; runs while true.
- `KOLE⟨condition, METO⟨body...⟩⟩`: runs while false and stops once true. This is the direct operational reading of “UNTIL stops when true”.
- `KWAM⟨ID_n, expression⟩`: stores the evaluated value and type in the runtime binding table. `ID_n` is audit-only symbolic notation, not canonical Arcane vocabulary.
- `KWAT⟨ID_n⟩`: reads a stored binding; an unbound identifier fails explicitly.
- `KWASH⟨expression⟩`: reevaluates its expression each time; it does not cache the result.
- `METO⟨expr1, expr2, ...⟩`: audit notation for a block with ordered expressions. The written `DOGU` terminator is not yet parsed by the expression parser.
- A global step budget prevents accidental unbounded loops in this prototype. The budget is an implementation guard, not a canonically specified Arcane resource limit.

## Deliberately blocked

- `WEKI` (EACH): Phase 4 supplies the concept but not a complete collection type, element binding rule, order semantics or mutation policy.
- `RUKI` (ONSET): transition history / edge detection needs an event model and sampling rules.
- Lexical numeric identifiers closed by `SHO`: grammar is recorded in Phase 4 G-2, but the current audit parser does not parse numeral tokens or unit-closed identifiers. Tests therefore use `ID_n` placeholders.
- Scope/lifetime rules for bindings and blocks: not fully specified by recovered source. This prototype uses one runtime environment per execution and makes no claim that this is final canon.
- Physical spell effects: no mana construction, compilation, targeting or execution is performed.

## Validation

The regression suite tests condition selection, Boolean type enforcement, stored and live bindings, loops that terminate, infinite-loop protection, unbound references, dimensional rejection after a binding, vector binding, nested conditions and blocked `WEKI`. Run with Python 3 in the same folder as the included Phase 6C/6D/6E dependencies and lexicon CSV.

**Important:** test passes show conformance to this prototype's explicitly stated subset, not proof that the complete Arcane language is working. Before locking these semantics, add a ledger decision and tests against the exact recovered construction grammar, especially `METO`/`DOGU`, `RUKI`, numeric identifiers, and block scope.
