"""Phase 5.14 policy gate: audit statuses only; not a compiler."""
import csv, json
from pathlib import Path

BASE = Path(__file__).resolve().parent
REGISTRY = json.loads((BASE / 'Arcane_Phase_5_12_Operator_Registry.json').read_text())
OPS = {r['form']: r for r in REGISTRY['operators']}

# Evidence-gate tests: these assert that unresolved contracts remain explicitly gated.
def run():
    tests = []
    def check(name, fn):
        try:
            assert fn()
            tests.append((name, True, 'PASS'))
        except Exception as e:
            tests.append((name, False, f'FAIL: {e}'))
    check('DRAS exists and remains provisional', lambda: 'dras' in OPS and ('PROVISIONAL' in OPS['dras']['status'] or 'OPEN' in OPS['dras']['status']))
    check('SIMA exists and remains open', lambda: 'sima' in OPS and 'OPEN' in OPS['sima']['status'])
    check('KWASH exists and remains open', lambda: 'kwash' in OPS and 'OPEN' in OPS['kwash']['status'])
    check('BEK remains open', lambda: 'bek' in OPS and 'OPEN' in OPS['bek']['status'])
    check('ZET remains open', lambda: 'zet' in OPS and 'OPEN' in OPS['zet']['status'])
    check('KREN construction contract remains open', lambda: 'kren' in OPS and 'OPEN' in OPS['kren']['status'])
    check('LABU is not canon', lambda: 'labu' in OPS and 'NOT CANON' in OPS['labu']['status'])
    expected = {'fraja':'frata','frama':'fraka','drum':'drim','grash':'grak','kwash':'kwak','dras':'dral'}
    check('renamed canonical forms retained', lambda: all(OPS[k]['aliases'].split(';').count(v)==1 for k,v in expected.items()))
    check('canonical forms unique', lambda: len(OPS)==len(REGISTRY['operators']))
    check('all aliases avoid another canonical form', lambda: all(a not in OPS for r in REGISTRY['operators'] for a in r['aliases'].split(';') if a))
    check('registry authority warns against promotion', lambda: 'provisional' in REGISTRY['status'].lower())
    return tests

if __name__ == '__main__':
    results = run()
    for name, ok, msg in results: print(f'{msg}\t{name}')
    print(f'RESULT: {sum(ok for _,ok,_ in results)}/{len(results)} PASS')
    raise SystemExit(0 if all(ok for _,ok,_ in results) else 1)
