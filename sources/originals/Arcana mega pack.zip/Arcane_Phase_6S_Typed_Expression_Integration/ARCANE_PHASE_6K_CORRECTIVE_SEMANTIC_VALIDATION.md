# Arcane Phase 6K — Corrective Semantic Validation

**Status:** targeted source-backed contract validated; full runtime correction not yet integrated; no canon changes made.

## 1. Verified source contract

The recovered Continuity & Recovery Audit lists `FRASHA` as **negate** in the maths inventory and separately records FRASHA as the negative sign in numeral-related notes. The Phase 5 lexical inventory also uses `GRASH` as logical NOT. Therefore the Phase 6H implementation of `FRASHA` as absolute value (`abs`) conflicts with the recovered gloss and must not be retained as validated behaviour.

The minimal numeric contract tested here is unary arithmetic negation:

- `FRASHA(3) = -3`
- `FRASHA(-3) = 3`
- `FRASHA(0) = 0`
- `FRASHA(1.25) = -1.25`

The tests exercise a reference contract function, not the full Phase 6H parser/evaluator. The Phase 6H runtime source was not present in the recovered working directory when this phase was run, so no claim is made that the runtime has been patched.

## 2. Important unresolved collision

The recovery audit also calls FRASHA the negative sign for numerals. The recovered material does not fully specify whether the same surface form acts as (a) a prefix sign in numeric literals, (b) a unary operator in expression syntax, or both under different grammatical contexts. This must be specified before parser integration. Do not silently infer a context rule.

## 3. Status conflicts

- `SHO`: Phase 4 grammar relies on it as dimensionless numeral closure; Phase 5 lexicon status is `PROPOSED`.
- `METO` and `DOGU`: Phase 4 grammar relies on them as block delimiters; Phase 5 lexicon status is `PROPOSED`.
- `KOLE`: Phase 4 lists UNTIL/KOLE, but Phase 5 lexicon status remains `PROPOSED`.

These are governance/reconciliation issues, not permission to promote words to canon. Keep them provisional until the decision ledger records an explicit decision.

## 4. Test result

Run `python arcane_phase6k_semantic_tests.py`.

The 6 tests cover positive, negative, zero, fractional, distinction-from-absolute-value, and invalid Boolean input. Passing establishes only this reference contract, not full parser/runtime conformance.

## 5. Next corrective work

1. Restore or recover the current Phase 6H runtime and its tests.
2. Patch its FRASHA evaluation from absolute value to unary negation only after the syntax contract for numeric sign vs unary operator is settled.
3. Add parser tests for prefix position, nested use, and malformed sign placement.
4. Reconcile SHO/METO/DOGU/KOLE statuses in the decision ledger without changing status silently.
5. Populate an operator contract registry with evidence, arity, operand types, result type, unit rules, evaluation order and failure cases.
6. Run all prior tests, preserving the original failures and new results in a change record.

## 6. Change-control decision

- Existing rule/source: recovery audit lists FRASHA = negate; lexicon lists FRASHA = negate.
- Defect: Phase 6H implementation uses absolute value.
- Corrective reference behaviour: unary numeric negation.
- Decision: **PROVISIONAL implementation contract; no canon change** pending the source-level distinction between a negative numeral marker and an operator call.
