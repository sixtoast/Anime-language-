# ARCANE LANGUAGE AUDIT — PHASE 6B
## Typed semantic checker and dimensional arithmetic

**Status:** Prototype; 13/13 listed regression tests pass. This is a diagnostic implementation, not a canonical language compiler and not a claim that the full Arcane grammar is complete.

## Scope and boundaries

This prototype implements a small typed layer over the provisional Phase 2 audit notation `OPERATOR⟨argument₁, argument₂, …⟩`. Angle brackets, commas, and test identifiers such as `LEN_A` are audit scaffolding, not new Arcane vocabulary or spoken forms.

It introduces a provisional type model for quantities with dimensions, vectors, Booleans, observations, unit symbols, and control expressions. The dimensional base tuple is `(L, T, M, Θ)` for length, time, mass, and temperature. Dimension exponents are combined by multiplication and division; addition and subtraction require matching dimensions.

## Implemented checks

- FRAPA / FRATA: two quantities of matching dimensions; result retains that dimension.
- FRAKA: quantity dimensions add componentwise.
- FRALA: quantity dimensions subtract componentwise.
- FRASHA: negation preserves quantity dimensions.
- DREM: vector inputs; output dimensions are the componentwise sum of the vector dimensions.
- GRAN / GRAT / GRAK: Boolean inputs and Boolean output.
- Selected fixed arities and unknown-symbol rejection.
- Unresolved signatures are blocked rather than guessed.

## Test results

| Test | Result | Purpose |
|---|---|---|
| 6B-01 | PASS | Add quantities with matching dimensions |
| 6B-02 | PASS | Reject length plus time |
| 6B-03 | PASS | Length multiplied by length yields area dimension |
| 6B-04 | PASS | Length divided by time yields velocity dimension |
| 6B-05 | PASS | Negation preserves energy dimension |
| 6B-06 | PASS | Reject unit symbols as numeric quantities |
| 6B-07 | PASS | Reject incorrect fixed arity |
| 6B-08 | PASS | Reject unknown symbols |
| 6B-09 | PASS | Block unfinalised DAVE signature |
| 6B-10 | PASS | Boolean AND returns Boolean |
| 6B-11 | PASS | Reject Boolean/numeric mismatch |
| 6B-12 | PASS | Dot-product dimensions combine correctly |
| 6B-13 | PASS | Keep unresolved cross-product signature explicitly blocked |

**Result: 13/13 prototype tests passed.** A test passes when the prototype gives the expected result, including rejecting an expression whose semantics are not yet defined. This is not a pass for the complete Arcane language.

## Findings that must not be silently promoted to canon

1. **Unit conversion is not implemented.** The checker tests dimensional compatibility, not conversion factors or affine units.
2. **Values and dimensions are distinct.** The current checker returns types, not numerical results. Division by zero and overflow belong to a later evaluator/runtime layer.
3. **Vector signatures need refinement.** DREM's dimensional rule is implemented provisionally. DRIM must return a vector for a 3D cross product, not a scalar; its signature and representation remain unresolved and execution is blocked.
4. **DRAL is unresolved.** The third argument's relation-criterion representation and exact comparison semantics remain open.
5. **Information/control operators are not guessed.** SIMA, NES, GAMA, DAVE, KWAM, KWAT and KWAK need their canonical typed signatures and evaluation semantics. The prototype explicitly blocks these rather than manufacturing behaviour.
6. **The symbol table is a test fixture.** `LEN_A`, `TIME_A`, `BOOL_A`, and similar names are not additions to the Arcane lexicon.
7. **Physical feasibility is a separate pass.** Type correctness cannot establish that a measurement pathway exists, a mechanism is physically possible, or a spell has sufficient resources.

## Proposed pipeline

`parse → type-check → resolve bindings/references → compile Construction representation → physical feasibility-check → execute → observe/feedback`

Each stage should return its own errors. A later-stage failure must not be obscured by earlier-stage success.

## Next milestone: Phase 6C

1. Define a canonical type inventory and value/reference distinction.
2. Finalise dimensional algebra, unit conversion and the treatment of dimensionless quantities and angles.
3. Define complete operator signatures, beginning with DRAL, DRIM, SIMA, NES, GAMA, DAVE, KWAM, KWAT and KWAK.
4. Specify control-expression semantics, including BEK/ZET evaluation and termination behaviour.
5. Add type tests for the Phase 4 Construction bridge without changing its canon.
6. Keep spoken-surface uniqueness and listener testing as separate validation tracks.

## Change-control status

All signatures in this document beyond the recovered core definitions are **provisional audit rules**. They must be reviewed against the canonical Phase 4 and v3.0-L documents before adoption. No lexical root, phonological rule, or spoken grammar rule is changed by this phase.
