#!/usr/bin/env python3
"""Small stdlib unittest wrapper for the Phase 5.24 embedded regression suite."""
import unittest
import arcane_phase_5_24 as arcane

class Phase524Tests(unittest.TestCase):
    def test_embedded_regression_suite(self):
        results = arcane.selftest()
        failed = [r for r in results if r['status'] != 'PASS']
        self.assertEqual([], failed, msg=failed)
        self.assertEqual(10, len(results))

if __name__ == '__main__':
    unittest.main()
