from arcane_phase513_ast_validator import check, ParseError, TypeErrorArcane
cases=[]
def run(name, fn):
 try: fn(); cases.append((name,True,''))
 except Exception as e: cases.append((name,False,str(e)))
def expect_reject(fn):
 try: fn()
 except (ParseError,TypeErrorArcane): return
 raise AssertionError('Expected rejection')
run('nested valid same-dimension addition',lambda: check('frapa<Q<1,L>,frapa<Q<2,L>,Q<3,L>>>',strict=False))
run('canonical alias fraja accepted as subtraction-form registry entry',lambda: check('fraja<Q<3,L>,Q<1,L>>',strict=False))
run('legacy frata normalises to fraja',lambda: (_ for _ in ()).throw(AssertionError()) if check('frata<Q<3,L>,Q<1,L>>',strict=False).value!='fraja' else None)
run('length times time yields product dimensions',lambda: (_ for _ in ()).throw(AssertionError()) if check('frama<Q<2,L>,Q<3,T>>',strict=False).dim!='L*T' else None)
run('division by zero rejected',lambda: expect_reject(lambda:check('frala<Q<1,L>,Q<0,L>>',strict=False)))
run('addition dimension mismatch rejected',lambda: expect_reject(lambda:check('frapa<Q<1,L>,Q<1,T>>',strict=False)))
run('missing argument rejected',lambda: expect_reject(lambda:check('frapa<Q<1,L>>',strict=False)))
run('extra argument rejected',lambda: expect_reject(lambda:check('frapa<Q<1,L>,Q<2,L>,Q<3,L>>',strict=False)))
run('unknown operator rejected',lambda: expect_reject(lambda:check('zorp<Q<1,L>>',strict=False)))
run('boolean AND accepted',lambda: check('gran<B<true>,B<false>>',strict=False))
run('non-Boolean AND rejected',lambda: expect_reject(lambda:check('gran<Q<1,L>,Q<2,L>>',strict=False)))
run('NOT requires Boolean',lambda: expect_reject(lambda:check('grash<B<true>>',strict=False) if False else check('grash<Q<1,L>>',strict=False)))
run('strict mode rejects provisional signature',lambda: expect_reject(lambda:check('frapa<Q<1,L>,Q<2,L>>',strict=True)))
run('trailing token rejected',lambda: expect_reject(lambda:check('frapa<Q<1,L>,Q<2,L>> Q<3,L>',strict=False)))
with open('/mnt/data/Arcane_Phase_5_13_Test_Results.txt','w') as f:
 for n,ok,d in cases: f.write(('PASS' if ok else 'FAIL')+'\t'+n+(('\t'+d) if d else '')+'\n')
 f.write(f'RESULT: {sum(ok for _,ok,_ in cases)}/{len(cases)} PASS\n')
print(open('/mnt/data/Arcane_Phase_5_13_Test_Results.txt').read())
