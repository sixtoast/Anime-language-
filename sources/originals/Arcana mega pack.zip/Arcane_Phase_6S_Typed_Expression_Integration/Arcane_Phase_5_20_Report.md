# Arcane Phase 5.20 — Source Recovery and Homograph Evidence Matrix

**Status:** historical evidence recovered in Phase 4 material; two lexical collision cases can now be narrowed, but full spoken-parser conformance is still blocked. No canon changed.

## Executive result

The archive does contain relevant v2.0-derived material: `Arcane_Language_Audit_Phase_4.docx` (especially §§3.3, 6, 8–10 and decision L-10/D-034), its extracted text, and `phase4 finalize.pdf` plus its source script. Phase 5.19's wording that the construction rules were not recoverable from the current source package was too broad. The better conclusion is **partially recovered**: fused forms and their intended role are documented, but the complete original v2.0 reference table and full executable grammar are not present as an authoritative original v2.0 source.

## Evidence matrix

| Question | Evidence found | Status | What it supports / does not support |
|---|---|---|---|
| What are `re` and `ra` in Performed Arcana? | Phase 4 §3.3 says reference+scope compresses to one syllable; §10 says declared slot-resolved homophones. The Phase 4 lexicon generator defines `re = TARGET-surface`, `ra = TARGET-path`. | RECOVERED IN PHASE 4 CONSOLIDATION | Intended Performed readings are supported by the consolidation. It is not the raw v2.0 source itself. |
| How are references ordered? | §3.3: Performed order starts with reference, then spatial role/vector, Feet, couplings, quantity, control, release; reference persists until replaced. §8 hand-flame example starts `mel`. | RECOVERED IN PHASE 4 CONSOLIDATION | Supports reference slot at clause/construction start and persistence. Exact scope and clause-boundary parser rules still need formalisation. |
| Are `re` and `ra` safe because of register labels alone? | Phase 4 §10 allows only declared slot-resolved homophones; Phase 5 lexicon labels the numeral/unit entries Shared and fused entries Performed. | NOT PROVEN BY LABELS ALONE | A parser must distinguish the construction slot from ordinary number/unit slots. Register and slot constraints must both be applied. |
| What is the scope-vowel map? | Phase 4 §3.3 says `MI/NI/RI` default to volume and perform as `mə/nə/rə`; fused list includes point, surface, volume and path forms. | PARTIALLY RECOVERED | Explicit forms exist; the full general productive rule for all reference classes/scope combinations is not independently demonstrated. `ra` is a path form, not merely another scope vowel. |
| What are the parameter vowels? | Phase 4 §3.3 labels mapping provisional: a energy family; u motion; o extent; e structure/form; i information; ə baseline. | PROVISIONAL | Do not promote to canon or use as a hard validation rule without owner confirmation. |
| What are h-couplings? | Phase 4 §3.3 and table: `hə he ha hu hi ho`; mechanical `he`, thermal `he+ha`, electromagnetic `ho (+ha)`, chemical `he`, biological `hu`, informational `hi`, mana-only `hə`. Table calls mappings provisional except basic BRAN shape. | PARTIALLY RECOVERED / PROVISIONAL | Recoverable as Phase 4 proposal, not sufficient to declare full physical coupling taxonomy canon. |
| What are `mel`, `kan`, `ken`, `kas`? | §8 maps `mel` to `me + anchor coda l`; `kan` TRAK ENRA; `ken` FREM/structure held; `kas` SHREN energy. §3.2 and table identify verbs as aliases of Foot patterns, with KREN reading explicitly proposed. | EXAMPLE-LEVEL EVIDENCE | Supports the example’s intended interpretation only; does not fully define every Foot or anchoring landmark. |
| Does a full spoken parser exist? | §8 says no grammar-level parse of the whole spell was run; §9 says checks were token-level and full parser remains open. | NO | Unique parse remains a canonical requirement but is not verified for complete Performed constructions. |

## Revised status for RG checks

- **RG-01 / RG-03: PASS** — Shared `re=4` and `ra=radian` lexical entries are source-backed.
- **RG-02 / RG-04: PARTIALLY RECOVERED, EXECUTION BLOCKED** — intended Performed readings `re=TARGET-surface` and `ra=TARGET-path` are documented in Phase 4. Their use is slot-resolved, but there is no complete parser proving the slots reject the competing Shared readings in all contexts.
- **RG-05: UNRESOLVED** — do not impose blanket mixed-register rejection. Phase 5 rule G-V1 says vernacular words do not occur inside a construction clause and register changes at clause boundary, but that does not settle all Shared/Performed mixing. Shared closed classes are explicitly shared across registers.
- **RG-06: REQUIREMENT CANON; IMPLEMENTATION UNVERIFIED** — unique parse principle stands; whole-grammar enforcement is not implemented/tested.
- **RG-07 / RG-08: PASS** — provenance is present and the only duplicate spellings in the Phase 5 CSV are `re` and `ra`.

## Important consistency distinction

The Phase 4 report has **two subsystems**: the Expression system (typed prefix operators) and Construction system (Feet, couplings and scoped references). Its `HEAD + CORE + PARAMETERS + CONSTRAINTS + CONTROL` is a spell representation, not a competing replacement for surface syntax `HEAD + ARGUMENTS + MODIFIERS`. The compile bridge is still incomplete. Do not use expression-level prefix examples as proof that Performed reference-slot parsing is solved.

## Decisions recorded

**P5.20-D1 — Amend the evidence description, not the language.** Record fused-reference meanings and ordering as “documented in Phase 4 consolidation”; do not claim raw v2.0 source recovery.

**P5.20-D2 — Keep `re` and `ra`.** Existing rename policy is unchanged. No demonstrated legal construction yet proves a real collision after slot constraints are applied.

**P5.20-D3 — No blanket register lock.** Keep G-V1's explicit vernacular/construction boundary, but do not generalise it into a rule forbidding every Shared/Performed combination.

**P5.20-D4 — Do not canonise provisional morphology.** Parameter-vowel and h-domain mappings remain provisional; `KREN`'s voiced-stop interpretation and complete MEL anchoring remain incompletely specified.

## Next work: Phase 5.21

1. Build a small *evidence-bounded construction validator* for the documented hand-flame token sequence and the two homograph slots; label it a fixture validator, not a general parser.
2. Test both intended readings in context: `re` as numeral versus target-surface, `ra` as unit versus target-path. Positive fixtures must include enough surrounding slot structure to make the intended role explicit.
3. Add negative fixtures for `re`/`ra` appearing in the wrong slot; do not invent the missing complete grammar. Mark any test whose validity depends on undocumented boundaries BLOCKED.
4. Maintain an open question: can a Shared numeral/unit occur inside a Performed construction's quantity slot? Phase 4's hand-flame says yes for `ma`/`se` units and digits, so “no Shared words inside Performed” would contradict evidence.
5. Recover or reconstruct the full v2.0 original from older chat/export if possible. Until then, label historical details “Phase 4 consolidation” rather than “original v2.0 source”.

## Scope disclaimer

This phase is documentary reconciliation. It does not validate naturalness, listener comprehension, full grammar, spell feasibility, or the physical validity of any magic effect.
