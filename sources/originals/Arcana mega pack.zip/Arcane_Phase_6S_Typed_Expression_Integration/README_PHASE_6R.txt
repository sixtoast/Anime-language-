Arcane Phase 6R — Provisional dimensional quantity layer

Run from this directory:
  python -m unittest -v test_arcane_reference_runtime test_phase6q_grammar test_phase6r_dimensions

This package is a prototype and does not change Arcane canon. The dimensional module is separate from the evaluator.
