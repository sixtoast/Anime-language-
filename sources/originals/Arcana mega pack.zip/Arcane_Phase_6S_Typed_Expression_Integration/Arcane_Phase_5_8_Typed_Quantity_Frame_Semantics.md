# Arcane Phase 5.8 — Typed Quantity and Frame Semantics

**Status:** provisional reference implementation; canon unchanged  
**Validation:** 16/16 regression checks passed in the included harness  
**Scope:** dimensional algebra, basic vector typing, frame compatibility, alias normalization and fail-closed behavior.

## 1. Why this phase exists

Phase 2 explicitly requires dimensional compatibility and dimensional algebra before arithmetic signatures can be considered complete. Phase 4 D-017 establishes that the historical cross-product head `DRIM` follows the physical right-hand rule and that its component formula is negated in the left-handed caster frame: `BA × DA` gives `KA` (backward) in the stated convention. Phase 5.8 begins implementing dimensional checks and same-frame requirements, but does not claim to implement all of D-017's coordinate transformation behavior.

The implementation uses a compact audit-only notation such as `Q[length]` and `V3[velocity;world]`. These are diagnostic type labels, not new Arcane vocabulary or canonical spoken forms.

## 2. Dimension model

The reference harness represents dimensions as exponent tuples in the order `(length, time, mass, temperature)`. It includes length, area, volume, time, mass, velocity, acceleration, force, energy, temperature, pressure, momentum and dimensionless quantities. Multiplication adds exponents; division subtracts them.

Examples:

- length × length → area
- length ÷ time → velocity
- length-vector · velocity-vector → dimension `L² T⁻¹`
- length-vector × length-vector → area-dimension vector

The harness does not yet represent numeric values, unit conversion factors, uncertainty, affine quantities such as absolute temperature, or semantic subtypes such as position versus displacement. These remain open.

## 3. Operator behavior implemented

| Operator head | Historical alias | Implemented checks/behavior |
|---|---|---|
| `FRAPA` | — | Two quantities; dimensions must match; output dimension preserved |
| `FRAJA` | `FRATA` | Two quantities; dimensions must match; output dimension preserved |
| `FRAMA` | `FRAKA` | Two quantities; output dimensions add |
| `FRALA` | — | Two quantities; output dimensions subtract; zero-denominator value check not implemented |
| `DRAN` | — | Vector magnitude returns a scalar quantity with the vector's dimension |
| `DREM` | — | Vectors in the same frame; output dimensions add |
| `DRUM` | `DRIM` | 3D vectors in the same frame; output vector dimensions add |
| `DRAS` | `DRAL` | Compatible operand types and a `Criterion`; returns Boolean; criterion evaluation not implemented |
| `GRASH` | `GRAK` | Boolean input; returns Boolean |

The alias normalizer uses the Phase 5.6 preferred forms supplied in the project recovery work. It does not change historical source text or prove that a production parser preserves source spans.

## 4. Test results

All 16 included regression checks passed:

1. Addition of matching length dimensions accepted.
2. Addition of length and time rejected.
3. Historical subtraction alias resolves.
4. Length multiplied by length returns area.
5. Length divided by time returns velocity dimension.
6. Magnitude preserves vector dimension.
7. Dot product combines dimensions correctly.
8. Dot product across different frames rejected.
9. Cross product of length vectors returns area-dimension vector.
10. Cross product across different frames rejected.
11. Non-vector cross-product operands rejected.
12. Nested expression type-checks.
13. Comparison returns Boolean.
14. Comparison of incompatible dimensions rejected.
15. Unknown operator signature rejected rather than guessed.
16. Malformed/unclosed expression rejected.

The test output is included as `Arcane_Phase_5_8_Test_Results.txt`; the full case list is `Arcane_Phase_5_8_Test_Cases.csv`.

## 5. Important caveats

- This is a reference type checker for a narrow subset, not a full Arcane parser/compiler.
- `FRAPA`/`FRAJA` currently use dimensional equality only. That is necessary but not sufficient: point-plus-point, absolute-temperature arithmetic and other semantic-kind rules need separate typing.
- The harness requires both vectors to name the same frame. It does not automatically transform vectors between `world`, `caster` and `local` frames.
- D-017's left-handed caster-frame cross-product sign convention is preserved as a source contract but not numerically implemented in this phase. Do not treat the dimensional result as proof of directional correctness.
- `FRALA` does not check the numeric value of the denominator, so divide-by-zero remains a runtime/value-level concern.
- `DRAS` only checks broad operand compatibility and the presence of a `Criterion`; it does not define comparison criterion encoding.
- Unit conversion, physical feasibility, mana coupling and spell execution are outside scope.

## 6. Decision status

**Implemented provisionally:** dimension-exponent propagation for multiplication/division, dimension checks for addition/subtraction, basic vector dimensional propagation, same-frame checks, fixed arity for the covered operators, alias normalization and rejection of unknown signatures.

**Not promoted to canon:** the audit notation, implementation-specific frame labels, the incomplete operator subset, and any claim that all Arcane quantity semantics are now closed.

## 7. Recommended Phase 5.9

Define semantic quantity kinds and coordinate-frame transformations before expanding the checker. Priorities:

1. Distinguish positions, displacements, vectors, scalar magnitudes and directions.
2. Define legal addition/subtraction for each semantic kind.
3. Implement explicit frame transforms and test D-017 numerically, including `BA × DA → KA` in the stated caster/world convention.
4. Add unit conversion and numeric literals with Phase 4's unit-terminated numeral rule.
5. Add value-level checks for division by zero and comparison evaluation.
6. Preserve source spans and report both historical token and preferred normalized operator in diagnostics.
