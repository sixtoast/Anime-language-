# Arcane Phase 5.18 — Vernacular Source Audit and Homograph Gate

**Status:** audit baseline complete; no canon changed. This is a static source/lexicon audit, not a complete parser, listener study, or physical spell validator.

## Inputs audited

- `Arcane_Lexicon_v5_draft.csv` (255 rows, from the supplied Arcana pack)
- `phase5_vernacular.py` (Phase 5 vernacular generator, sample sentences, and idioms)

## Recorded results

| Check | Result | Meaning |
|---|---|---|
| CSV schema | PASS | Required columns are present. |
| Lexical entry completeness | PASS | No blank form/gloss entries found. |
| Homograph inventory | PASS with review flag | Only `re` and `ra` are duplicated, matching the already documented cross-register pairs. This does **not** prove they are safe in execution. |
| `re` register separation | BLOCKED | A normative rule and enforcement test preventing unsafe mixed-register parsing are absent. |
| `ra` register separation | BLOCKED | A normative rule and enforcement test preventing unsafe mixed-register parsing are absent. |
| Sample sentence key coverage | PASS | All 25 source sentence fixtures refer to a declared key under the static inventory check. |
| Shared vocabulary targets | PASS | Shared mappings resolve to forms in the merged lexicon. |
| Fixture availability | PASS | The source includes 25 sentence fixtures and 5 idiom fixtures. |
| Naturalness/listener comprehension | NOT TESTED | Requires actual speakers/listeners and a recorded protocol. |
| Spoken unique parse | BLOCKED | The complete spoken grammar and register-boundary rules are not present. |

Counts: **6 PASS, 0 FAIL, 3 BLOCKED, 1 NOT TESTED.** PASS here only applies to the narrow static checks above; it does not imply the language is complete.

## Homograph findings

The source-backed duplicates are:

- `re`: digit `4` in the Shared register; `TARGET-surface` fused reference in Performed Arcana (labelled canon from v2.0).
- `ra`: `radian` unit in the Shared register; `TARGET-path` fused reference in Performed Arcana (labelled canon from v2.0).

**Recommendation — keep both spellings provisionally. Do not rename them yet.** The recovered evidence identifies them as different-register forms, so there is not enough evidence to call them unconditional lexical errors. However, a register label in a CSV is not a grammar rule. Before these forms are declared safe, the language specification must say whether an executable phrase has exactly one active register, how a register is established, whether it can switch inside a construction, and what happens if a token could be parsed in more than one way. Then the parser/conformance tests must enforce that rule.

This follows the existing change-control policy: preserve old forms as aliases unless an actual ambiguity is demonstrated. If a legal mixed-register construction admits both parses, record the counterexample and then adjudicate a disambiguation rule or rename.

## Important limits

1. The audit reads the current merged lexicon and Phase 5 source; it does not recover absent v2.0 rules.
2. The source's generator uses heuristic phonological distance. Such distance is not a substitute for listener recognition under speed, noise, accent, or stress variation.
3. Sentence-key coverage only proves that the examples reference declared lexical keys. It does not prove that the sentence grammar is natural, unambiguous, or compositionally correct.
4. The audit does not validate the semantics or feasibility of spells.

## Phase 5.19 — next concrete step

Build a small register-gating conformance suite before writing a full parser:

- **RG-01:** a standalone Shared-register number expression accepts `re` as digit 4.
- **RG-02:** a Performed construction with the canonical target-surface slot accepts `re` as the fused reference only if the v2.0 slot rule is recovered and documented.
- **RG-03:** a Shared-register unit expression accepts `ra` as radian.
- **RG-04:** a Performed construction with the canonical target-path slot accepts `ra` only if the v2.0 slot rule is recovered and documented.
- **RG-05:** a construction that mixes Shared and Performed tokens without an explicit, authorised register transition is rejected (proposal pending owner approval; do not treat as canon yet).
- **RG-06:** any sequence with two valid parses is rejected rather than guessed.
- **RG-07:** each accepted example records source, register, intended parse, and why competing parses are excluded.

RG-01 and RG-03 can be fixture designs from the current lexicon. RG-02 and RG-04 remain blocked until the original fused-reference grammar is available. RG-05 is a proposed safety rule requiring owner approval. RG-06 restates the canonical Unique Parse Requirement, but its surface implementation is still open.

## Decision status

No spelling, grammar, or canonical rule is changed by this report. The result is a clearer boundary between what the package demonstrates and what still needs a source or a test.
