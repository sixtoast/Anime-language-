# Arcane Phase 5.9 — Semantic Kinds, Units, and Frame Semantics

**Status:** provisional audit implementation; canonical language and Phase 4 decisions unchanged.  
**Execution:** 15/15 regression checks passed in the included reference harness.  
**Scope:** semantic distinctions between positions and displacements, explicit frame compatibility, a small SI conversion table, and a numerical handedness check for the recovered D-017 convention.

## 1. Why this phase exists

Phase 5.8's dimensional typing is necessary but insufficient. Two values can share dimensions while representing different kinds of thing. A position and a displacement both have length dimensions, but adding two positions is not the same operation as adding a displacement to a position. Likewise, vectors in different frames cannot safely be combined until a transformation is explicitly supplied.

This phase therefore adds semantic kinds alongside dimensions. It remains an audit harness, not a complete parser, compiler, or executable magic system.

## 2. Implemented semantic rules

- `position + displacement → position`, when both are in the same frame.
- `position + position` is rejected.
- `displacement + displacement → displacement`, when dimensions and frames agree.
- An operation involving incompatible semantic kinds is rejected rather than silently coerced.
- Frame mismatches are rejected; this phase does not guess a transform.
- Exact rational unit conversions are used to avoid floating-point rounding in the test harness.
- Angles remain semantically tagged even though radians are dimensionless in dimensional analysis.

## 3. Unit conversions

The harness recognises the recovered canonical units `MA` (metre), `SE` (second), `KE` (kilogram), `RA` (radian), and `KU` (kelvin). It additionally includes audit-only convenience units `CM`, `MM`, `KM`, `MS`, `MIN`, `H`, and `G` for testing conversion behavior. These extra abbreviations are **not proposed as Arcane lexemes** and must not be added to the canon without a lexicon collision audit.

Verified examples include `1 KM = 1000 MA`, `250 CM = 5/2 MA`, `60 SE = 1 MIN`, and `1 MS = 1/1000 SE`. Converting length to time is rejected.

## 4. D-017 handedness check

The harness explicitly tests the recovered convention for the cross-product sign:

- In the declared right-handed world basis, `X × Y = +Z`.
- In the declared left-handed caster convention, the component formula is sign-reversed, giving `X × Y = −Z`.
- Cross products whose operands declare different frames are rejected.

This is a narrowly defined numerical consistency test, not proof that every world-to-caster transform in the wider project has been specified. The actual basis relationship and coordinate transformation rules still need to be reconciled against the full Phase 4 wording before a general transform engine can be locked.

## 5. Test results

All 15 included checks passed: position/displacement rules, illegal point arithmetic, frame mismatch rejection, exact unit conversions, incompatible unit rejection, world and caster cross-product signs, cross-frame rejection, angle tagging, semantic-kind rejection, canonical unit registration, and exact fractional conversion.

The test log is `Arcane_Phase_5_9_Test_Results.txt`; the implementation is `arcane_phase59_semantic_frames.py`.

## 6. Explicit limitations

1. This is not a complete Arcane parser or compiler.
2. It does not implement a general affine coordinate transformation matrix between world, caster, and local frames.
3. The test harness uses convenience unit symbols for internal tests; they are not approved language vocabulary.
4. It does not yet parse the canonical unit-terminated numeral syntax from Phase 4.
5. It does not implement subtraction rules for every semantic kind, vector rotation, affine temperature, uncertainty, or runtime numeric checks.
6. Passing these tests validates only the implemented rules, not the whole language or magic system.

## 7. Change-control recommendation

Keep Phase 5.9 **PROVISIONAL**. Do not mark semantic typing or frame semantics LOCKED until the full D-017 source contract is compared line by line, all transformations are defined, and the official Arcane numeral/unit notation is tested without introducing lexical collisions.

## 8. Recommended Phase 5.10

Implement and test the canonical unit-terminated numeral syntax from Phase 4, while preserving source spelling and aliases. In parallel, create a frame-transform contract that specifies the basis matrix, handedness, transformation direction, and whether positions, displacements, and directions transform differently. Avoid adding any new Arcane roots until the existing v4/v5 lexicons have been checked for collisions.
