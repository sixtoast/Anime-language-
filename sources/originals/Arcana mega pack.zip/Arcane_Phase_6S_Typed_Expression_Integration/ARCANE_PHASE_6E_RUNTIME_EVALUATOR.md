# Arcane Phase 6E — Runtime Numeric and Vector Evaluation

**Status:** executable audit prototype; not canonical surface grammar and not spell execution.

## Purpose
Phase 6B checked types, Phase 6C defined provisional operator behaviour, and Phase 6D reconciled current lexicon spellings. Phase 6E adds evaluation of concrete test values after parsing, lexicon normalisation, and static type checking.

## Implemented in this prototype
- Numeric evaluation: `FRAPA`, current `FRAJA` (legacy `FRATA` alias), current `FRAMA` (legacy `FRAKA` alias), `FRALA`, `FRASHA`.
- Vector operations: `DRAN` magnitude, `DREM` dot product, current `DRUM` cross product (legacy `DRIM` alias), with three-component vectors.
- Comparisons: current `DRAS` (legacy `DRAL`) using audit-only criteria `LT`, `LE`, `EQ`, `NE`, `GE`, `GT`.
- Boolean logic: `GRAN`, `GRAT`, current `GRASH` (legacy `GRAK`).
- Explicit runtime errors for unknown symbols, incompatible dimensions, invalid argument kinds, non-finite results, division by zero, and unresolved operators.

## Test fixtures and units
The runtime environment contains test-only symbols such as `LEN_A`, `TIME_A`, `VEC_LEN_A`, `BOOL_A`. Numeric values are synthetic fixtures expressed in consistent base units with dimension tuple `(length, time, mass, temperature)`. These identifiers are not additions to the Arcane lexicon. The checker currently uses static dimensions and does not implement unit conversion or a complete unit algebra.

## Validation
The included regression suite defines 18 tests covering arithmetic, dimensions, vectors, comparisons, Boolean operations, unresolved control flow and invalid symbols. Run:

```bash
python arcane_phase6e_runtime_evaluator.py
```

Passing tests demonstrate the prototype's implementation of these stated rules only; they do not establish that every rule is canonical or that the full language is operational.

## Important limitation
This prototype calls the Phase 6C type checker before evaluating values. Some error tests therefore validate static rejection rather than a dynamic exception path. A future refinement should expose a unified compiler diagnostic model, explicit vector coordinate frames, unit conversion, and a proper typed runtime environment. `BEK`, `ZET`, `KWAM`, `KWAT`, `KWAK`, `NES`, `SIMA`, `GAMA`, and `DAVE` remain blocked until their semantics are recovered and approved.

## Next phase
Phase 6F should formalise control-flow and binding semantics from source evidence, then implement only those rules that can be tested against the recovered canon. Construction compilation remains a separate bridge and is not yet complete.
