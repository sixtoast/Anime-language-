# Arcane Language Audit — Phase 5.24
## Symbol tables, binding resolution, and captured/live evaluation

**Status:** PROTOTYPE IMPLEMENTED; 10/10 included regression tests pass.
**Canon status:** PROVISIONAL semantics for engineering tests only. This phase does not overwrite v3.0-L canon or claim to recover missing v2.0 morphology.

## Purpose
Phase 5.24 gives operational, testable behaviour to the existing vocabulary `KWAM` (bind), `KWAT` (reference), and `KWAK` (live evaluation). It distinguishes declaration, captured value, and re-evaluation, while rejecting undefined names, duplicate declarations, type-invalid arithmetic, division by zero, and malformed arity.

## Diagnostic notation supported
- `KWAM⟨X, FRAPA⟨KI, TO⟩⟩` declares `X` and captures the result of `1 + 2`.
- `KWAT⟨X⟩` returns the captured value.
- `KWAK⟨X⟩` re-evaluates X's defining expression against the current external inputs.
- External inputs are passed to the test harness as a JSON object, e.g. `{"POSITION": 4}`.
- Quantity examples may include units, e.g. `2:MA` for 2 metres and `1:SE` for 1 second.

Angle brackets and commas are audit notation only; they are not declared Arcane words or proof of a valid spoken surface grammar.

## Provisional semantics selected for this prototype
1. `KWAM⟨name, expression⟩` evaluates the right-hand expression first, then stores both the expression and its resulting value. If evaluation fails, no binding is created.
2. A declaration cannot overwrite a name already declared in the same scope.
3. `KWAT⟨name⟩` returns the value captured at declaration time.
4. `KWAK⟨name⟩` re-evaluates the stored expression against the current external input environment.
5. Unknown names are errors; the evaluator never guesses.
6. `FRAPA` and `FRATA` require matching dimensions. `FRAKA` combines dimensions; `FRALA` subtracts dimensions and rejects a zero denominator.
7. These are implementation conventions for Phase 5.24 and require owner approval before being marked canon.

## Regression suite
| Test | Purpose | Result |
|---|---|---|
| P5.24-T01 | Declaration and captured reference | PASS |
| P5.24-T02 | Live reevaluation after input change | PASS |
| P5.24-T03 | Undefined binding rejection | PASS |
| P5.24-T04 | Duplicate declaration rejection | PASS |
| P5.24-T05 | Dimensional mismatch rejection | PASS |
| P5.24-T06 | Division-by-zero rejection | PASS |
| P5.24-T07 | Failed declaration is atomic | PASS |
| P5.24-T08 | Captured value remains stable while live value changes | PASS |
| P5.24-T09 | Nested arithmetic inside a binding | PASS |
| P5.24-T10 | Invalid operator arity rejection | PASS |

Tests are design-level regression checks against this Python prototype, not a compiler validation of the entire Arcane language and not tests of actual mana or physical effects.

## Run
Requires Python 3.10+; no third-party packages.

```bash
python arcane_phase_5_24.py --selftest
python arcane_phase_5_24.py --selftest --json
python arcane_phase_5_24.py --expr 'FRAPA⟨KI, TO⟩'
python arcane_phase_5_24.py --expr 'KWAM⟨P, POSITION⟩' --inputs '{"POSITION": 4}'
```

A multi-expression session is demonstrated by the test functions; the command-line interface evaluates one expression per invocation, so declarations do not persist between separate CLI runs.

## Not implemented yet
- Nested lexical scopes and shadowing policy.
- Forward references, recursive bindings, dependency cycles, and declaration ordering beyond sequential evaluation.
- Explicit mutable state or assignment semantics for external inputs.
- Canonical treatment of whether `KWAM` should capture a value, store a deferred expression, or support both modes through an explicit binding type.
- Boolean, vector, observation, reference, temporal, and control-expression types.
- Spoken boundaries, modifier scope, and unique-parse proof for surface Arcane.
- Spell compilation and physical feasibility checks.

## Next phase recommendation
Phase 5.25 should settle the binding model with a decision record before adding complexity: compare (A) value-only binding, (B) expression-only binding, and (C) typed captured/live bindings. Then specify scope, shadowing, forward references, and dependency cycles; add tests before implementing control flow.
