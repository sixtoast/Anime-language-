# Arcane Phase 6H — End-to-End Pipeline Prototype

**Status:** narrow integration prototype; not canon-locked and not a complete Arcane implementation.

## Purpose

Phase 6H joins a surface parser, a small static type checker and a runtime evaluator into one executable path. It verifies that supported expressions can move between stages and that failures are reported at the appropriate stage.

## Pipeline

1. **Parse:** whitespace-tokenised romanised input becomes a small AST (`Num`, `Word`, `Call`, `Block`).
2. **Type-check:** verify supported operand types, binding references, and limited unit compatibility.
3. **Evaluate:** compute supported arithmetic and Boolean operations, with a runtime step budget.
4. **Report:** distinguish parse, type-check and runtime errors.

## Enabled subset

- Numerals formed from the consolidated digit words, optional `SHI` decimal fraction, and a unit closure.
- Arithmetic: `FRAPA`, `FRAJA`, `FRAMA`, `FRALA`, `FRASHA`.
- Boolean logic: `GRAN`, `GRAT`, `GRASH`.
- Bindings: `KWAM`, `KWAT`, `KWASH`, with numeric identifiers closed by `SHO`.
- Control structure parsing for `BEK`, `ZET`, and proposed `KOLE`, using `METO ... DOGU`.
- Legacy normalisation for aliases recorded in the script.

## Validation

Run `python arcane_phase6h_pipeline.py` in this directory. The current regression suite passes **15/15 tests**:

- end-to-end addition and nested arithmetic;
- legacy alias normalisation;
- unit mismatch caught by the checker;
- malformed numeral and control delimiter rejection;
- unbound binding rejection and stored binding roundtrip;
- Boolean NOT, AND and OR;
- division-by-zero runtime error;
- unknown word and trailing-token rejection.

`BOOL_TRUE`, `BOOL_FALSE`, and `BOOL_A` are test-harness fixtures only. They are not asserted to be canonical Arcane vocabulary.

## Known limitations

- This is a whitespace-token parser, not a phonological, prosodic, sigil or vernacular parser.
- The signatures enabled here are a small subset of the lexicon; unsupported operators fail rather than guessing.
- Unit checking is deliberately rudimentary. There is no complete dimensional algebra, unit conversion, coordinate-frame validation or context binding system.
- `FRAMA` only supports multiplication where at least one operand is dimensionless in this prototype. `FRALA` requires a dimensionless divisor.
- Control blocks are parsed and type-checked, but this test suite does not certify their full operational semantics. Loops can still run until the runtime step budget is exceeded if their condition never changes.
- `KOLE`, `METO`, and `DOGU` are marked proposed in the supplied lexicon. Their use here follows the recovered Phase 4 grammar description but does not promote their status to canon.
- No Construction compiler, mana accounting, targeting, physical-feasibility analysis or real-world effect is implemented.
- Passing tests validate only this declared subset; they do not prove that the complete language is working.

## Decision record

- **Implemented:** one explicit AST shared by parser, checker and evaluator.
- **Implemented:** stage-specific failures and fail-closed handling for unknown forms and unsupported signatures.
- **Not decided:** complete operator signatures, final unit algebra, lexical homophone disambiguation, binding scope/lifetime, construction compilation.
- **Next:** expand enabled signatures only against source-backed grammar, add property-based malformed-input tests, and define unit/frame rules before integrating the Construction subsystem.
