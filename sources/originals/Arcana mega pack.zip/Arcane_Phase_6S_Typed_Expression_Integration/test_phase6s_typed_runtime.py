import unittest
from decimal import Decimal
from arcane_reference_runtime import Number, Boolean, Call, parse
from arcane_dimensions import Dimension, Quantity, DIMENSIONLESS
from arcane_typed_runtime import QuantityLiteral, TypedEvaluationError, evaluate_typed

L = Dimension.of({'L': 1})
M = Dimension.of({'M': 1})
T = Dimension.of({'T': 1})
SPEED = Dimension.of({'L': 1, 'T': -1})

def q(value, dimension=DIMENSIONLESS):
    return Quantity(Decimal(str(value)), dimension)
def call(op, *args):
    return Call(op, tuple(args))
def lit(value, dimension=DIMENSIONLESS):
    return QuantityLiteral(q(value, dimension))

class TestPhase6STypedIntegration(unittest.TestCase):
    def test_bare_number_becomes_dimensionless_quantity(self):
        self.assertEqual(evaluate_typed(parse('7')), q(7))
    def test_parsed_addition_remains_dimensionless(self):
        self.assertEqual(evaluate_typed(parse('(frapa 2 3)')), q(5))
    def test_typed_addition_same_dimension(self):
        self.assertEqual(evaluate_typed(call('frapa', lit(2,L), lit(3,L))), q(5,L))
    def test_typed_subtraction_same_dimension(self):
        self.assertEqual(evaluate_typed(call('fraja', lit(8,T), lit(3,T))), q(5,T))
    def test_incompatible_addition_rejected(self):
        with self.assertRaises(TypedEvaluationError): evaluate_typed(call('frapa', lit(2,M), lit(1,T)))
    def test_incompatible_subtraction_rejected(self):
        with self.assertRaises(TypedEvaluationError): evaluate_typed(call('fraja', lit(2,L), lit(1,T)))
    def test_multiplication_propagates_dimensions(self):
        self.assertEqual(evaluate_typed(call('frama', lit(3,L), lit(4,T))), q(12, Dimension.of({'L':1,'T':1})))
    def test_division_propagates_dimensions(self):
        self.assertEqual(evaluate_typed(call('frala', lit(12,L), lit(3,T))), q(4,SPEED))
    def test_division_cancels_equal_dimensions(self):
        self.assertEqual(evaluate_typed(call('frala', lit(8,L), lit(2,L))), q(4))
    def test_division_by_zero_rejected(self):
        with self.assertRaises(TypedEvaluationError): evaluate_typed(call('frala', lit(1,L), lit(0,T)))
    def test_negation_preserves_dimension(self):
        self.assertEqual(evaluate_typed(call('frasha', lit(5,M))), q(-5,M))
    def test_boolean_and_still_works(self):
        self.assertIs(evaluate_typed(parse('(gran true false)')), False)
    def test_boolean_and_rejects_quantity(self):
        with self.assertRaises(TypedEvaluationError): evaluate_typed(call('gran', lit(1), Boolean(True)))
    def test_numeric_operator_rejects_boolean(self):
        with self.assertRaises(TypedEvaluationError): evaluate_typed(call('frapa', Boolean(True), Number(Decimal(1))))
    def test_nested_typed_expression(self):
        # 2L + (3L * 4 dimensionless) = 14L
        expr = call('frapa', lit(2,L), call('frama', lit(3,L), Number(Decimal(4))))
        self.assertEqual(evaluate_typed(expr), q(14,L))
    def test_existing_grammar_ast_integrates(self):
        expr = parse('(fraja 2 (frapa 3 4))')
        self.assertEqual(evaluate_typed(expr), q(-5))
    def test_unknown_operator_rejected(self):
        with self.assertRaises(TypedEvaluationError): evaluate_typed(Call('kole', (Number(Decimal(1)),)))

if __name__ == '__main__': unittest.main(verbosity=2)
