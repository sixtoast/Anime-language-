import unittest
from decimal import Decimal
from arcane_dimensions import Dimension, DimensionError, Quantity, DIMENSIONLESS

MASS = Dimension.of({'M': 1})
LENGTH = Dimension.of({'L': 1})
TIME = Dimension.of({'T': 1})

class TestPhase6RDimensions(unittest.TestCase):
    def q(self, n, d=DIMENSIONLESS): return Quantity(Decimal(str(n)), d)
    def test_dimensionless_is_empty_vector(self): self.assertEqual(DIMENSIONLESS.powers, ())
    def test_dimension_canonical_order(self): self.assertEqual(Dimension.of({'T': 1, 'L': 1}), Dimension.of({'L': 1, 'T': 1}))
    def test_zero_exponents_are_removed(self): self.assertEqual(Dimension.of({'L': 0}), DIMENSIONLESS)
    def test_rejects_empty_dimension_symbol(self):
        with self.assertRaises(DimensionError): Dimension.of({' ': 1})
    def test_rejects_noninteger_exponent(self):
        with self.assertRaises(DimensionError): Dimension.of({'L': 0.5})
    def test_add_same_dimensions(self): self.assertEqual(self.q(2,LENGTH).add(self.q(3,LENGTH)), self.q(5,LENGTH))
    def test_subtract_same_dimensions(self): self.assertEqual(self.q(8,TIME).subtract(self.q(3,TIME)), self.q(5,TIME))
    def test_add_incompatible_dimensions_rejected(self):
        with self.assertRaises(DimensionError): self.q(2,MASS).add(self.q(1,TIME))
    def test_subtract_incompatible_dimensions_rejected(self):
        with self.assertRaises(DimensionError): self.q(2,LENGTH).subtract(self.q(1,TIME))
    def test_multiply_combines_dimensions(self):
        self.assertEqual(self.q(3,LENGTH).multiply(self.q(4,TIME)), self.q(12,Dimension.of({'L':1,'T':1})))
    def test_divide_subtracts_dimension_exponents(self):
        self.assertEqual(self.q(12,LENGTH).divide(self.q(3,TIME)), self.q(4,Dimension.of({'L':1,'T':-1})))
    def test_same_dimension_division_becomes_dimensionless(self):
        self.assertEqual(self.q(8,LENGTH).divide(self.q(2,LENGTH)), self.q(4))
    def test_multiply_cancels_opposite_exponents(self):
        speed = Dimension.of({'L':1,'T':-1})
        self.assertEqual(speed.combine(TIME), LENGTH)
    def test_division_by_zero_rejected(self):
        with self.assertRaises(DimensionError): self.q(1,LENGTH).divide(self.q(0,TIME))
    def test_negation_preserves_dimension(self): self.assertEqual(self.q(5,MASS).negate(), self.q(-5,MASS))
    def test_non_quantity_operand_rejected(self):
        with self.assertRaises(DimensionError): self.q(1).add(2)
    def test_quantity_requires_decimal(self):
        with self.assertRaises(DimensionError): Quantity(2, LENGTH)

if __name__ == '__main__': unittest.main(verbosity=2)
