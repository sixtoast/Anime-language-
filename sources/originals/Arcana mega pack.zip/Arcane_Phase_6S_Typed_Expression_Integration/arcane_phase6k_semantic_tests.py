#!/usr/bin/env python3
"""Arcane Phase 6K: source-backed corrective semantic tests.

This module validates the recovered unary numeric meaning of FRASHA (negate).
It is intentionally not a patch to the unavailable Phase 6H runtime file.
"""
from decimal import Decimal
import unittest


def frasha_negate(value: Decimal) -> Decimal:
    """Reference contract: FRASHA negates a numeric value; it is not abs()."""
    if not isinstance(value, Decimal):
        raise TypeError("FRASHA reference contract requires Decimal numeric input")
    return -value


class FrashaContractTests(unittest.TestCase):
    def test_positive_to_negative(self):
        self.assertEqual(frasha_negate(Decimal("3")), Decimal("-3"))

    def test_negative_to_positive(self):
        self.assertEqual(frasha_negate(Decimal("-3")), Decimal("3"))

    def test_zero_remains_zero(self):
        self.assertEqual(frasha_negate(Decimal("0")), Decimal("0"))

    def test_fractional_value(self):
        self.assertEqual(frasha_negate(Decimal("1.25")), Decimal("-1.25"))

    def test_not_absolute_value(self):
        value = Decimal("3")
        self.assertNotEqual(frasha_negate(value), abs(value))

    def test_rejects_non_numeric_fixture(self):
        with self.assertRaises(TypeError):
            frasha_negate(True)  # bool is not an Arcane numeric value


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(FrashaContractTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(0 if result.wasSuccessful() else 1)
