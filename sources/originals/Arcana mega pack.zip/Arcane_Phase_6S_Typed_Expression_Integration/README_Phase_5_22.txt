Arcane Phase 5.22 — Bounded Construction Parser

Contents:
- Arcane_Phase_5_22_Report.md: scope, results, decisions and next steps.
- arcane_phase_5_22_parser.py: standard-library Python parser and tests.
- Arcane_Phase_5_22_Results.json: machine-readable test results.
- Arcane_Lexicon_v5_draft.csv: source lexicon carried forward.
- Arcane_Language_Audit_Phase_4.docx: source evidence.

Run tests: python arcane_phase_5_22_parser.py --test
Parse the documented fixture: python arcane_phase_5_22_parser.py

This is a fixture-specific parser, not a complete Arcane parser. No canon was changed.
