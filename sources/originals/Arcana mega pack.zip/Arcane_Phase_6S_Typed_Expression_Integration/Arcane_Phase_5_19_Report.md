# Arcane Phase 5.19 — Register-Gating Audit

**Status:** source-backed lexical checks complete; register execution remains blocked. No spelling, grammar, or canonical rule has changed.

## Purpose

Phase 5.18 identified exactly two duplicated spellings in the merged Phase 5 lexicon: `re` and `ra`. Phase 5.19 tests what the current source can prove about those entries and explicitly separates lexical evidence from grammatical behaviour. This is not a parser and does not claim that either collision is safe in speech or execution.

## Inputs

- `Arcane_Lexicon_v5_draft.csv` (the merged Phase 5 lexicon from the supplied archive)
- Phase 5.18 report and results, retained as regression context
- `arcane_phase_5_19_register_gate.py` (new repeatable harness)

## Results

| Test | Status | Finding |
|---|---|---|
| RG-01 Shared digit `re` | PASS | Exactly one `re = 4` DIGIT entry in Shared, source `v3.0-L`. |
| RG-02 Performed target-surface `re` | BLOCKED | The v2.0 FUSED-REF entry exists, but slot grammar, fusion decomposition, and legal host construction are not recovered. |
| RG-03 Shared unit `ra` | PASS | Exactly one `ra = radian` UNIT entry in Shared, source `v3.0-L`. |
| RG-04 Performed target-path `ra` | BLOCKED | The v2.0 FUSED-REF entry exists, but slot grammar, fusion decomposition, and legal host construction are not recovered. |
| RG-05 Mixed-register rejection | BLOCKED | Candidate safety rule only; no recovered normative register-transition rule. Do not treat as canon. |
| RG-06 Reject multiple parses | BLOCKED | The Unique Parse Requirement is canonical, but there is no complete parser/surface grammar to execute this test. |
| RG-07 Homograph provenance | PASS | Both readings of both collisions have distinct gloss, register, and source metadata. |
| RG-08 Duplicate inventory scope | PASS | The only duplicated spellings in the current lexicon are `re` and `ra`. |

**Counts: 4 PASS, 0 FAIL, 4 BLOCKED, 0 NOT TESTED.** PASS refers only to static source facts. BLOCKED is not a pass and must not be presented as one.

## Findings and decisions

### Decision P5.19-D1 — preserve `re` and `ra` provisionally

Keep the four source-backed entries as-is. Their source labels are:

- `re` / `4` / DIGIT / Shared / CANON / `v3.0-L`
- `re` / `TARGET-surface` / FUSED-REF / Performed / CANON (v2.0) / `v2.0`
- `ra` / `radian` / UNIT / Shared / CANON / `v3.0-L`
- `ra` / `TARGET-path` / FUSED-REF / Performed / CANON (v2.0) / `v2.0`

This is a preservation decision, not a safety certification. It follows the stated rename policy: preserve old forms as aliases unless an actual inconsistency is demonstrated.

### Decision P5.19-D2 — do not canonise blanket mixed-register rejection

A rule that rejects mixed Shared/Performed constructions may be a useful parser safeguard, but it is not yet supported as historical canon. First recover whether v2.0 permits register transitions or treats the Performed register as a distinct construction mode. If the source cannot be recovered, present an explicit proposed replacement rule for owner approval instead of silently claiming it was always canon.

### Decision P5.19-D3 — unique parse remains a requirement, not a verified implementation

If an executable expression has more than one valid interpretation, it must fail rather than guess. The principle is canonical; proof that an implementation enforces it awaits a grammar and parser.

## What Phase 5.19 does not establish

- It does not prove that listeners distinguish the homographs in natural speech.
- It does not define Performed reference morphology or infer the missing scope vowel map.
- It does not establish which mixed-register constructions are legal.
- It does not validate the meaning, physical mechanism, or feasibility of any spell.

## Phase 5.20 — recommended next work

1. Search the supplied archive and prior phase documents specifically for the original v2.0 fused-reference table, parameter-vowel/scope mapping, `h` coupling, and examples containing `re` or `ra`.
2. Build a source-evidence matrix: exact quotation/paraphrase, file/page/section, rule, confidence, and conflicts.
3. If source evidence is found, implement a minimal parser for only the recovered construction and create positive/negative fixtures. Do not generalise beyond evidence.
4. If source evidence is not found, mark the historic rule UNRECOVERED and draft a replacement as a proposed change with alternatives and owner decision.
5. Keep `re` and `ra` unchanged until the tests show a real ambiguity in a legal construction or the owner approves a controlled rename/alias plan.

## Reproduction

From the package directory, run:

```bash
python arcane_phase_5_19_register_gate.py
```

An optional first argument supplies an alternate lexicon CSV. The harness exits non-zero only for a FAIL; BLOCKED checks are intentionally visible in the report and must not be mistaken for successful validation.
