# Arcane Phase 5.13 — Minimal Typed AST and Validator

**Status:** audit prototype, not a production compiler and not a canon change.

## Goal

Exercise the Phase 5.12 registry through a minimal recursive parser. The prototype parses a diagnostic notation, builds a typed abstract syntax tree (AST), normalises recorded aliases, checks arity, and validates a deliberately small subset of type and dimension rules.

## Audit notation

This is testing metalanguage only; angle brackets and commas are not claimed to be spoken Arcane.

- `Q<1,L>` — quantity with value 1 and dimension label `L` (length)
- `Q<2,T>` — quantity with value 2 and dimension label `T` (time)
- `B<true>` — Boolean literal
- `V<L,world>` — vector with dimension `L` in frame `world`
- `ID<1>` — binding identifier
- `FRAPA<arg1,arg2>` — nested operator expression

The harness uses exact rational values where relevant.

## Implemented behaviours

- Recursive parsing of nested expressions.
- Rejection of malformed delimiters, missing/extra arguments, unknown operators and trailing tokens.
- Alias normalisation using Phase 5.12's registry (`FRATA` normalises to `FRAJA`, etc.).
- Basic dimensional checks for add/subtract/multiply/divide and Boolean checks for AND/OR/NOT.
- Explicit division-by-zero rejection.
- Strict mode fails closed when an operator's signature is provisional, open or proposed.

## Results

**14/14 tests passed.** See `Arcane_Phase_5_13_Test_Results.txt`.

## Limitations

1. This only implements type rules for a small arithmetic/Boolean subset.
2. Most registry entries intentionally fail closed because their contracts are not yet fully defined.
3. It does not compile Construction/Foot expressions or the Phase 4 `METO`/`DOGU` block grammar.
4. It does not validate physical feasibility, mana coupling, energy, or spell execution.
5. It does not prove spoken Arcane has unique parses; the parser consumes explicit audit delimiters.
6. Dimension labels are test labels, not Arcane words or a complete SI dimension system.
7. `strict=False` is for audit testing only. It must not be interpreted as permission to execute underspecified operators.

## Change-control result

No operator signature has been promoted to canon by this prototype. The registry remains provisional. Strict-mode rejection is intentional: the correct next step is to resolve the signatures with source evidence, not to weaken the validator until every expression passes.

## Next step: Phase 5.14

Create a signature-resolution matrix. For each open operator, identify the exact source rule, competing interpretations, smallest distinguishing test cases, and decision status. Prioritise `DRAS` comparison criteria, `SIMA` measurement inputs, `KWASH` evaluation timing, `BEK`/`ZET` block semantics, and the v2.0 construction macros.
