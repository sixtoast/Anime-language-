Arcane Phase 5.14 package

Contents:
- Arcane_Phase_5_14_Signature_Resolution.md: signature-resolution evidence matrix and completeness assessment.
- arcane_phase514_gate.py: executable policy-gate checks against the Phase 5.12 registry.
- Arcane_Phase_5_14_Test_Results.txt: test results.
- Phase 5.12 registry CSV/JSON and report.
- Phase 5.13 AST validator and report/test results.
- Phase 5.10 and 5.11 test results and implementation files where available.
- Recovered Phase 2, Phase 4 and Phase 5 audit sources and lexicon drafts.

Scope warning: this is an audit package, not a production compiler or spell runtime. No new language rule is promoted to canon.
