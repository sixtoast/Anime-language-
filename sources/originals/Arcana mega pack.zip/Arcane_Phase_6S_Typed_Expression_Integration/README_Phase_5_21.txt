ARCANE PHASE 5.21 — EVIDENCE-BOUNDED CONSTRUCTION CONFORMANCE FIXTURES

Run: python arcane_phase_5_21_fixtures.py
Expected result: 11 PASS, 0 FAIL, 3 BLOCKED.

This is a fixture validator, not a general Arcane parser. It checks documented lexicon entries, explicit-slot lexical resolution, ambiguity visibility without a slot, and the exact Phase 4 hand-flame transcription. It deliberately blocks claims requiring the complete productive grammar. No canon changed.
