# Arcane Phase 6I — Contract and Dimensional-Safety Audit

**Status:** audit/test milestone; no new language rules are canon-locked.

## Purpose

Phase 6I adds a separate regression audit over the Phase 6H parser → type checker → evaluator. It checks the behaviours the current subset claims to support and verifies that invalid cases fail at the expected stage. It does not silently add operator meanings or define the physical dimensions of Arcane units.

## Result

**22/22 audit tests pass** using `arcane_phase6i_contract_audit.py` against `arcane_phase6h_pipeline.py` and the bundled `Arcane_Lexicon_v5_draft.csv`.

Coverage:

- arithmetic values and preservation of the current unit labels;
- addition/subtraction rejection when unit labels differ;
- current restricted multiplication and division rules;
- runtime division-by-zero rejection;
- Boolean type checks using test-only fixture words;
- IF condition type validation;
- numeral closure and malformed decimal rejection;
- unknown/trailing token rejection;
- explicit control block delimiter checks;
- unbound binding reference rejection.

## Unit safety contract currently enforced

| Operation | Current prototype rule | Limitation |
|---|---|---|
| `FRAPA` / `FRAJA` | Operand types must be numeric and unit labels identical | No conversion between units |
| `FRAMA` | Numeric operands; at least one operand must be `SHO` | No dimensional product algebra |
| `FRALA` | Numeric operands; divisor must be `SHO` | No reciprocal dimensions or conversion |
| `FRASHA` | Numeric operand; preserves unit label | Exact canonical meaning still depends on source audit |

These are implementation constraints for the current subset, not a complete dimensional theory. The symbols `MA`, `SE`, `KE`, `RA`, `KU`, `SHO`, and `VO` must not be treated as interchangeable or assigned physical dimensions without evidence from the language specification.

## What this phase found

The first audit run produced two test failures: one expected `3 / 2` to equal `1`, and another searched for wording that did not match the type checker's actual error message. Both were defects in the audit expectations, not failures of the implementation. The expectations were corrected to `1.5` and to match the actual error contract; the complete audit then passed 22/22.

This is a useful example of why expected results must be checked independently instead of treating every failed test as a runtime defect.

## Not yet implemented or proven

- Canonical physical dimensions and conversion rules.
- A complete operator/signature registry sourced from the audit documents.
- Boolean short-circuit rules, unless explicitly documented by Arcane canon.
- Fully integrated binding scope/lifetime across expression sequences.
- Complete loop termination semantics and loop mutation rules.
- Homophone disambiguation, speech/prosody and alternate input forms.
- Construction compilation, mana accounting, targeting and physical feasibility.

## Decision record

- **Chosen:** keep the audit separate from the runtime so the test contract is inspectable.
- **Chosen:** reject unknown or unsupported forms rather than infer behaviour.
- **Chosen:** document the unit restrictions as prototype rules, not canonical physics.
- **Not decided:** unit ontology, conversion algebra, complete signatures, scope and construction semantics.
- **Next:** inspect the source audit for authoritative unit meanings and operator definitions; then design a dimension model only where the source gives enough information.
