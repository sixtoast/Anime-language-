# Arcane Phase 7R — Syntax Checking and Developer Tooling

## Delivered
- Added `arcane_check.py`, a standalone static checker for the reconstructed, provisional line-oriented Arcane subset.
- Added `arcane_cli.py` with file-based syntax checking, readable diagnostics, and meaningful process exit codes (0 for valid input, 1 for errors).
- Checks conditional block balance, missing/unexpected `END`, `ELSE` without a block, duplicate `ELSE`, malformed block headers, and common statement shapes.
- Preserves original source line numbers, including blank lines and comments.
- Added valid and invalid `.arc` examples plus unit tests.

## Validation
- `python -m unittest -v`: 10 tests passed.
- Valid example exits with status 0.
- Invalid example reports malformed block structure and exits nonzero.

## Important scope note
The Phase 7Q runtime package was not present in the active workspace; only the historical `Arcana pack.zip` was available. Accordingly, Phase 7R is delivered as a standalone static-checking tool, not as an update to a verified Phase 7Q runtime. It does **not** execute programs or type-check/evaluate expressions. Its accepted statement patterns are intentionally approximate and syntax remains provisional. This checker must not be mistaken for the canonical Arcane parser or a guarantee that a program will execute successfully.

## Run
```bash
python -m unittest -v
python arcane_cli.py example_valid.arc
python arcane_cli.py example_invalid.arc
```
