import unittest
from arcane_runtime import ArcaneRuntime, Quantity, Diagnostic, show

class Phase7NTests(unittest.TestCase):
 def setUp(self): self.r=ArcaneRuntime()
 def test_function_define(self): self.assertIn('defined',self.r.run_line('KWAF square(x) => FRATA $x $x'))
 def test_function_call(self):
  self.r.run_line('KWAF square(x) => FRATA $x $x'); self.assertEqual(self.r.evaluate('square(4)').value,16)
 def test_function_multiple_args(self):
  self.r.run_line('KWAF add(x, y) => FRAPA $x $y'); self.assertEqual(self.r.evaluate('add(4, 5)').value,9)
 def test_function_nested(self):
  self.r.run_line('KWAF square(x) => FRATA $x $x'); self.r.run_line('KWAF fourth(x) => square(square($x))'); self.assertEqual(self.r.evaluate('fourth(2)').value,16)
 def test_function_scope(self):
  self.r.run_line('KWAF ident(x) => $x'); self.r.evaluate('ident(2)')
  self.assertEqual(self.r.run_line('KWAT x').code,'ARC-NAME-001')
 def test_wrong_arity(self):
  self.r.run_line('KWAF ident(x) => $x'); self.assertEqual(self.r.run_line('ident()').code,'ARC-TYPE-001')
 def test_duplicate_function_parameter(self): self.assertEqual(self.r.run_line('KWAF bad(x,x) => $x').code,'ARC-PARSE-001')
 def test_duplicate_function_name(self):
  self.r.run_line('KWAF f(x) => $x'); self.assertEqual(self.r.run_line('KWAF f(y) => $y').code,'ARC-NAME-002')
 def test_unknown_parameter_in_body(self):
  self.r.run_line('KWAF bad(x) => $z'); self.assertEqual(self.r.run_line('bad(1)').code,'ARC-NAME-001')
 def test_recursion_limit(self):
  self.r.max_call_depth=5; self.r.run_line('KWAF loop(x) => loop($x)'); out=self.r.run_line('loop(1)'); self.assertEqual(out.code,'ARC-RUNTIME-001')
 def test_function_with_unit(self):
  self.r.run_line('KWAF twice(x) => FRATA $x 2'); self.assertEqual(self.r.evaluate('twice(m)').dimensions,(1,0,0))
 def test_repetition(self): self.assertEqual([x.value for x in self.r.run_line('KWAR i FROM 1 TO 3 => FRATA $i $i')],[1,4,9])
 def test_aggregation(self): self.assertEqual(self.r.run_line('KWAS s FROM 1 TO 5 => $s').value,15)
 def test_short_circuit_and(self): self.assertFalse(self.r.evaluate('FRAND 0 $missing'))
 def test_short_circuit_or(self): self.assertTrue(self.r.evaluate('FROR 1 $missing'))
 def test_units_mismatch(self): self.assertEqual(self.r.run_line('FRAPA m s').code,'ARC-UNIT-001')
 def test_div_zero(self): self.assertEqual(self.r.run_line('FRAKA 1 0').code,'ARC-MATH-001')
 def test_iteration_limit(self): self.r.max_iterations=2; self.assertEqual(self.r.run_line('KWAR i FROM 1 TO 3 => $i').code,'ARC-LOOP-002')
 def test_binding(self): self.r.run_line('KWAM total => FRAPA 2 3'); self.assertEqual(self.r.run_line('KWAT total').value,5)
 def test_unknown_name(self): self.assertEqual(self.r.run_line('$wat').code,'ARC-NAME-001')
 def test_show(self): self.assertEqual(show(Quantity(3)),'3 dimensionless')
 def test_function_inside_repetition(self):
  self.r.run_line('KWAF square(x) => FRATA $x $x'); self.assertEqual([x.value for x in self.r.run_line('KWAR i FROM 1 TO 3 => square($i)')],[1,4,9])
 def test_function_inside_aggregation(self):
  self.r.run_line('KWAF square(x) => FRATA $x $x'); self.assertEqual(self.r.run_line('KWAS total FROM 1 TO 3 => square($total)').value,14)

if __name__=='__main__':unittest.main(verbosity=2)
