# Arcane Phase 7C — Persistent Sessions and Transactional Execution

## Outcome
The runtime now has a persistent interactive session and script runner. Users can issue multiple statements in one environment, inspect bindings, enter/leave nested scopes, and continue after a failed statement. Every language statement executes transactionally: on an Arcane error or unexpected exception, the environment is restored to its pre-statement snapshot.

## Quick start
Requires Python 3.10+ and only the standard library.

```bash
python arcane_session.py
python arcane_session.py --script example.arc
python -m unittest -v test_arcane_runtime test_arcane_session
```

Example interactive session:

```text
arcane> KWAS distance = 2@m
2 m
arcane> KWAK total = FRAPA $distance 30@cm
2.3 m
arcane> KWAS distance <- 5@m
5 m
arcane> KWAT total
5.3 m
arcane> :scope in
entered scope 1
arcane> KWAM distance = 1@m
1 m
arcane> KWAT distance
1 m
arcane> :scope out
left scope; depth 0
arcane> KWAT distance
5 m
```

## Implemented
- One persistent `Environment` for the lifetime of an interactive session.
- `:help`, `:quit`, `:scope`, `:scope in`, `:scope out`, and `:env` commands.
- UTF-8 script execution with line-numbered output and continuation after a failing statement.
- Transactional rollback for each statement on language or unexpected runtime errors.
- Error messages include the statement number for session-level failures.
- Prior arithmetic, dimensional checks, bindings, mutable state and scopes remain integrated.

## Verification
The combined Phase 7B runtime and Phase 7C session suite passes **29 tests**. This is regression evidence for the included code only, not a claim of full Arcane conformance.

## Canon boundary and limitations
Interactive commands and the current Arcane syntax remain a provisional implementation profile, not a canon change. Each statement is atomic, but a multi-statement script is not one all-or-nothing transaction: earlier successful statements remain committed if a later statement fails. Session state is in memory only and is not persisted after the process exits. There is no editor, debugger, module system, or canonical grammar lock yet.

## Acceptance result
This phase makes the runtime materially more usable: it can run a sequence of statements, inspect and mutate live state, use scopes, recover from errors, and execute scripts. The next phase should add a small module/function capability or structured control flow through this same runtime, not restart broad auditing.
