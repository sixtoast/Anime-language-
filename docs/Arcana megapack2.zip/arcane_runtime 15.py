"""Arcane Phase 7N: compact runnable subset with user-defined functions.
All grammar spellings here are provisional implementation syntax, not canonical decisions.
"""
from dataclasses import dataclass
import re

@dataclass(frozen=True)
class Diagnostic:
    code: str
    message: str
    line: int = 1
    column: int = 1
    hint: str = ''
    def render(self):
        s=f'{self.code} at {self.line}:{self.column}: {self.message}'
        return s + (f'\n  hint: {self.hint}' if self.hint else '')

class ArcaneError(Exception):
    def __init__(self, code, message, hint=''):
        self.diagnostic=Diagnostic(code,message,hint=hint)
        super().__init__(self.diagnostic.render())

@dataclass(frozen=True)
class Quantity:
    value: float
    dimensions: tuple[int,...]=()
    def same(self, other):
        if not isinstance(other,Quantity): raise ArcaneError('ARC-TYPE-001','numeric value required')
        if self.dimensions != other.dimensions: raise ArcaneError('ARC-UNIT-001','dimension mismatch','Use quantities with compatible dimensions.')
    def __add__(self,o): self.same(o); return Quantity(self.value+o.value,self.dimensions)
    def __sub__(self,o): self.same(o); return Quantity(self.value-o.value,self.dimensions)
    def __mul__(self,o):
        self.same_numeric(o); n=max(len(self.dimensions),len(o.dimensions)); a=self.dimensions+(0,)*(n-len(self.dimensions)); b=o.dimensions+(0,)*(n-len(o.dimensions)); return Quantity(self.value*o.value,tuple(x+y for x,y in zip(a,b)))
    def __truediv__(self,o):
        self.same_numeric(o)
        if o.value==0: raise ArcaneError('ARC-MATH-001','division by zero','Check the denominator before dividing.')
        n=max(len(self.dimensions),len(o.dimensions)); a=self.dimensions+(0,)*(n-len(self.dimensions)); b=o.dimensions+(0,)*(n-len(o.dimensions)); return Quantity(self.value/o.value,tuple(x-y for x,y in zip(a,b)))
    def same_numeric(self,o):
        if not isinstance(o,Quantity): raise ArcaneError('ARC-TYPE-001','numeric value required')

UNITS={'1':Quantity(1), 'm':Quantity(1,(1,0,0)), 'cm':Quantity(.01,(1,0,0)), 'km':Quantity(1000,(1,0,0)), 's':Quantity(1,(0,1,0)), 'kg':Quantity(1,(0,0,1))}
TOKEN=re.compile(r'\s*(?:(\d+(?:\.\d+)?)|(\$?[A-Za-z_][A-Za-z_0-9]*)|(=>)|(\()|(\))|(,))')

class ArcaneRuntime:
    def __init__(self,max_iterations=1000,max_call_depth=64):
        self.bindings={}; self.functions={}; self.scopes=[]; self.max_iterations=max_iterations; self.max_call_depth=max_call_depth
    def define(self,name,value):
        target=self.scopes[-1] if self.scopes else self.bindings
        if name in target: raise ArcaneError('ARC-NAME-002',f'duplicate binding {name}')
        if not self.scopes and (name in self.functions): raise ArcaneError('ARC-NAME-002',f'name already defined: {name}')
        target[name]=value; return value

    def _lookup_binding(self,name,locals_):
        if name in locals_: return locals_[name]
        for scope in reversed(self.scopes):
            if name in scope: return scope[name]
        if name in self.bindings: return self.bindings[name]
        raise ArcaneError('ARC-NAME-001',f'unknown binding {name}','Check the spelling and scope.')
    def _tokenize(self,src):
        out=[]; p=0
        while p<len(src):
            if src[p:].strip()=='': break
            m=TOKEN.match(src,p)
            if not m: raise ArcaneError('ARC-PARSE-001',f'unexpected token at column {p+1}','Check spelling and delimiters.')
            out.append(next(x for x in m.groups() if x is not None)); p=m.end()
        return out
    def evaluate(self,src,locals_=None,depth=0):
        if depth>self.max_call_depth: raise ArcaneError('ARC-RUNTIME-001','maximum function call depth exceeded')
        locals_=locals_ or {}; ts=self._tokenize(src); i=0
        def expr(execute=True):
            nonlocal i
            if i>=len(ts): raise ArcaneError('ARC-PARSE-001','unexpected end of expression')
            t=ts[i]; i+=1
            if t=='(':
                v=expr(execute)
                if i>=len(ts) or ts[i]!=')': raise ArcaneError('ARC-PARSE-001','expected closing parenthesis')
                i+=1; return v
            if t.replace('.','',1).isdigit(): return Quantity(float(t)) if execute else None
            if t.startswith('$'):
                n=t[1:]
                if not execute:return None
                return self._lookup_binding(n,locals_)
            if t in ('FRNOT','FRAND','FROR'):
                if t=='FRNOT':
                    v=expr(execute); return (not self.truth(v)) if execute else None
                left=expr(execute)
                if not execute: expr(False); return None
                b=self.truth(left)
                if t=='FRAND' and not b: expr(False); return False
                if t=='FROR' and b: expr(False); return True
                return self.truth(expr(True))
            if t in ('FRAPA','FRALA','FRATA','FRAKA','FRAGT','FRALT','FRAEQ'):
                a=expr(execute); b=expr(execute)
                if not execute:return None
                if t=='FRAPA':return a+b
                if t=='FRALA':return a-b
                if t=='FRATA':return a*b
                if t=='FRAKA':return a/b
                a.same(b)
                return a.value>b.value if t=='FRAGT' else a.value<b.value if t=='FRALT' else a.value==b.value
            if t in UNITS:return UNITS[t] if execute else None
            if t in self.functions:
                if i>=len(ts) or ts[i]!='(': raise ArcaneError('ARC-PARSE-001',f'function {t} requires parentheses')
                i+=1; args=[]
                if i<len(ts) and ts[i]!=')':
                    while True:
                        args.append(expr(execute))
                        if i<len(ts) and ts[i]==',': i+=1; continue
                        break
                if i>=len(ts) or ts[i]!=')': raise ArcaneError('ARC-PARSE-001','expected ) after function arguments')
                i+=1
                if not execute:return None
                fn=self.functions[t]
                if len(args)!=len(fn['params']): raise ArcaneError('ARC-TYPE-001',f'{t} expects {len(fn["params"])} arguments, got {len(args)}')
                return self.evaluate(fn['body'],dict(zip(fn['params'],args)),depth+1)
            if not execute:return None
            raise ArcaneError('ARC-NAME-001',f'unknown name {t}')
        result=expr()
        if i!=len(ts): raise ArcaneError('ARC-PARSE-001',f'unexpected token {ts[i]}')
        return result
    @staticmethod
    def truth(v):
        if isinstance(v,bool):return v
        if isinstance(v,Quantity) and not v.dimensions and v.value in (0,1):return v.value==1
        raise ArcaneError('ARC-TYPE-001','logical operation requires boolean or dimensionless 0/1')
    @staticmethod
    def _bound(v):
        if not isinstance(v,Quantity) or v.dimensions or not v.value.is_integer(): raise ArcaneError('ARC-LOOP-001','bounds must be dimensionless integers')
        return int(v.value)
    def run_program(self, source):
        """Execute statements and KWAI/THEN/ELSE/END blocks; stop at first error.

        Block bindings are scoped to the selected branch and do not leak out.
        Syntax is provisional. Block headers and delimiters occupy their own lines.
        """
        lines=[]
        for number, raw in enumerate(source.splitlines(),1):
            text=raw.strip()
            if not text or text.startswith('#'):
                continue
            lines.append((number,text))
        def parse_block(index, stops=()):
            results=[]
            while index < len(lines):
                number,text=lines[index]
                if text in stops:
                    return results,index,text
                if text.startswith('KWAI ') and text.endswith(' THEN'):
                    condition=text[5:-5].strip()
                    if not condition:
                        return Diagnostic('ARC-PARSE-001','empty conditional condition',number),index,None
                    index+=1
                    yes,index,stop=parse_block(index,('ELSE','END'))
                    if isinstance(yes,Diagnostic): return yes,index,None
                    if stop is None:
                        return Diagnostic('ARC-PARSE-001','conditional block requires END',number,1,'Close each block with END.'),index,None
                    no=[]
                    if stop=='ELSE':
                        index+=1
                        no,index,stop=parse_block(index,('END',))
                        if isinstance(no,Diagnostic): return no,index,None
                        if stop!='END':
                            return Diagnostic('ARC-PARSE-001','ELSE branch requires END',number,1),index,None
                    index+=1
                    try: take_yes=self.truth(self.evaluate(condition))
                    except ArcaneError as e:
                        d=e.diagnostic
                        return Diagnostic(d.code,f'line {number}: {d.message}',number,d.column,d.hint),index,None
                    self.scopes.append({})
                    try:
                        chosen=yes if take_yes else no
                        # Execute only the chosen source statements, preserving nested control flow.
                        selected_numbers=set(n for n,_ in chosen)
                        # The parser above records execution results for both branches only as source tuples.
                        # Branches are re-executed through the source interpreter below.
                        branch_source='\n'.join(t for n,t in chosen)
                        branch_results=self.run_program(branch_source) if branch_source else []
                        if isinstance(branch_results,Diagnostic): return branch_results,index,None
                        results.extend(branch_results)
                    finally:
                        self.scopes.pop()
                    continue
                if text in ('ELSE','END'):
                    if text in stops:return results,index,text
                    return Diagnostic('ARC-PARSE-001',f'unexpected {text}',number),index,None
                result=self.run_line(text)
                if isinstance(result,Diagnostic):
                    return Diagnostic(result.code,f'line {number}: {result.message}',number,result.column,result.hint),index,None
                results.append(result); index+=1
            return results,index,None
        # Parser needs source tuples to retain block structure; this nested helper is
        # intentionally separate from evaluation to make malformed delimiters explicit.
        def parse_and_execute(index=0, stops=()):
            results=[]
            while index < len(lines):
                number,text=lines[index]
                if text in stops:return results,index,text
                m=re.fullmatch(r'KWAI\s+(.+?)\s+THEN',text)
                if m:
                    condition=m.group(1); index+=1
                    yes,index,stop=parse_and_execute(index,('ELSE','END'))
                    if isinstance(yes,Diagnostic):return yes,index,None
                    no=[]
                    if stop=='ELSE':
                        index+=1; no,index,stop=parse_and_execute(index,('END',))
                        if isinstance(no,Diagnostic):return no,index,None
                    if stop!='END':return Diagnostic('ARC-PARSE-001','conditional block requires END',number,1,'Close each conditional with END.'),index,None
                    index+=1
                    try: condition_value=self.truth(self.evaluate(condition))
                    except ArcaneError as e:
                        d=e.diagnostic; return Diagnostic(d.code,f'line {number}: {d.message}',number,d.column,d.hint),index,None
                    self.scopes.append({})
                    try:
                        # Branch nodes are (line_number, text) for simple statements and
                        # ('block', condition, yes, no, header_line) for nested blocks.
                        branch=yes if condition_value else no
                        def execute_nodes(nodes):
                            out=[]
                            for node in nodes:
                                if len(node)==5 and node[0]=='block':
                                    _,cond,yy,nn,ln=node
                                    try: val=self.truth(self.evaluate(cond))
                                    except ArcaneError as e:
                                        d=e.diagnostic; return Diagnostic(d.code,f'line {ln}: {d.message}',ln,d.column,d.hint)
                                    self.scopes.append({})
                                    try:
                                        r=execute_nodes(yy if val else nn)
                                        if isinstance(r,Diagnostic):return r
                                        out.extend(r)
                                    finally:self.scopes.pop()
                                else:
                                    ln,txt=node
                                    r=self.run_line(txt)
                                    if isinstance(r,Diagnostic):return Diagnostic(r.code,f'line {ln}: {r.message}',ln,r.column,r.hint)
                                    out.append(r)
                            return out
                        chosen_results=execute_nodes(branch)
                        if isinstance(chosen_results,Diagnostic):return chosen_results,index,None
                        results.extend(chosen_results)
                    finally:self.scopes.pop()
                    continue
                if text in ('ELSE','END'):
                    if text in stops:return results,index,text
                    return Diagnostic('ARC-PARSE-001',f'unexpected {text}',number),index,None
                result=self.run_line(text)
                if isinstance(result,Diagnostic):return Diagnostic(result.code,f'line {number}: {result.message}',number,result.column,result.hint),index,None
                results.append(result); index+=1
            return results,index,None
        # Replace simple results with structured nodes using a dedicated recursive parser.
        def parse_nodes(index=0, stops=()):
            nodes=[]
            while index<len(lines):
                number,text=lines[index]
                if text in stops:return nodes,index,text
                m=re.fullmatch(r'KWAI\s+(.+?)\s+THEN',text)
                if m:
                    cond=m.group(1); yes,index,stop=parse_nodes(index+1,('ELSE','END'))
                    if isinstance(yes,Diagnostic):return yes,index,None
                    no=[]
                    if stop=='ELSE':no,index,stop=parse_nodes(index+1,('END',))
                    if isinstance(no,Diagnostic):return no,index,None
                    if stop!='END':return Diagnostic('ARC-PARSE-001','conditional block requires END',number,1,'Close each conditional with END.'),index,None
                    nodes.append(('block',cond,yes,no,number)); index+=1; continue
                if text in ('ELSE','END'):
                    if text in stops:return nodes,index,text
                    return Diagnostic('ARC-PARSE-001',f'unexpected {text}',number),index,None
                nodes.append((number,text));index+=1
            return nodes,index,None
        nodes,index,stop=parse_nodes()
        if isinstance(nodes,Diagnostic):return nodes
        if stop is not None:return Diagnostic('ARC-PARSE-001',f'unexpected {stop}')
        def execute(nodes):
            results=[]
            for node in nodes:
                if len(node)==5 and node[0]=='block':
                    _,condition,yes,no,number=node
                    try:take_yes=self.truth(self.evaluate(condition))
                    except ArcaneError as e:
                        d=e.diagnostic;return Diagnostic(d.code,f'line {number}: {d.message}',number,d.column,d.hint)
                    self.scopes.append({})
                    try:
                        out=execute(yes if take_yes else no)
                        if isinstance(out,Diagnostic):return out
                        results.extend(out)
                    finally:self.scopes.pop()
                else:
                    number,text=node;out=self.run_line(text)
                    if isinstance(out,Diagnostic):return Diagnostic(out.code,f'line {number}: {out.message}',number,out.column,out.hint)
                    results.append(out)
            return results
        return execute(nodes)

    def run_line(self,line):
        line=line.strip()
        try:
            # Provisional conditional form: KWAI condition THEN expression ELSE expression.
            m=re.fullmatch(r'KWAI\s+(.+?)\s+THEN\s+(.+?)\s+ELSE\s+(.+)',line)
            if m:
                condition, yes_expr, no_expr=m.groups()
                condition_value=self.evaluate(condition)
                choose_yes=self.truth(condition_value)
                return self.evaluate(yes_expr if choose_yes else no_expr)
            if line.startswith('KWAI '):
                raise ArcaneError('ARC-PARSE-001','conditional requires THEN and ELSE branches','Use: KWAI condition THEN expression ELSE expression')
            m=re.fullmatch(r'KWAM\s+([A-Za-z_]\w*)\s*=>\s*(.+)',line)
            if m:return self.define(m.group(1),self.evaluate(m.group(2)))
            m=re.fullmatch(r'KWAF\s+([A-Za-z_]\w*)\s*\(([^()]*)\)\s*=>\s*(.+)',line)
            if m:
                name,ps,body=m.groups(); params=[p.strip().lstrip('$') for p in ps.split(',') if p.strip()]
                if any(not re.fullmatch(r'[A-Za-z_]\w*',p) for p in params) or len(set(params))!=len(params): raise ArcaneError('ARC-PARSE-001','invalid or duplicate function parameter')
                if name in self.functions or name in self.bindings: raise ArcaneError('ARC-NAME-002',f'name already defined: {name}')
                # Register before syntax validation so self-recursion parses safely.
                self.functions[name]={'params':params,'body':body}
                # Syntax/name validation is deferred until the first call, allowing recursion.
                return f'function {name}/{len(params)} defined'
            m=re.fullmatch(r'KWAT\s+([A-Za-z_]\w*)',line)
            if m:
                return self._lookup_binding(m.group(1),{})
            m=re.fullmatch(r'KWAR\s+([A-Za-z_]\w*)\s+FROM\s+(.+?)\s+TO\s+(.+?)\s*=>\s*(.+)',line)
            if m:
                n,lo,hi,body=m.groups(); a=self._bound(self.evaluate(lo)); b=self._bound(self.evaluate(hi)); count=max(0,b-a+1)
                if count>self.max_iterations: raise ArcaneError('ARC-LOOP-002','iteration limit exceeded')
                return [self.evaluate(body,{n:Quantity(float(k))}) for k in range(a,b+1)]
            m=re.fullmatch(r'KWAS\s+([A-Za-z_]\w*)\s+FROM\s+(.+?)\s+TO\s+(.+?)\s*=>\s*(.+)',line)
            if m:
                n,lo,hi,body=m.groups(); a=self._bound(self.evaluate(lo)); b=self._bound(self.evaluate(hi)); count=max(0,b-a+1)
                if count>self.max_iterations: raise ArcaneError('ARC-LOOP-002','iteration limit exceeded')
                vals=[self.evaluate(body,{n:Quantity(float(k))}) for k in range(a,b+1)]
                if not vals:return Quantity(0)
                if not all(isinstance(v,Quantity) for v in vals): raise ArcaneError('ARC-TYPE-001','aggregation requires numeric values')
                if any(v.dimensions!=vals[0].dimensions for v in vals): raise ArcaneError('ARC-UNIT-001','dimension mismatch in aggregation')
                return Quantity(sum(v.value for v in vals),vals[0].dimensions)
            return self.evaluate(line)
        except ArcaneError as e:return e.diagnostic

def show(v):
    if isinstance(v,Quantity):return f'{v.value:g}'+(' dimensionless' if not v.dimensions else f' dimensions={v.dimensions}')
    if isinstance(v,list):return '['+', '.join(show(x) for x in v)+']'
    return str(v)
