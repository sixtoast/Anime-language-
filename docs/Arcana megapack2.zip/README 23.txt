ARCANE PHASE 7V — SHARED PARSER AND SAFER EXECUTION

Python 3.10+; standard library only.

Run regression tests:
  python -m unittest -v

Static checks:
  python arcane_cli.py --check example.arc

Validate, then execute:
  python arcane_cli.py --run example.arc

Expected example output: 49

Phase 7V integrates syntax checking and runtime parsing, validates syntax and
semantic issues before CLI execution, guards recursive calls, and resets
runtime state between runs. This remains a small reconstructed subset, not the
complete Arcane language. See ARCANE_PHASE_7V_REPORT.md for scope and limits.
