from dataclasses import dataclass
from pathlib import Path
import re
from arcane_runtime import ArcaneFailure, parse_program, walk, tokenize, BINOPS

@dataclass(frozen=True)
class Issue:
    code:str; message:str; line:int
    def render(self,filename="<source>"): return f"{filename}:{self.line}: error {self.code}: {self.message}"
@dataclass(frozen=True)
class Report:
    filename:str; issues:tuple
    @property
    def ok(self): return not self.issues
    def render(self): return f"{self.filename}: semantic checks OK" if self.ok else "\n".join(x.render(self.filename) for x in self.issues)

def _expr(expr,line,visible,functions,issues):
    try: ts=tokenize(expr,line)
    except ArcaneFailure as e: issues.append(Issue(e.code,e.message,line)); return
    for t in ts:
        if t.startswith("$") and t[1:] not in visible:
            issues.append(Issue("ARC-SEM-005",f"unresolved binding '{t}'",line))
    i=0
    while i<len(ts)-1:
        name=ts[i]
        if re.fullmatch(r"[A-Za-z_]\w*",name) and name not in BINOPS and ts[i+1]=="(":
            j=i+2; depth=0; commas=0; empty=j<len(ts) and ts[j]==")"
            while j<len(ts):
                if ts[j]=="(": depth+=1
                elif ts[j]==")":
                    if depth==0: break
                    depth-=1
                elif ts[j]=="," and depth==0: commas+=1
                j+=1
            arity=0 if empty else commas+1
            if name not in functions: issues.append(Issue("ARC-SEM-006",f"undefined function '{name}'",line))
            elif functions[name]!=arity: issues.append(Issue("ARC-SEM-007",f"function '{name}' expects {functions[name]} argument(s), got {arity}",line))
        i+=1

def analyze_source(source,filename="<source>"):
    try: ast,_=parse_program(source)
    except ArcaneFailure as e: return Report(filename,(Issue(e.code,e.message,e.line),))
    issues=[]; functions={}
    for n in walk(ast):
        if n.kind=="function":
            if n.name in functions: issues.append(Issue("ARC-SEM-003",f"duplicate function '{n.name}'",n.line))
            else: functions[n.name]=len(n.params)
            if len(set(n.params))!=len(n.params): issues.append(Issue("ARC-SEM-002",f"duplicate parameter in '{n.name}'",n.line))
    def block(nodes,inherited):
        visible=set(inherited); declared=set()
        for n in nodes:
            if n.kind=="binding":
                _expr(n.expr,n.line,visible,functions,issues)
                if n.name in declared: issues.append(Issue("ARC-SEM-004",f"duplicate binding '{n.name}'",n.line))
                declared.add(n.name); visible.add(n.name)
            elif n.kind=="output":
                if n.name not in visible: issues.append(Issue("ARC-SEM-005",f"unresolved binding '{n.name}'",n.line))
            elif n.kind=="if":
                _expr(n.expr,n.line,visible,functions,issues)
                block(n.yes,visible); block(n.no,visible)
    block(ast,set())
    # Function expressions intentionally use parameter-only scope in this subset.
    for n in walk(ast):
        if n.kind=="function": _expr(n.expr,n.line,set(n.params),functions,issues)
    unique=[]; seen=set()
    for x in issues:
        k=(x.code,x.message,x.line)
        if k not in seen: seen.add(k); unique.append(x)
    return Report(filename,tuple(unique))

def analyze_file(path):
    p=Path(path)
    try:return analyze_source(p.read_text(encoding="utf-8"),str(p))
    except OSError as e:return Report(str(p),(Issue("ARC-IO-001",str(e),1),))
