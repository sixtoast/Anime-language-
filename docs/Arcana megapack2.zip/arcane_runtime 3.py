"""Arcane Phase 7B: provisional mutable state and lexical scopes.

Not canon: KWAM name = expr (immutable value), KWAK name = expr (live expression),
KWAT name (read), KWAS name = expr (update nearest existing mutable state).
Expressions use $name references and binary prefix arithmetic operators.
"""
from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
import re

class ArcaneError(ValueError): pass
class ArcaneParseError(ArcaneError): pass
class ArcaneTypeError(ArcaneError): pass
class ArcaneEvaluationError(ArcaneError): pass
class ArcaneBindingError(ArcaneError): pass

D0=(0,0,0)
UNITS={'1':(Decimal(1),D0),'m':(Decimal(1),(1,0,0)),'cm':(Decimal('.01'),(1,0,0)),'km':(Decimal(1000),(1,0,0)),'s':(Decimal(1),(0,1,0)),'min':(Decimal(60),(0,1,0)),'h':(Decimal(3600),(0,1,0)),'kg':(Decimal(1),(0,0,1)),'g':(Decimal('.001'),(0,0,1))}
DIGITS={'ZA':0,'KI':1,'TO':2,'MU':3,'RE':4,'SA':5,'FI':6,'DU':7,'GO':8,'PE':9}
ARITY={'FRAPA':2,'FRATA':2,'FRAKA':2,'FRALA':2}
NUM_RE=re.compile(r'^([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)(?:@([A-Za-z0-9]+))?$')
NAME_RE=re.compile(r'^[A-Za-z_][A-Za-z0-9_]*$')

@dataclass(frozen=True)
class Quantity:
    value: Decimal
    dimension: tuple[int,int,int]
@dataclass(frozen=True)
class Literal: quantity: Quantity
@dataclass(frozen=True)
class Reference: name: str
@dataclass(frozen=True)
class Call:
    op: str
    args: tuple['Expr',...]
Expr=Literal|Reference|Call

def _plus(a,b): return tuple(x+y for x,y in zip(a,b))
def _minus(a,b): return tuple(x-y for x,y in zip(a,b))
def _literal(token):
    if token in DIGITS: return Literal(Quantity(Decimal(DIGITS[token]),D0))
    m=NUM_RE.fullmatch(token)
    if not m: return None
    raw,unit=m.groups(); unit=unit or '1'
    if unit not in UNITS: raise ArcaneTypeError(f'unknown unit {unit!r}')
    try: val=Decimal(raw)
    except InvalidOperation as e: raise ArcaneParseError(f'invalid numeric literal {token!r}') from e
    scale,dims=UNITS[unit]
    return Literal(Quantity(val*scale,dims))
class _Parser:
    def __init__(self,tokens): self.tokens=tokens; self.i=0
    def expr(self):
        if self.i>=len(self.tokens): raise ArcaneParseError('unexpected end; expected operand')
        tok=self.tokens[self.i]; self.i+=1
        lit=_literal(tok)
        if lit is not None: return lit
        if tok.startswith('$') and NAME_RE.fullmatch(tok[1:]): return Reference(tok[1:])
        if tok in ARITY: return Call(tok,tuple(self.expr() for _ in range(ARITY[tok])))
        raise ArcaneParseError(f'unknown form or malformed literal {tok!r}')
def parse(source):
    if not isinstance(source,str) or not source.strip(): raise ArcaneParseError('expression must not be empty')
    p=_Parser(source.split()); tree=p.expr()
    if p.i!=len(p.tokens): raise ArcaneParseError('extra tokens: '+' '.join(p.tokens[p.i:]))
    return tree

@dataclass
class Binding:
    kind: str # value, state, live
    value: Quantity|None=None
    expression: Expr|None=None

class Environment:
    def __init__(self): self._scopes=[{}]; self._resolving=[]
    @property
    def scope_depth(self): return len(self._scopes)-1
    def push_scope(self): self._scopes.append({})
    def pop_scope(self):
        if len(self._scopes)==1: raise ArcaneBindingError('cannot pop the global scope')
        self._scopes.pop()
    def _valid_name(self,name):
        if not isinstance(name,str) or not NAME_RE.fullmatch(name): raise ArcaneBindingError(f'invalid binding name {name!r}')
    def _current_key(self,name):
        key=name.casefold()
        if key in self._scopes[-1]: raise ArcaneBindingError(f'binding {name!r} already exists in this scope')
        return key
    def _find(self,name):
        key=name.casefold()
        for scope in reversed(self._scopes):
            if key in scope: return scope[key]
        raise ArcaneBindingError(f'unknown binding {name!r}')
    def _find_scope(self,name):
        key=name.casefold()
        for scope in reversed(self._scopes):
            if key in scope: return scope,key
        raise ArcaneBindingError(f'unknown binding {name!r}')
    def create_value(self,name,source):
        self._valid_name(name); key=self._current_key(name); value=self.evaluate_expr(parse(source))
        self._scopes[-1][key]=Binding('value',value=value); return value
    def create_state(self,name,source):
        self._valid_name(name); key=self._current_key(name); value=self.evaluate_expr(parse(source))
        self._scopes[-1][key]=Binding('state',value=value); return value
    def create_live(self,name,source):
        self._valid_name(name); key=self._current_key(name); tree=parse(source)
        # Validate now so invalid declarations never enter the environment.
        self.evaluate_expr(tree)
        self._scopes[-1][key]=Binding('live',expression=tree)
        return self.resolve(name)
    def assign(self,name,source):
        scope,key=self._find_scope(name); binding=scope[key]
        if binding.kind!='state': raise ArcaneBindingError(f'{name!r} is not mutable state; only KWAM state bindings can be updated')
        new_value=self.evaluate_expr(parse(source))
        if new_value.dimension!=binding.value.dimension:
            raise ArcaneTypeError(f'cannot change dimensions of {name!r}: expected {binding.value.dimension}, got {new_value.dimension}')
        binding.value=new_value; return new_value
    def resolve(self,name):
        key=name.casefold(); binding=self._find(name)
        if binding.kind!='live': return binding.value
        marker=(key,id(binding))
        if marker in self._resolving: raise ArcaneBindingError('cyclic live binding detected')
        self._resolving.append(marker)
        try: return self.evaluate_expr(binding.expression)
        finally: self._resolving.pop()
    def evaluate_expr(self,tree):
        if isinstance(tree,Literal): return tree.quantity
        if isinstance(tree,Reference): return self.resolve(tree.name)
        a,b=(self.evaluate_expr(x) for x in tree.args)
        if tree.op in ('FRAPA','FRATA') and a.dimension!=b.dimension:
            raise ArcaneTypeError(f'{tree.op} requires matching dimensions; got {a.dimension} and {b.dimension}')
        if tree.op=='FRAPA': return Quantity(a.value+b.value,a.dimension)
        if tree.op=='FRATA': return Quantity(a.value-b.value,a.dimension)
        if tree.op=='FRAKA': return Quantity(a.value*b.value,_plus(a.dimension,b.dimension))
        if tree.op=='FRALA':
            if b.value==0: raise ArcaneEvaluationError('FRALA: division by zero')
            return Quantity(a.value/b.value,_minus(a.dimension,b.dimension))
        raise ArcaneParseError(f'unsupported operator {tree.op}')
    def execute(self,statement):
        s=statement.strip()
        patterns=[('KWAM',r'KWAM\s+([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+)','value'),('KWAK',r'KWAK\s+([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+)','live'),('KWAS',r'KWAS\s+([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+)','state'),('KWAS',r'KWAS\s+([A-Za-z_][A-Za-z0-9_]*)\s*<-\s*(.+)','assign')]
        for _,pattern,kind in patterns:
            m=re.fullmatch(pattern,s,re.I)
            if m:
                name,expr=m.groups()
                if kind=='value': return self.create_value(name,expr)
                if kind=='live': return self.create_live(name,expr)
                if kind=='state': return self.create_state(name,expr)
                return self.assign(name,expr)
        m=re.fullmatch(r'KWAT\s+([A-Za-z_][A-Za-z0-9_]*)',s,re.I)
        if m: return self.resolve(m.group(1))
        if s.split() and s.split()[0] in ARITY: return self.evaluate_expr(parse(s))
        raise ArcaneParseError('expected KWAM name = expr, KWAK name = expr, KWAS name = expr, KWAS name <- expr, KWAT name, or an arithmetic expression')

def format_quantity(q):
    v=format(q.value.normalize(),'f') if q.value else '0'; l,t,m=q.dimension
    if (l,t,m)==D0: unit='1'
    else:
        parts=[]
        for sym,power in [('m',l),('s',t),('kg',m)]:
            if power: parts.append(sym if power==1 else f'{sym}^{power}')
        unit=' '.join(parts)
    return f'{v} {unit}'

if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser(description='Arcane provisional state/scope runtime; one statement per process')
    ap.add_argument('statement',nargs='+'); args=ap.parse_args(); env=Environment()
    try: print(format_quantity(env.execute(' '.join(args.statement))))
    except ArcaneError as e: raise SystemExit(f'Arcane error: {e}')
