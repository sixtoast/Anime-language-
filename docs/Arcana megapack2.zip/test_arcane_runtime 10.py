import unittest
from arcane_runtime import ArcaneRuntime, Quantity
from arcane_diagnostics import ArcaneDiagnosticError, ErrorCode

class RuntimeTests(unittest.TestCase):
 def setUp(self): self.r=ArcaneRuntime()
 def test_number(self): self.assertEqual(self.r.evaluate('4').value,4)
 def test_add(self): self.assertEqual(self.r.evaluate('FRAPA 2 3').value,5)
 def test_subtract(self): self.assertEqual(self.r.evaluate('FRALA 8 3').value,5)
 def test_multiply(self): self.assertEqual(self.r.evaluate('FRATA 2 3').value,6)
 def test_divide(self): self.assertEqual(self.r.evaluate('FRAKA 8 2').value,4)
 def test_divide_zero_diagnostic(self):
  with self.assertRaises(ArcaneDiagnosticError) as e: self.r.evaluate('FRAKA 1 0')
  self.assertEqual(e.exception.diagnostic.code,ErrorCode.DIVISION_BY_ZERO)
 def test_unknown_name_diagnostic(self):
  with self.assertRaises(ArcaneDiagnosticError) as e: self.r.evaluate('$missing')
  self.assertEqual(e.exception.diagnostic.code,ErrorCode.UNKNOWN_NAME)
 def test_units_add_same(self): self.assertEqual(self.r.evaluate('FRAPA m cm').dimensions,(1,0,0))
 def test_units_mismatch(self):
  with self.assertRaises(ArcaneDiagnosticError) as e: self.r.evaluate('FRAPA m s')
  self.assertEqual(e.exception.diagnostic.code,ErrorCode.DIMENSION_MISMATCH)
 def test_product_dimensions(self): self.assertEqual(self.r.evaluate('FRATA m s').dimensions,(1,1,0))
 def test_comparison(self): self.assertTrue(self.r.evaluate('FRAGT 3 2'))
 def test_equality(self): self.assertTrue(self.r.evaluate('FRAEQ 3 3'))
 def test_logic(self): self.assertTrue(self.r.evaluate('FRAND 1 1'))
 def test_not(self): self.assertTrue(self.r.evaluate('FRNOT 0'))
 def test_parentheses(self): self.assertEqual(self.r.evaluate('( FRAPA 2 3 )').value,5)
 def test_define_and_lookup(self):
  self.r.run_line('KWAM total => FRAPA 2 3'); self.assertEqual(self.r.run_line('KWAT total').value,5)
 def test_duplicate_binding(self):
  self.r.run_line('KWAM x => 1'); out=self.r.run_line('KWAM x => 2'); self.assertEqual(out.code,ErrorCode.DUPLICATE_BINDING)
 def test_trailing_token(self):
  with self.assertRaises(ArcaneDiagnosticError) as e: self.r.evaluate('1 2')
  self.assertEqual(e.exception.diagnostic.code,ErrorCode.PARSE_ERROR)
 def test_invalid_token(self):
  with self.assertRaises(ArcaneDiagnosticError): self.r.evaluate('@')
 def test_dimensionless_one_truth(self): self.assertTrue(self.r.evaluate('FRNOT 0'))
 def test_zero_is_not_true(self): self.assertFalse(self.r.evaluate('FRAND 0 1'))

if __name__=='__main__': unittest.main()
