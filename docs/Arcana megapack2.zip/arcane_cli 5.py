from arcane_runtime import ArcaneRuntime, ArcaneError, show

def main():
    r=ArcaneRuntime()
    print('Arcane Phase 7O subset — :help for examples, :quit to exit')
    while True:
        try: line=input('arcane> ').strip()
        except (EOFError,KeyboardInterrupt): print(); break
        if not line: continue
        if line==':quit': break
        if line==':help':
            print('KWAF square(x) => FRATA $x $x')
            print('square(4)')
            print('KWAR i FROM 1 TO 3 => square($i)')
            print('KWAS total FROM 1 TO 5 => $total')
            print('KWAI FRAGT 5 3 THEN FRAPA 10 2 ELSE 0')
            print('Multi-line programs: use ArcaneRuntime.run_program(source)')
            continue
        result=r.run_line(line)
        if hasattr(result,'render') and hasattr(result,'code'): print(result.render())
        elif hasattr(result,'render') and hasattr(result,'message'): print(result.render())
        else: print(show(result))

if __name__=='__main__': main()
