"""Arcane provisional-subset CLI: interactive mode or execute a source file."""
import argparse
from pathlib import Path
from arcane_runtime import ArcaneRuntime, ArcaneError, Diagnostic, show


def display(result):
    if isinstance(result, Diagnostic):
        print(result.render())
    elif isinstance(result, list):
        for item in result:
            print(show(item))
    else:
        print(show(result))


def main():
    parser = argparse.ArgumentParser(description='Run the provisional Arcane language subset')
    parser.add_argument('file', nargs='?', help='Arcane source file to execute')
    args = parser.parse_args()
    runtime = ArcaneRuntime()
    if args.file:
        path = Path(args.file)
        try:
            source = path.read_text(encoding='utf-8')
        except OSError as error:
            parser.error(f'cannot read {path}: {error}')
        result = runtime.run_program(source)
        display(result)
        raise SystemExit(1 if isinstance(result, Diagnostic) else 0)

    print('Arcane Phase 7Q subset — :help for examples, :quit to exit')
    while True:
        try:
            line = input('arcane> ').strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not line:
            continue
        if line == ':quit':
            break
        if line == ':help':
            print('KWAF square(x) => FRATA $x $x')
            print('square(4)')
            print('KWAM width => 4; KWAM height => 3; FRATA $width $height')
            print('For multi-line blocks and programs, save source to a file and run: python arcane_cli.py program.arc')
            print('Block syntax: KWAI condition THEN, optional ELSE, and END on separate lines.')
            continue
        display(runtime.run_line(line))


if __name__ == '__main__':
    main()
