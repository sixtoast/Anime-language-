"""Arcane Phase 7C: persistent interactive sessions and transactional statements.

All command spellings are provisional implementation syntax, not canon.
"""
from __future__ import annotations
import copy
from dataclasses import dataclass
from pathlib import Path
from typing import TextIO
from arcane_runtime import Environment, ArcaneError, format_quantity

HELP = """Arcane interactive session (provisional syntax)
  KWAM name = expression     immutable value
  KWAS name = expression     mutable state
  KWAS name <- expression   update mutable state
  KWAK name = expression     live expression
  KWAT name                  read a binding
  FRAPA/FRATA/FRAKA/FRALA    evaluate arithmetic expression
  :scope in                  enter nested scope
  :scope out                 leave nested scope
  :scope                     show current scope depth
  :env                       list visible bindings
  :help                      show this help
  :quit                      exit

Expressions support numeric literals, units and $name references.
Each statement is atomic: a failed command restores the environment.
"""

@dataclass(frozen=True)
class SessionResult:
    ok: bool
    message: str
    value: object = None

class ArcaneSession:
    def __init__(self, environment: Environment | None = None):
        self.env = environment or Environment()
        self.statement_number = 0

    def _visible_bindings(self):
        # Preserve nearest-scope shadowing; display the effective visible binding.
        visible = {}
        for scope in self.env._scopes:
            visible.update(scope)
        return visible

    def execute_line(self, line: str) -> SessionResult:
        raw = line.strip()
        if not raw or raw.startswith('#'):
            return SessionResult(True, '')
        if raw.casefold() in (':quit', ':exit'):
            return SessionResult(True, 'Goodbye.')
        if raw.casefold() == ':help':
            return SessionResult(True, HELP)
        if raw.casefold() == ':scope':
            return SessionResult(True, f'scope depth: {self.env.scope_depth}')
        if raw.casefold() == ':scope in':
            self.env.push_scope()
            return SessionResult(True, f'entered scope {self.env.scope_depth}')
        if raw.casefold() == ':scope out':
            try:
                self.env.pop_scope()
            except ArcaneError as exc:
                return SessionResult(False, f'Error: {exc}')
            return SessionResult(True, f'left scope; depth {self.env.scope_depth}')
        if raw.casefold() == ':env':
            visible = self._visible_bindings()
            if not visible:
                return SessionResult(True, '(no bindings)')
            lines = []
            for name, binding in sorted(visible.items()):
                try:
                    value = self.env.resolve(name)
                    rendered = format_quantity(value)
                except ArcaneError as exc:
                    rendered = f'<error: {exc}>'
                lines.append(f'{name} [{binding.kind}] = {rendered}')
            return SessionResult(True, '\n'.join(lines))

        # Snapshot before executing. Any language error restores all scope maps and
        # binding objects, so even an accidental partial mutation cannot leak.
        snapshot = copy.deepcopy(self.env._scopes)
        resolving = list(self.env._resolving)
        self.statement_number += 1
        try:
            value = self.env.execute(raw)
            message = format_quantity(value) if hasattr(value, 'dimension') and hasattr(value, 'value') else str(value)
            return SessionResult(True, message, value)
        except ArcaneError as exc:
            self.env._scopes = snapshot
            self.env._resolving = resolving
            return SessionResult(False, f'Error on statement {self.statement_number}: {exc}')
        except Exception as exc:
            # Surface unexpected implementation failures without corrupting state.
            self.env._scopes = snapshot
            self.env._resolving = resolving
            return SessionResult(False, f'Internal error on statement {self.statement_number}: {type(exc).__name__}: {exc}')

    def run_stream(self, source: TextIO, output: TextIO, interactive: bool = False) -> int:
        if interactive:
            output.write('Arcane provisional runtime. Type :help for commands; :quit to exit.\n')
        for line in source:
            if interactive:
                output.write('arcane> ')
                output.flush()
            result = self.execute_line(line)
            if result.message:
                output.write(result.message + '\n')
            if line.strip().casefold() in (':quit', ':exit'):
                break
        return 0

def run_file(path: str | Path, output: TextIO) -> int:
    session = ArcaneSession()
    errors = 0
    with open(path, encoding='utf-8') as src:
        for lineno, line in enumerate(src, 1):
            result = session.execute_line(line)
            if result.message:
                output.write(f'{lineno}: {result.message}\n')
            if not result.ok:
                errors += 1
    return 1 if errors else 0

if __name__ == '__main__':
    import argparse, sys
    parser = argparse.ArgumentParser(description='Arcane persistent interactive runtime')
    parser.add_argument('--script', help='execute statements from a UTF-8 file')
    args = parser.parse_args()
    if args.script:
        raise SystemExit(run_file(args.script, sys.stdout))
    session = ArcaneSession()
    sys.stdout.write('Arcane provisional runtime. Type :help for commands; :quit to exit.\n')
    while True:
        try:
            line = input('arcane> ')
        except EOFError:
            print()
            break
        result = session.execute_line(line)
        if result.message:
            print(result.message)
        if line.strip().casefold() in (':quit', ':exit'):
            break
