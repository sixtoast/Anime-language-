"""Lightweight static name/function checks for Phase 7U; runtime remains authoritative."""
import re
from dataclasses import dataclass
from pathlib import Path
@dataclass(frozen=True)
class Issue:
    code:str; message:str; line:int
    def render(self,filename='<source>'): return f'{filename}:{self.line}: error {self.code}: {self.message}'
@dataclass(frozen=True)
class Report:
    filename:str; issues:tuple
    @property
    def ok(self): return not self.issues
    def render(self): return f'{self.filename}: semantic checks OK' if self.ok else '\n'.join(i.render(self.filename) for i in self.issues)
def analyze_source(src,filename='<source>'):
    issues=[]; bindings=set(); funcs={}; pending=[]; params=set(); stack=[]
    lines=[(i,s.strip()) for i,s in enumerate(src.splitlines(),1) if s.strip() and not s.strip().startswith('#')]
    for n,s in lines:
        fm=re.fullmatch(r'KWAF\s+(\w+)\s*\(([^()]*)\)\s*=>\s*(.+)',s)
        if fm:
            name,raw,body=fm.groups(); ps=[x.strip().lstrip('$') for x in raw.split(',') if x.strip()]
            if name in funcs: issues.append(Issue('ARC-SEM-003',f"duplicate function '{name}'",n))
            funcs[name]=len(ps); pending.append((n,body,set(ps),name)); continue
        if s.startswith('KWAI ') and s.endswith(' THEN'):
            stack.append(set()); continue
        if s=='ELSE':
            if stack: stack[-1]=set()
            continue
        if s=='END':
            if stack: stack.pop()
            continue
        bm=re.fullmatch(r'KWAM\s+(\w+)\s*=>\s*(.+)',s)
        if bm:
            name,body=bm.groups(); visible=bindings.union(*stack) if stack else bindings
            _refs(body,n,visible,funcs,issues,allow_forward=True)
            current=stack[-1] if stack else bindings
            if name in current: issues.append(Issue('ARC-SEM-004',f"duplicate binding '{name}'",n))
            current.add(name); continue
        if s.startswith('KWAT '):
            name=s.split(None,1)[1]; visible=bindings.union(*stack) if stack else bindings
            if name not in visible: issues.append(Issue('ARC-SEM-005',f"unresolved binding '{name}'",n))
    for n,body,ps,name in pending: _refs(body,n,ps,funcs,issues,allow_forward=True)
    return Report(filename,tuple(issues))
def _refs(expr,line,visible,funcs,issues,allow_forward=False):
    for name in re.findall(r'\$([A-Za-z_]\w*)',expr):
        if name not in visible: issues.append(Issue('ARC-SEM-005',f"unresolved binding '${name}'",line))
    for name,args in re.findall(r'\b([A-Za-z_]\w*)\s*\(([^()]*)\)',expr):
        if name not in funcs: issues.append(Issue('ARC-SEM-006',f"undefined function '{name}'",line))
        elif len([x for x in args.split(',') if x.strip()]) != funcs[name]: issues.append(Issue('ARC-SEM-007',f"wrong argument count for '{name}'",line))
def analyze_file(path):
    p=Path(path)
    try: return analyze_source(p.read_text(encoding='utf-8'),str(p))
    except OSError as e: return Report(str(p),(Issue('ARC-IO-001',str(e),1),))
