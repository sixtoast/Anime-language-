"""Phase 7J: stable diagnostics and result typing utilities for Arcane tooling.

This module is deliberately independent of a particular evaluator implementation so
it can be integrated without changing the semantics of the provisional runtime.
"""
from dataclasses import dataclass
from enum import Enum
from typing import Any, Optional

class ErrorCode(str, Enum):
    PARSE_ERROR = 'ARC-PARSE-001'
    UNKNOWN_NAME = 'ARC-NAME-001'
    DUPLICATE_BINDING = 'ARC-NAME-002'
    TYPE_MISMATCH = 'ARC-TYPE-001'
    DIMENSION_MISMATCH = 'ARC-UNIT-001'
    INVALID_BOUNDS = 'ARC-LOOP-001'
    ITERATION_LIMIT = 'ARC-LOOP-002'
    DIVISION_BY_ZERO = 'ARC-MATH-001'
    CALL_DEPTH = 'ARC-RUNTIME-001'
    INTERNAL_ERROR = 'ARC-RUNTIME-999'

@dataclass(frozen=True)
class SourceSpan:
    line: int = 1
    column: int = 1
    end_line: Optional[int] = None
    end_column: Optional[int] = None
    def __post_init__(self):
        if self.line < 1 or self.column < 1: raise ValueError('source positions are 1-based positive integers')
        if self.end_line is not None and self.end_line < self.line: raise ValueError('end_line cannot precede line')
        if self.end_column is not None and self.end_line == self.line and self.end_column < self.column: raise ValueError('end_column cannot precede column')

@dataclass(frozen=True)
class Diagnostic:
    code: ErrorCode
    message: str
    span: SourceSpan = SourceSpan()
    hint: Optional[str] = None
    def render(self):
        out = f'{self.code.value} at {self.span.line}:{self.span.column}: {self.message}'
        if self.hint: out += f'\n  hint: {self.hint}'
        return out

class ArcaneDiagnosticError(Exception):
    def __init__(self, diagnostic: Diagnostic):
        self.diagnostic = diagnostic
        super().__init__(diagnostic.render())

class ValueKind(str, Enum):
    NUMBER = 'number'
    BOOLEAN = 'boolean'
    STRING = 'string'
    LIST = 'list'
    FUNCTION = 'function'
    UNKNOWN = 'unknown'

@dataclass(frozen=True)
class ValueType:
    kind: ValueKind
    dimensions: tuple[int, ...] = ()
    element_type: Optional['ValueType'] = None
    def describe(self):
        if self.kind == ValueKind.NUMBER and self.dimensions:
            return f"number[{','.join(map(str, self.dimensions))}]"
        if self.kind == ValueKind.LIST and self.element_type:
            return f'list[{self.element_type.describe()}]'
        return self.kind.value

@dataclass(frozen=True)
class TypedValue:
    value: Any
    type: ValueType

def infer_type(value: Any, dimensions: tuple[int, ...] = ()) -> ValueType:
    """Infer a descriptive type without changing or coercing the value."""
    if isinstance(value, bool): return ValueType(ValueKind.BOOLEAN)
    if isinstance(value, (int, float, complex)): return ValueType(ValueKind.NUMBER, dimensions)
    if isinstance(value, str): return ValueType(ValueKind.STRING)
    if isinstance(value, (list, tuple)):
        if not value: return ValueType(ValueKind.LIST, element_type=ValueType(ValueKind.UNKNOWN))
        first = infer_type(value[0])
        # Heterogeneous collections are represented honestly as unknown element type.
        if any(infer_type(item) != first for item in value[1:]): first = ValueType(ValueKind.UNKNOWN)
        return ValueType(ValueKind.LIST, element_type=first)
    if callable(value): return ValueType(ValueKind.FUNCTION)
    return ValueType(ValueKind.UNKNOWN)

def diagnostic_for_exception(exc: Exception, span: SourceSpan = SourceSpan()) -> Diagnostic:
    """Map common evaluator exceptions to stable diagnostics; never expose traceback text."""
    message = str(exc).strip() or exc.__class__.__name__
    low = message.casefold()
    if isinstance(exc, ZeroDivisionError) or 'division by zero' in low:
        code, hint = ErrorCode.DIVISION_BY_ZERO, 'Check the denominator before dividing.'
    elif 'unknown binding' in low or 'unknown name' in low:
        code, hint = ErrorCode.UNKNOWN_NAME, 'Check the spelling and whether the name is in scope.'
    elif 'duplicate binding' in low or 'already defined' in low:
        code, hint = ErrorCode.DUPLICATE_BINDING, 'Choose a new name or use the existing binding.'
    elif 'dimension' in low or 'unit' in low:
        code, hint = ErrorCode.DIMENSION_MISMATCH, 'Check that the quantities use compatible dimensions.'
    elif 'bound' in low or 'integer' in low:
        code, hint = ErrorCode.INVALID_BOUNDS, 'Use dimensionless integer bounds.'
    elif 'iteration' in low and ('maximum' in low or 'exceed' in low):
        code, hint = ErrorCode.ITERATION_LIMIT, 'Reduce the range to the configured iteration limit.'
    elif 'type' in low or 'numeric' in low:
        code, hint = ErrorCode.TYPE_MISMATCH, 'Check the value types expected by this operation.'
    elif 'parse' in low or 'unexpected' in low or 'token' in low:
        code, hint = ErrorCode.PARSE_ERROR, 'Check the expression syntax and delimiters.'
    elif 'call depth' in low or 'recursion' in low:
        code, hint = ErrorCode.CALL_DEPTH, 'Reduce recursive nesting or add a terminating condition.'
    else:
        code, hint = ErrorCode.INTERNAL_ERROR, None
    return Diagnostic(code, message, span, hint)
