"""Arcane Phase 7W: small provisional interpreter with a shared AST parser."""
from dataclasses import dataclass
import re

@dataclass(frozen=True)
class Diagnostic:
    code: str
    message: str
    line: int = 1
    def render(self, filename="<source>"):
        return f"{filename}:{self.line}: error {self.code}: {self.message}"

class ArcaneFailure(Exception):
    def __init__(self, code, message, line=1):
        super().__init__(message); self.code, self.message, self.line = code, message, line
    def diagnostic(self): return Diagnostic(self.code, self.message, self.line)

@dataclass(frozen=True)
class Node:
    kind: str
    line: int
    name: str = ""
    params: tuple = ()
    expr: str = ""
    yes: tuple = ()
    no: tuple = ()

NAME = r"[A-Za-z_][A-Za-z0-9_]*"
BINOPS = {"FRATA": (3, lambda a,b:a*b), "FRAPA": (2, lambda a,b:a+b),
          "FRAMO": (2, lambda a,b:a-b), "FRADI": (3, lambda a,b:a/b),
          "FRAGT": (1, lambda a,b:a>b), "FRALT": (1, lambda a,b:a<b),
          "FRAEQ": (1, lambda a,b:a==b), "FRANE": (1, lambda a,b:a!=b),
          "FRAGE": (1, lambda a,b:a>=b), "FRALE": (1, lambda a,b:a<=b)}
TOKEN = re.compile(r"\s*(\$\w+|\d+(?:\.\d+)?|[A-Za-z_]\w*|==|!=|<=|>=|[()+\-*/%,<>])")
PRECEDENCE = {"==":1,"!=":1,"<":1,">":1,"<=":1,">=":1,"+":2,"-":2,"*":3,"/":3,"%":3}

def parse_program(source):
    lines = [(i, s.strip()) for i,s in enumerate(source.splitlines(),1)
             if s.strip() and not s.strip().startswith("#")]
    def seq(i, stops=()):
        out=[]
        while i < len(lines):
            ln,s=lines[i]
            if s in stops: return out,i,s
            m=re.fullmatch(r"KWAI\s+(.+?)\s+THEN",s)
            if m:
                yes,i,stop=seq(i+1,("ELSE","END"))
                if stop=="ELSE": no,i,stop=seq(i+1,("END",))
                else: no=[]
                if stop!="END": raise ArcaneFailure("ARC-PARSE-001","conditional block missing END",ln)
                out.append(Node("if",ln,expr=m.group(1),yes=tuple(yes),no=tuple(no))); i+=1; continue
            if s in ("ELSE","END"): raise ArcaneFailure("ARC-PARSE-002",f"unexpected {s}",ln)
            fm=re.fullmatch(rf"KWAF\s+({NAME})\s*\(([^()]*)\)\s*=>\s*(.+)",s)
            bm=re.fullmatch(rf"KWAM\s+({NAME})\s*=>\s*(.+)",s)
            om=re.fullmatch(rf"KWAT\s+({NAME})",s)
            if s.startswith("KWAF "):
                if not fm: raise ArcaneFailure("ARC-PARSE-006","expected KWAF name(params) => expression",ln)
                nm,raw,expr=fm.groups(); params=tuple(x.strip().lstrip("$") for x in raw.split(",") if x.strip())
                if any(not re.fullmatch(NAME,p) for p in params): raise ArcaneFailure("ARC-PARSE-008","invalid parameter name",ln)
                out.append(Node("function",ln,name=nm,params=params,expr=expr))
            elif s.startswith("KWAM "):
                if not bm: raise ArcaneFailure("ARC-PARSE-005","expected KWAM name => expression",ln)
                out.append(Node("binding",ln,name=bm.group(1),expr=bm.group(2)))
            elif s.startswith("KWAT "):
                if not om: raise ArcaneFailure("ARC-PARSE-007","expected KWAT binding_name",ln)
                out.append(Node("output",ln,name=om.group(1)))
            elif s.startswith("KWAI "): raise ArcaneFailure("ARC-PARSE-003","expected KWAI condition THEN",ln)
            else: raise ArcaneFailure("ARC-PARSE-004",f"unsupported statement: {s}",ln)
            i+=1
        return out,i,None
    ast,i,stop=seq(0)
    if stop: raise ArcaneFailure("ARC-PARSE-002",f"unexpected {stop}")
    return tuple(ast),len(lines)

def walk(nodes):
    for n in nodes:
        yield n
        if n.kind=="if":
            yield from walk(n.yes); yield from walk(n.no)

def tokenize(expr,line):
    out=[]; pos=0
    while pos<len(expr):
        m=TOKEN.match(expr,pos)
        if not m:
            if expr[pos:].strip()=="": break
            raise ArcaneFailure("ARC-EXPR-001",f"unexpected character {expr[pos]!r}",line)
        out.append(m.group(1)); pos=m.end()
    if not out: raise ArcaneFailure("ARC-EXPR-001","empty expression",line)
    return out

class Parser:
    def __init__(self,ts,scope,funcs,line,depth,max_depth):
        self.ts,self.i,self.scope,self.funcs,self.line=ts,0,scope,funcs,line
        self.depth,self.max_depth=depth,max_depth
    def peek(self): return self.ts[self.i] if self.i<len(self.ts) else None
    def take(self):
        t=self.peek()
        if t is None: raise ArcaneFailure("ARC-EXPR-001","unexpected end of expression",self.line)
        self.i+=1; return t
    def parse(self,minp=0):
        t=self.take()
        if t=="(":
            v=self.parse()
            if self.take()!=")": raise ArcaneFailure("ARC-EXPR-001","expected ')'",self.line)
        elif t in ("+","-"):
            v=self.parse(4); v=v if t=="+" else -v
        elif t.startswith("$"):
            if t[1:] not in self.scope: raise ArcaneFailure("ARC-SEM-005",f"unresolved binding '{t}'",self.line)
            v=self.scope[t[1:]]
        elif re.fullmatch(r"\d+(?:\.\d+)?",t): v=float(t) if "." in t else int(t)
        elif re.fullmatch(NAME,t) and t in BINOPS:
            _,fn=BINOPS[t]; v=fn(self.parse(4),self.parse(4))
        elif re.fullmatch(NAME,t) and self.peek()=="(":
            self.take(); args=[]
            if self.peek()!=")":
                args.append(self.parse())
                while self.peek()==",": self.take(); args.append(self.parse())
            if self.take()!=")": raise ArcaneFailure("ARC-EXPR-001","expected ')' after arguments",self.line)
            if t not in self.funcs: raise ArcaneFailure("ARC-SEM-006",f"undefined function '{t}'",self.line)
            params,body,fl=self.funcs[t]
            if len(args)!=len(params): raise ArcaneFailure("ARC-SEM-007",f"function '{t}' expects {len(params)} argument(s), got {len(args)}",self.line)
            if self.depth>=self.max_depth: raise ArcaneFailure("ARC-RUN-002",f"maximum call depth ({self.max_depth}) exceeded",self.line)
            v=evaluate(body,dict(zip(params,args)),self.funcs,fl,self.depth+1,self.max_depth)
        else: raise ArcaneFailure("ARC-EXPR-002",f"invalid expression token {t!r}",self.line)
        while self.peek() in PRECEDENCE and PRECEDENCE[self.peek()]>=minp:
            op=self.take(); rhs=self.parse(PRECEDENCE[op]+1)
            try:
                fn={"+":lambda:v+rhs,"-":lambda:v-rhs,"*":lambda:v*rhs,"/":lambda:v/rhs,"%":lambda:v%rhs,
                    "==":lambda:v==rhs,"!=":lambda:v!=rhs,"<":lambda:v<rhs,">":lambda:v>rhs,
                    "<=":lambda:v<=rhs,">=":lambda:v>=rhs}[op]
                v=fn()
            except ZeroDivisionError: raise ArcaneFailure("ARC-RUN-001","division by zero",self.line)
            except TypeError as e: raise ArcaneFailure("ARC-RUN-004",str(e),self.line)
        return v

def evaluate(expr,scope,funcs,line,depth=0,max_depth=100):
    p=Parser(tokenize(expr,line),scope,funcs,line,depth,max_depth); v=p.parse()
    if p.peek() is not None: raise ArcaneFailure("ARC-EXPR-001",f"unexpected token {p.peek()!r}",line)
    return v

class ArcaneRuntime:
    def __init__(self,max_call_depth=100,max_steps=10000):
        self.max_call_depth,self.max_steps=max_call_depth,max_steps; self.reset()
    def reset(self): self.globals,self.functions,self.output,self.steps={},{},[],0
    def run_program(self,source):
        try:
            ast,_=parse_program(source); self.reset()
            for n in walk(ast):
                if n.kind=="function":
                    if n.name in self.functions: raise ArcaneFailure("ARC-SEM-003",f"duplicate function '{n.name}'",n.line)
                    if len(set(n.params))!=len(n.params): raise ArcaneFailure("ARC-SEM-002",f"duplicate parameter in '{n.name}'",n.line)
                    self.functions[n.name]=(n.params,n.expr,n.line)
            self._exec(ast,self.globals); return list(self.output)
        except ArcaneFailure as e: return e.diagnostic()
    def _exec(self,nodes,scope):
        for n in nodes:
            self.steps+=1
            if self.steps>self.max_steps: raise ArcaneFailure("ARC-RUN-003",f"execution step limit ({self.max_steps}) exceeded",n.line)
            if n.kind=="if":
                c=evaluate(n.expr,scope,self.functions,n.line,max_depth=self.max_call_depth)
                self._exec(n.yes if c else n.no,dict(scope))
            elif n.kind=="binding":
                if n.name in scope: raise ArcaneFailure("ARC-SEM-004",f"duplicate binding '{n.name}'",n.line)
                scope[n.name]=evaluate(n.expr,scope,self.functions,n.line,max_depth=self.max_call_depth)
            elif n.kind=="output":
                if n.name not in scope: raise ArcaneFailure("ARC-SEM-005",f"unresolved binding '{n.name}'",n.line)
                self.output.append(scope[n.name])
