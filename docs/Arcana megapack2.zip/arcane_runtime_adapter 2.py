"""Phase 7K: adapter utilities for connecting an Arcane evaluator to diagnostics.

This is an integration boundary, not a replacement evaluator. Pass a callable that
runs one existing evaluation; errors are converted to stable diagnostics and successful
results receive descriptive types without coercion.
"""
from dataclasses import dataclass
from typing import Any, Callable, Optional

from arcane_diagnostics import (
    ArcaneDiagnosticError, Diagnostic, ErrorCode, SourceSpan, TypedValue,
    diagnostic_for_exception, infer_type,
)

@dataclass(frozen=True)
class EvaluationResult:
    typed_value: Optional[TypedValue] = None
    diagnostic: Optional[Diagnostic] = None

    @property
    def ok(self) -> bool:
        return self.typed_value is not None and self.diagnostic is None

    def render(self) -> str:
        if self.diagnostic is not None:
            return self.diagnostic.render()
        if self.typed_value is None:
            return 'ARC-RUNTIME-999: evaluation produced no result'
        return f"{self.typed_value.type.describe()}: {self.typed_value.value!r}"


def evaluate_safely(evaluator: Callable[[], Any], span: SourceSpan = SourceSpan(),
                    dimensions: tuple[int, ...] = ()) -> EvaluationResult:
    """Run an evaluator callable and normalise its result or exception.

    Existing ArcaneDiagnosticError objects retain their original diagnostic. Other
    exceptions are mapped through the Phase 7J catalogue. Exception tracebacks are
    deliberately not included in user-facing output.
    """
    try:
        value = evaluator()
        return EvaluationResult(typed_value=TypedValue(value, infer_type(value, dimensions)))
    except ArcaneDiagnosticError as exc:
        return EvaluationResult(diagnostic=exc.diagnostic)
    except Exception as exc:  # adapter boundary intentionally normalises evaluator errors
        return EvaluationResult(diagnostic=diagnostic_for_exception(exc, span))


def require_success(result: EvaluationResult) -> TypedValue:
    """Return the typed value or raise a structured Arcane diagnostic error."""
    if result.diagnostic is not None:
        raise ArcaneDiagnosticError(result.diagnostic)
    if result.typed_value is None:
        raise ArcaneDiagnosticError(Diagnostic(
            code=ErrorCode.INTERNAL_ERROR,
            message='evaluation produced no result',
        ))
    return result.typed_value
