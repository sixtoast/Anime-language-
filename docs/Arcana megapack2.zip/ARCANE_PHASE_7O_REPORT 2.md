# Arcane Phase 7O — Control Flow and Program Composition

## Delivered

Phase 7O extends the reconstructed runnable subset from Phase 7N with:

- **Conditional selection:** `KWAI condition THEN expression ELSE expression` evaluates the condition and runs only the selected branch.
- **Multi-line programs:** `ArcaneRuntime.run_program(source)` executes newline-separated statements in order, skips blank lines and full-line comments beginning with `#`, and returns the results.
- **Stop-on-error behaviour:** a diagnostic stops program execution immediately, includes the source line number, and prevents later statements from running.
- **Regression coverage:** all prior function, arithmetic, units, repetition, aggregation, diagnostics and safety-limit tests remain, with new tests for conditionals and multi-line execution.

## Examples

```arcane
KWAM score => 8
KWAI FRAGT $score 5 THEN FRAPA $score 2 ELSE 0
```

The conditional result is `10`.

```arcane
# small multi-step program
KWAM width => 4
KWAM height => 3
KWAM area => FRATA $width $height
KWAT area
```

`run_program` returns a list of statement results; the final result is `12`.

## Validation

Run `python -m unittest -v` from this directory. Phase 7O suite: **28 tests passed**.

## Important status and limitations

This is a **reconstructed, provisional executable subset**, not a claim that the whole Arcane language is complete. `KWAI` and the `THEN`/`ELSE` form are provisional implementation syntax, not canonical language decisions. Conditional branches currently accept expressions, not nested statement blocks; `run_program` currently has no indentation-based blocks, loops over statements, imports, or file/module system. The grammar and spelling must be reconciled with the canonical Arcane language ledger before declaring them final.
