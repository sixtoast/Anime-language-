from arcane_runtime import ArcaneRuntime, ArcaneError, show

def main():
    r=ArcaneRuntime()
    print('Arcane Phase 7N subset — :help for examples, :quit to exit')
    while True:
        try: line=input('arcane> ').strip()
        except (EOFError,KeyboardInterrupt): print(); break
        if not line: continue
        if line==':quit': break
        if line==':help':
            print('KWAF square(x) => FRATA $x $x')
            print('square(4)')
            print('KWAR i FROM 1 TO 3 => square($i)')
            print('KWAS total FROM 1 TO 5 => $total')
            continue
        result=r.run_line(line)
        if hasattr(result,'render') and hasattr(result,'code'): print(result.render())
        elif hasattr(result,'render') and hasattr(result,'message'): print(result.render())
        else: print(show(result))

if __name__=='__main__': main()
