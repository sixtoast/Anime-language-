ARCANE PHASE 7C — PERSISTENT SESSIONS AND TRANSACTIONAL EXECUTION

Run interactive runtime:
  python arcane_session.py

Run demonstration script:
  python arcane_session.py --script example.arc

Run tests:
  python -m unittest -v test_arcane_runtime test_arcane_session

Python 3.10+; standard library only.
Syntax is a provisional implementation profile, not a canonical language change.
