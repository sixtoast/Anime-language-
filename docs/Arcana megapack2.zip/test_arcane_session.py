import io
import tempfile
import unittest
from pathlib import Path
from arcane_session import ArcaneSession, run_file
from arcane_runtime import format_quantity, ArcaneBindingError

class SessionTests(unittest.TestCase):
    def setUp(self): self.s = ArcaneSession()
    def run_ok(self, line):
        result = self.s.execute_line(line)
        self.assertTrue(result.ok, result.message)
        return result
    def test_session_persists_across_statements(self):
        self.run_ok('KWAS x = 2@m')
        self.run_ok('KWAS x <- 4@m')
        self.assertEqual(self.run_ok('KWAT x').message, '4 m')
    def test_live_binding_updates_in_session(self):
        self.run_ok('KWAS x = 2@m')
        self.run_ok('KWAK y = FRAPA $x 30@cm')
        self.assertEqual(self.run_ok('KWAT y').message, '2.3 m')
        self.run_ok('KWAS x <- 5@m')
        self.assertEqual(self.run_ok('KWAT y').message, '5.3 m')
    def test_failed_statement_rolls_back_state(self):
        self.run_ok('KWAS x = 2@m')
        bad = self.s.execute_line('KWAS x <- 3@s')
        self.assertFalse(bad.ok)
        self.assertEqual(self.run_ok('KWAT x').message, '2 m')
    def test_failed_declaration_not_left_behind(self):
        bad = self.s.execute_line('KWAM broken = FRAPA 1@m 2@s')
        self.assertFalse(bad.ok)
        self.assertFalse(self.s.execute_line('KWAT broken').ok)
    def test_duplicate_declaration_rolls_back(self):
        self.run_ok('KWAS x = 1')
        bad = self.s.execute_line('KWAM x = 2')
        self.assertFalse(bad.ok)
        self.assertEqual(self.run_ok('KWAT x').message, '1 1')
    def test_scope_commands(self):
        self.run_ok('KWAM x = 1')
        self.run_ok(':scope in')
        self.run_ok('KWAM x = 2')
        self.assertEqual(self.run_ok('KWAT x').message, '2 1')
        self.run_ok(':scope out')
        self.assertEqual(self.run_ok('KWAT x').message, '1 1')
    def test_cannot_exit_global_scope(self):
        r = self.s.execute_line(':scope out')
        self.assertFalse(r.ok)
        self.assertEqual(self.s.env.scope_depth, 0)
    def test_environment_listing(self):
        self.run_ok('KWAS x = 3@m')
        self.run_ok('KWAK y = FRAPA $x 1@m')
        text = self.run_ok(':env').message
        self.assertIn('x [state] = 3 m', text)
        self.assertIn('y [live] = 4 m', text)
    def test_help_and_scope_depth(self):
        self.assertIn('KWAM', self.run_ok(':help').message)
        self.assertEqual(self.run_ok(':scope').message, 'scope depth: 0')
    def test_blank_and_comment_ignored(self):
        self.assertTrue(self.s.execute_line('').ok)
        self.assertTrue(self.s.execute_line('# note').ok)
    def test_arithmetic_expression(self):
        self.assertEqual(self.run_ok('FRAPA 3 4').message, '7 1')
    def test_script_execution_persists(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / 'sample.arc'
            p.write_text('KWAS x = 2\nKWAS x <- 8\nKWAT x\n', encoding='utf-8')
            out = io.StringIO()
            self.assertEqual(run_file(p, out), 0)
            self.assertIn('3: 8 1', out.getvalue())
    def test_script_reports_errors_but_continues(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / 'sample.arc'
            p.write_text('KWAS x = 2\nKWAS x <- 4@s\nKWAT x\n', encoding='utf-8')
            out = io.StringIO()
            self.assertEqual(run_file(p, out), 1)
            self.assertIn('Error on statement 2', out.getvalue())
            self.assertIn('3: 2 1', out.getvalue())
    def test_quit_command(self):
        self.assertEqual(self.run_ok(':quit').message, 'Goodbye.')

if __name__ == '__main__': unittest.main(verbosity=2)
