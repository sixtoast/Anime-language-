ARCANE PHASE 7K — RUNTIME DIAGNOSTIC ADAPTER

Files
- arcane_diagnostics.py: stable diagnostic codes, source spans, exception mapping and value typing (Phase 7J)
- arcane_runtime_adapter.py: callable adapter that returns typed results or structured diagnostics (Phase 7K)
- test_arcane_diagnostics.py: 23 tests
- test_arcane_runtime_adapter.py: 10 adapter tests
- PHASE_7K_TEST_OUTPUT.txt: combined test output
- ARCANE_PHASE_7K_REPORT.md: implementation report and integration boundary
- Arcane_Lexicon_v5_draft.csv and Arcane_Decision_Ledger.docx: supplied project references

Run all tests from this directory:
  python -m unittest -v

Verified: 33/33 tests passed. Python standard library only.

Important boundary: this package does not contain the previous Phase 7H/7I evaluator. It delivers a tested integration adapter, not a claim of end-to-end integration with bounded repetition or aggregation. No language syntax or canonical vocabulary is changed.
