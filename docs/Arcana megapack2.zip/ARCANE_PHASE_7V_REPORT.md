# Arcane Phase 7V — Runtime and Checker Integration

## Outcome
Phase 7V improves the Phase 7U runnable reconstruction by sharing the parser between static syntax checking and runtime execution, adding pre-execution CLI validation, introducing a recursive-call depth guard, resetting runtime state between runs, and expanding integration coverage.

## Implemented
- `parse_program()` is now the common source parser for the runtime and syntax checker.
- The parser rejects malformed `KWAM`, `KWAF`, and `KWAT` statement shapes as well as invalid conditional structure before execution.
- `arcane_cli.py --run` runs syntax and lightweight semantic checks first and exits non-zero on detected errors.
- Function expression evaluation has a configurable call-depth guard (`ARC-RUN-002`).
- Runtime statement execution has a configurable step limit (`ARC-RUN-003`).
- `ArcaneRuntime.run_program()` resets globals, functions, output and step state for each invocation.
- Five new integration tests supplement the original twelve runtime tests.

## Validation performed
- `python -m unittest -v`: 17 tests passed.
- `python arcane_cli.py --check example.arc`: syntax and semantic checks passed.
- `python arcane_cli.py --run example.arc`: output `49`.
- CLI integration test confirms statically detectable semantic errors stop execution with exit code 1.
- Shared-parser test confirms the checker and runtime return the same diagnostic code for a missing conditional terminator.

## Known limitations
- This is still a provisional, minimal reconstructed subset, not the complete Arcane language or a verified continuation of the unavailable earlier source tree.
- Operator meanings, keyword spellings, scope rules and declaration semantics remain provisional.
- The semantic analyser is lightweight and regex-based; it is not a formal type checker and can miss complex expression cases.
- The runtime's step counter currently guards executed AST nodes; it is not a general instruction budget for expression evaluation.
- Functions remain expression-bodied, and there are no general loops, modules, imports, or statement-bodied functions.
- `KWAT` outputs a named binding only.
- Function declarations are registered as execution reaches them; forward function calls are not guaranteed by the runtime even if the lightweight semantic analyser can recognise a later declaration.
- The original Phase 7R/7T source and test suite were unavailable in the active workspace. Phase 7V builds on the newly reconstructed Phase 7U files and preserves their 12 tests rather than claiming to recover the old suite.

## Next implementation target
Phase 7W should focus on runtime/semantic consistency: function declaration and scope rules, stronger expression-aware semantic analysis, forward-call policy, and CLI-level conformance tests. It should not expand the grammar until those existing behaviours are aligned.
