import unittest
from arcane_runtime import Environment,fmt,ArcaneTypeError,ArcaneBindingError,ArcaneEvaluationError,ArcaneParseError

class FunctionCompositionTests(unittest.TestCase):
 def setUp(self): self.e=Environment()
 def define_basics(self):
  self.e.execute('KWAF increment(x) => FRAPA $x 1')
  self.e.execute('KWAF double(x) => FRAKA $x 2')
 def test_nested_function_calls(self):
  self.define_basics();self.assertEqual(fmt(self.e.execute('double(increment(3))')),'8 1')
 def test_kwac_accepts_nested_calls(self):
  self.define_basics();self.assertEqual(fmt(self.e.execute('KWAC double(increment(3))')),'8 1')
 def test_function_argument_can_be_arithmetic_expression(self):
  self.define_basics();self.assertEqual(fmt(self.e.execute('double(FRAPA 3 4)')),'14 1')
 def test_multiple_nested_arguments(self):
  self.e.execute('KWAF add(x,y) => FRAPA $x $y')
  self.e.execute('KWAF square(x) => FRAKA $x $x')
  self.assertEqual(fmt(self.e.execute('add(square(3), square(4))')),'25 1')
 def test_nested_calls_preserve_dimensions(self):
  self.e.execute('KWAF twice_distance(d) => FRAKA $d 2')
  self.assertEqual(fmt(self.e.execute('twice_distance(3@m)')),'6 m')
 def test_conditional_inside_composed_function(self):
  self.e.execute('KWAF positive(x) => FRASI FRAGT $x 0 $x 0')
  self.e.execute('KWAF double(x) => FRAKA $x 2')
  self.assertEqual(fmt(self.e.execute('double(positive(-3))')),'0 1')
  self.assertEqual(fmt(self.e.execute('double(positive(3))')),'6 1')
 def test_function_result_can_feed_prefix_expression(self):
  self.e.execute('KWAF inc(x) => FRAPA $x 1')
  self.assertEqual(fmt(self.e.execute('FRAPA inc(2) inc(5)')),'9 1')
 def test_call_arguments_evaluated_in_caller_scope(self):
  self.e.execute('KWAM base = 10')
  self.e.execute('KWAF plus_base(x) => FRAPA $x $base')
  self.assertEqual(fmt(self.e.execute('plus_base(FRAPA $base 2)')),'22 1')
 def test_arity_error_in_nested_call(self):
  self.e.execute('KWAF ident(x) => $x')
  with self.assertRaises(ArcaneBindingError):self.e.execute('FRAPA ident(1,2) 3')
 def test_unknown_nested_function_errors(self):
  with self.assertRaises(ArcaneBindingError):self.e.execute('FRAPA absent(1) 2')
 def test_dimension_error_propagates_through_nested_call(self):
  self.e.execute('KWAF add(x,y) => FRAPA $x $y')
  with self.assertRaises(ArcaneTypeError):self.e.execute('add(1@m,2@s)')
 def test_function_local_bindings_do_not_leak(self):
  self.e.execute('KWAF local(x) => FRAPA $x 1')
  self.e.execute('local(2)')
  with self.assertRaises(ArcaneBindingError):self.e.execute('KWAT x')
 def test_duplicate_function_is_rejected(self):
  self.e.execute('KWAF ident(x) => $x')
  with self.assertRaises(ArcaneBindingError):self.e.execute('KWAF ident(y) => $y')
 def test_duplicate_parameters_are_rejected(self):
  with self.assertRaises(ArcaneBindingError):self.e.execute('KWAF bad(x,X) => $x')
 def test_unclosed_call_errors(self):
  with self.assertRaises(ArcaneParseError):self.e.execute('absent(1')
 def test_nested_division_by_zero_errors(self):
  with self.assertRaises(ArcaneEvaluationError):self.e.execute('FRAPA 1 FRALA 2 0')
 def test_maximum_call_depth_guard(self):
  self.e.execute('KWAF ident(x) => $x');self.e.depth=self.e.max_depth
  with self.assertRaises(ArcaneEvaluationError):self.e.execute('ident(1)')

class ConditionalRegressionTests(unittest.TestCase):
 def setUp(self):self.e=Environment()
 def test_conditional_true_branch(self):self.assertEqual(fmt(self.e.execute('FRASI 1 12 20')),'12 1')
 def test_conditional_false_branch(self):self.assertEqual(fmt(self.e.execute('FRASI 0 12 20')),'20 1')
 def test_lazy_conditional_does_not_evaluate_unselected_division(self):self.assertEqual(fmt(self.e.execute('FRASI 1 8 FRALA 1 0')),'8 1')
 def test_greater_than(self):self.assertEqual(fmt(self.e.execute('FRAGT 3 2')),'1 1')
 def test_less_than_false(self):self.assertEqual(fmt(self.e.execute('FRALT 3 2')),'0 1')
 def test_equal(self):self.assertEqual(fmt(self.e.execute('FRAEQ 4 4')),'1 1')
 def test_comparison_dimensions(self):
  with self.assertRaises(ArcaneTypeError):self.e.execute('FRAGT 1@m 2@s')
 def test_conditional_selected_branch_type_is_returned(self):self.assertEqual(fmt(self.e.execute('FRASI 1 1@m 2@s')),'1 m')
 def test_division_by_zero_in_selected_branch(self):
  with self.assertRaises(ArcaneEvaluationError):self.e.execute('FRASI 0 9 FRALA 1 0')
 def test_unselected_branch_is_not_evaluated(self):self.assertEqual(fmt(self.e.execute('FRASI 1 4 $missing')),'4 1')

if __name__=='__main__':unittest.main(verbosity=2)
