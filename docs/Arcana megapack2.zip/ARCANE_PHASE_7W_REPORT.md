# Arcane Phase 7W — Function and Semantic Consistency

## Delivered
- Shared AST parser for syntax checking and execution.
- Program-wide function registration, enabling forward calls.
- Nested function calls and argument-count checks.
- Duplicate function/parameter diagnostics.
- Parameter-only function scope and branch-local bindings.
- CLI validation before execution.
- Runtime call-depth and statement-step limits.
- Regression tests for the above behaviours.

## Verification
Run `python -m unittest -v`, `python arcane_cli.py --check example.arc`, and `python arcane_cli.py --run example.arc`. The example should print `13`.

## Limitations
This is a provisional reconstructed subset, not the complete canonical Arcane language. Prefix operator semantics and keyword grammar require reconciliation with the authoritative specification. Semantic checks are static approximations; runtime checks remain necessary. The original earlier source tree was unavailable, so this package is a reproducible reconstruction rather than recovered history.
