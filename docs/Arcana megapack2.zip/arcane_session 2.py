import copy
from dataclasses import dataclass
from arcane_runtime import Environment, ArcaneError, format_quantity
@dataclass(frozen=True)
class Result: ok:bool; message:str; value:object=None
class ArcaneSession:
 def __init__(self):self.env=Environment();self.count=0
 def execute_line(self,line):
  s=line.strip()
  if not s or s.startswith('#'):return Result(True,'')
  if s.casefold() in (':quit',':exit'):return Result(True,'Goodbye.')
  if s.casefold()==':help':return Result(True,'KWAM name = expr | KWAS name = expr | KWAS name <- expr | KWAK name = expr | KWAT name | KWAF name(p1,p2) => expression | KWAC name(args) | :env | :scope in/out | :quit')
  if s.casefold()==':scope in':self.env.push_scope();return Result(True,f'entered scope {self.env.scope_depth}')
  if s.casefold()==':scope out':
   try:self.env.pop_scope();return Result(True,f'left scope; depth {self.env.scope_depth}')
   except ArcaneError as e:return Result(False,f'Error: {e}')
  if s.casefold()==':env':
   visible={}
   for scope in self.env._scopes:visible.update(scope)
   return Result(True,'\n'.join(f'{n} [{b.kind}] = {format_quantity(self.env.resolve(n))}' for n,b in sorted(visible.items())) or '(no bindings)')
  snap=copy.deepcopy((self.env._scopes,self.env.functions,self.env._resolving))
  self.count+=1
  try:
   v=self.env.execute(s);msg=format_quantity(v) if hasattr(v,'dimension') else str(v);return Result(True,msg,v)
  except Exception as e:
   self.env._scopes,self.env.functions,self.env._resolving=snap
   return Result(False,f'Error on statement {self.count}: {e}')
if __name__=='__main__':
 s=ArcaneSession();print('Arcane provisional runtime. Type :help or :quit.')
 while True:
  try:line=input('arcane> ')
  except EOFError:break
  r=s.execute_line(line)
  if r.message:print(r.message)
  if line.strip().casefold() in (':quit',':exit'):break
