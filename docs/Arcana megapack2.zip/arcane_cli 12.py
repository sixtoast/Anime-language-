"""Command-line interface for the minimal provisional Arcane runtime."""
import argparse
from pathlib import Path
from arcane_runtime import ArcaneRuntime, Diagnostic
from arcane_check import check_file
from arcane_semantic import analyze_file

def main():
    p=argparse.ArgumentParser(description='Check or run a provisional Arcane source file')
    p.add_argument('file',help='source file (.arc)')
    mode=p.add_mutually_exclusive_group()
    mode.add_argument('--check',action='store_true',help='run static syntax and semantic checks (default)')
    mode.add_argument('--run',action='store_true',help='run the supported executable subset')
    args=p.parse_args()
    if not args.run:
        reports=[check_file(args.file),analyze_file(args.file)]
        for r in reports: print(r.render())
        raise SystemExit(0 if all(r.ok for r in reports) else 1)
    try: source=Path(args.file).read_text(encoding='utf-8')
    except OSError as e: p.error(f'cannot read {args.file}: {e}')
    # Never execute a program that already has statically detectable errors.
    syntax=check_file(args.file); semantic=analyze_file(args.file)
    for report in (syntax,semantic):
        if not report.ok: print(report.render())
    if not syntax.ok or not semantic.ok: raise SystemExit(1)
    rt=ArcaneRuntime(); result=rt.run_program(source)
    if isinstance(result,Diagnostic): print(result.render(args.file)); raise SystemExit(1)
    for value in result: print(value)

if __name__=='__main__': main()
