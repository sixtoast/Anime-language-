import unittest
from arcane_semantic import analyze_source

class SemanticTests(unittest.TestCase):
    def codes(self, source): return [i.code for i in analyze_source(source).issues]
    def test_valid_example(self):
        self.assertEqual(self.codes('KWAF square(x) => FRATA $x $x\nKWAM input => 7\nKWAI FRAGT $input 5 THEN\n  KWAM answer => square($input)\n  KWAT answer\nELSE\n  KWAM answer => 0\n  KWAT answer\nEND'), [])
    def test_unresolved_binding(self):
        self.assertIn('ARC-SEM-005', self.codes('KWAM y => $missing'))
    def test_declared_binding_resolves(self):
        self.assertEqual(self.codes('KWAM x => 2\nKWAM y => $x + 1'), [])
    def test_undefined_function(self):
        self.assertIn('ARC-SEM-006', self.codes('KWAM x => absent(2)'))
    def test_function_arity(self):
        self.assertIn('ARC-SEM-007', self.codes('KWAF add(x, y) => $x + $y\nKWAM z => add(1)'))
    def test_forward_function_call(self):
        self.assertEqual(self.codes('KWAM z => add(1, 2)\nKWAF add(x, y) => $x + $y'), [])
    def test_duplicate_binding_same_scope(self):
        self.assertIn('ARC-SEM-004', self.codes('KWAM x => 1\nKWAM x => 2'))
    def test_duplicate_functions(self):
        self.assertIn('ARC-SEM-003', self.codes('KWAF f(x) => $x\nKWAF f(y) => $y'))
    def test_duplicate_parameters(self):
        self.assertIn('ARC-SEM-002', self.codes('KWAF f(x, x) => $x'))
    def test_nested_scope_sees_outer_binding(self):
        self.assertEqual(self.codes('KWAM x => 1\nKWAI FRAEQ $x 1 THEN\nKWAT x\nEND'), [])
    def test_branch_binding_does_not_escape(self):
        self.assertIn('ARC-SEM-005', self.codes('KWAI FRAEQ 1 1 THEN\nKWAM x => 1\nEND\nKWAT x'))
    def test_else_branch_has_separate_scope(self):
        self.assertEqual(self.codes('KWAI FRAEQ 1 1 THEN\nKWAM x => 1\nELSE\nKWAM x => 2\nEND'), [])
    def test_function_parameter_scope(self):
        self.assertEqual(self.codes('KWAF f(x) => $x'), [])
    def test_function_parameter_not_global(self):
        self.assertIn('ARC-SEM-005', self.codes('KWAF f(x) => $x\nKWAM y => $x'))
    def test_call_arity_zero(self):
        self.assertIn('ARC-SEM-007', self.codes('KWAF f() => 1\nKWAM x => f(2)'))

if __name__ == '__main__': unittest.main(verbosity=2)
