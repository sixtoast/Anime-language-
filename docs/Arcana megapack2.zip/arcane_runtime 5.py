"""Arcane provisional runtime: typed arithmetic, bindings, scopes, functions."""
from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
import re
class ArcaneError(ValueError): pass
class ArcaneParseError(ArcaneError): pass
class ArcaneTypeError(ArcaneError): pass
class ArcaneEvaluationError(ArcaneError): pass
class ArcaneBindingError(ArcaneError): pass
D0=(0,0,0); UNITS={'1':(Decimal(1),D0),'m':(Decimal(1),(1,0,0)),'cm':(Decimal('.01'),(1,0,0)),'km':(Decimal(1000),(1,0,0)),'s':(Decimal(1),(0,1,0)),'min':(Decimal(60),(0,1,0)),'h':(Decimal(3600),(0,1,0)),'kg':(Decimal(1),(0,0,1)),'g':(Decimal('.001'),(0,0,1))}
DIGITS={'ZA':0,'KI':1,'TO':2,'MU':3,'RE':4,'SA':5,'FI':6,'DU':7,'GO':8,'PE':9}; ARITY={'FRAPA':2,'FRATA':2,'FRAKA':2,'FRALA':2}
NUM_RE=re.compile(r'^([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)(?:@([A-Za-z0-9]+))?$'); NAME_RE=re.compile(r'^[A-Za-z_][A-Za-z0-9_]*$')
@dataclass(frozen=True)
class Quantity: value:Decimal; dimension:tuple[int,int,int]
@dataclass(frozen=True)
class Literal: quantity:Quantity
@dataclass(frozen=True)
class Reference: name:str
@dataclass(frozen=True)
class Call: op:str; args:tuple['Expr',...]
Expr=Literal|Reference|Call
def _add(a,b): return tuple(x+y for x,y in zip(a,b))
def _sub(a,b): return tuple(x-y for x,y in zip(a,b))
def _literal(tok):
 if tok in DIGITS:return Literal(Quantity(Decimal(DIGITS[tok]),D0))
 m=NUM_RE.fullmatch(tok)
 if not m:return None
 raw,unit=m.groups(); unit=unit or '1'
 if unit not in UNITS:raise ArcaneTypeError(f'unknown unit {unit!r}')
 try:v=Decimal(raw)
 except InvalidOperation as e:raise ArcaneParseError(f'invalid number {tok!r}') from e
 scale,d=UNITS[unit];return Literal(Quantity(v*scale,d))
class Parser:
 def __init__(self,t):self.t=t;self.i=0
 def expr(self):
  if self.i>=len(self.t):raise ArcaneParseError('unexpected end; expected operand')
  tok=self.t[self.i];self.i+=1;lit=_literal(tok)
  if lit is not None:return lit
  if tok.startswith('$') and NAME_RE.fullmatch(tok[1:]):return Reference(tok[1:])
  if tok in ARITY:return Call(tok,tuple(self.expr() for _ in range(ARITY[tok])))
  raise ArcaneParseError(f'unknown form or malformed literal {tok!r}')
def parse(s):
 if not isinstance(s,str) or not s.strip():raise ArcaneParseError('expression must not be empty')
 p=Parser(s.split());tree=p.expr()
 if p.i!=len(p.t):raise ArcaneParseError('extra tokens: '+' '.join(p.t[p.i:]))
 return tree
@dataclass
class Binding: kind:str; value:Quantity|None=None; expression:Expr|None=None
@dataclass(frozen=True)
class FunctionDef: name:str; params:tuple[str,...]; body:Expr
class Environment:
 def __init__(self):self._scopes=[{}];self._resolving=[];self.functions={};self._call_depth=0;self.max_call_depth=64
 @property
 def scope_depth(self):return len(self._scopes)-1
 def push_scope(self):self._scopes.append({})
 def pop_scope(self):
  if len(self._scopes)==1:raise ArcaneBindingError('cannot pop global scope')
  self._scopes.pop()
 def _valid(self,n):
  if not isinstance(n,str) or not NAME_RE.fullmatch(n):raise ArcaneBindingError(f'invalid name {n!r}')
 def _newkey(self,n):
  self._valid(n);k=n.casefold()
  if k in self._scopes[-1]:raise ArcaneBindingError(f'binding {n!r} already exists in this scope')
  return k
 def _find(self,n):
  for scope in reversed(self._scopes):
   if n.casefold() in scope:return scope[n.casefold()]
  raise ArcaneBindingError(f'unknown binding {n!r}')
 def resolve(self,n):
  b=self._find(n)
  if b.kind!='live':return b.value
  marker=(n.casefold(),id(b))
  if marker in self._resolving:raise ArcaneBindingError('cyclic live binding detected')
  self._resolving.append(marker)
  try:return self.evaluate_expr(b.expression)
  finally:self._resolving.pop()
 def evaluate_expr(self,e):
  if isinstance(e,Literal):return e.quantity
  if isinstance(e,Reference):return self.resolve(e.name)
  a,b=(self.evaluate_expr(x) for x in e.args)
  if e.op in ('FRAPA','FRATA') and a.dimension!=b.dimension:raise ArcaneTypeError(f'{e.op} requires matching dimensions; got {a.dimension}, {b.dimension}')
  if e.op=='FRAPA':return Quantity(a.value+b.value,a.dimension)
  if e.op=='FRATA':return Quantity(a.value-b.value,a.dimension)
  if e.op=='FRAKA':return Quantity(a.value*b.value,_add(a.dimension,b.dimension))
  if b.value==0:raise ArcaneEvaluationError('FRALA: division by zero')
  return Quantity(a.value/b.value,_sub(a.dimension,b.dimension))
 def create_value(self,n,s):k=self._newkey(n);v=self.evaluate_expr(parse(s));self._scopes[-1][k]=Binding('value',value=v);return v
 def create_state(self,n,s):k=self._newkey(n);v=self.evaluate_expr(parse(s));self._scopes[-1][k]=Binding('state',value=v);return v
 def create_live(self,n,s):k=self._newkey(n);e=parse(s);self.evaluate_expr(e);self._scopes[-1][k]=Binding('live',expression=e);return self.resolve(n)
 def assign(self,n,s):
  for scope in reversed(self._scopes):
   k=n.casefold()
   if k in scope:
    b=scope[k]
    if b.kind!='state':raise ArcaneBindingError(f'{n!r} is not mutable state')
    v=self.evaluate_expr(parse(s))
    if v.dimension!=b.value.dimension:raise ArcaneTypeError(f'cannot change dimensions of {n!r}')
    b.value=v;return v
  raise ArcaneBindingError(f'unknown binding {n!r}')
 def define_function(self,n,params,body):
  self._valid(n);k=n.casefold(); ps=tuple(params)
  if k in self.functions:raise ArcaneBindingError(f'function {n!r} already defined')
  if len({p.casefold() for p in ps})!=len(ps):raise ArcaneBindingError('duplicate parameter name')
  for p in ps:self._valid(p)
  tree=parse(body)
  # Validate syntax now; parameter refs are bound temporarily for semantic checking.
  self.push_scope()
  try:
   for p in ps:self._scopes[-1][p.casefold()]=Binding('value',value=Quantity(Decimal(1),D0))
   self.evaluate_expr(tree)
  finally:self.pop_scope()
  self.functions[k]=FunctionDef(n,ps,tree)
  return f'function {n} defined'
 def call_function(self,n,args):
  k=n.casefold()
  if k not in self.functions:raise ArcaneBindingError(f'unknown function {n!r}')
  fn=self.functions[k]
  if len(args)!=len(fn.params):raise ArcaneBindingError(f'{n} expects {len(fn.params)} argument(s), got {len(args)}')
  if self._call_depth>=self.max_call_depth:raise ArcaneEvaluationError('maximum function call depth exceeded')
  vals=[self.evaluate_expr(parse(a)) for a in args]
  self._call_depth+=1;self.push_scope()
  try:
   for p,v in zip(fn.params,vals):self._scopes[-1][p.casefold()]=Binding('value',value=v)
   return self.evaluate_expr(fn.body)
  finally:self.pop_scope();self._call_depth-=1
 def execute(self,s):
  s=s.strip();m=re.fullmatch(r'KWAM\s+(\w+)\s*=\s*(.+)',s,re.I)
  if m:return self.create_value(*m.groups())
  m=re.fullmatch(r'KWAS\s+(\w+)\s*=\s*(.+)',s,re.I)
  if m:return self.create_state(*m.groups())
  m=re.fullmatch(r'KWAS\s+(\w+)\s*<-\s*(.+)',s,re.I)
  if m:return self.assign(*m.groups())
  m=re.fullmatch(r'KWAK\s+(\w+)\s*=\s*(.+)',s,re.I)
  if m:return self.create_live(*m.groups())
  m=re.fullmatch(r'KWAT\s+(\w+)',s,re.I)
  if m:return self.resolve(m.group(1))
  m=re.fullmatch(r'KWAF\s+(\w+)\s*\((.*?)\)\s*=>\s*(.+)',s,re.I)
  if m:
   n,ps,body=m.groups();params=[] if not ps.strip() else [x.strip() for x in ps.split(',')]
   return self.define_function(n,params,body)
  m=re.fullmatch(r'KWAC\s+(\w+)\s*\((.*?)\)',s,re.I)
  if m:
   n,raw=m.groups();args=[] if not raw.strip() else [x.strip() for x in raw.split(',')]
   return self.call_function(n,args)
  if s.split() and s.split()[0] in ARITY:return self.evaluate_expr(parse(s))
  raise ArcaneParseError('unrecognised statement')
def format_quantity(q):
 v=format(q.value.normalize(),'f') if q.value else '0';l,t,m=q.dimension
 if (l,t,m)==D0:u='1'
 else:
  bits=[]
  for sym,p in [('m',l),('s',t),('kg',m)]:
   if p:bits.append(sym if p==1 else f'{sym}^{p}')
  u=' '.join(bits)
 return f'{v} {u}'
