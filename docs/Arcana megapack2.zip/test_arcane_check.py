import unittest
from arcane_check import check_source

class SyntaxCheckerTests(unittest.TestCase):
    def test_valid_nested_blocks(self):
        r=check_source('KWAM score => 8\nKWAI FRAGT $score 5 THEN\nKWAI FRAEQ 1 1 THEN\nKWAM answer => 42\nEND\nELSE\nKWAM answer => 0\nEND')
        self.assertTrue(r.ok, r.render())
    def test_missing_end(self): self.assertIn('ARC-PARSE-009', [x.code for x in check_source('KWAI FRAGT 2 1 THEN\nKWAM x => 1').issues])
    def test_unexpected_end(self): self.assertIn('ARC-PARSE-004', [x.code for x in check_source('END').issues])
    def test_else_without_header(self): self.assertIn('ARC-PARSE-002', [x.code for x in check_source('ELSE').issues])
    def test_duplicate_else(self): self.assertIn('ARC-PARSE-003', [x.code for x in check_source('KWAI FRAGT 2 1 THEN\nELSE\nELSE\nEND').issues])
    def test_malformed_header(self): self.assertIn('ARC-PARSE-005', [x.code for x in check_source('KWAI FRAGT 2 1').issues])
    def test_comment_and_blank_lines(self): self.assertTrue(check_source('# hi\n\nKWAM x => 4\nKWAT x').ok)
    def test_unknown_keyword(self): self.assertIn('ARC-PARSE-007', [x.code for x in check_source('KWZZ x => 1').issues])
    def test_line_number_preserved(self): self.assertEqual(check_source('# c\n\nEND').issues[0].line,3)
    def test_function_declaration_shape(self): self.assertTrue(check_source('KWAF square(x) => FRATA $x $x').ok)

if __name__ == '__main__': unittest.main(verbosity=2)
