# Arcane Phase 7Q example: file-based execution
KWAF square(x) => FRATA $x $x
KWAM input => 7
KWAI FRAGT $input 5 THEN
  KWAM answer => square($input)
  KWAT answer
ELSE
  KWAM answer => 0
  KWAT answer
END
