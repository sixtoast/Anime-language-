# Arcane Phase 7J — Value Typing and Stable Diagnostics

## Outcome

Phase 7J delivers a tested diagnostics and descriptive value-typing module. It defines stable diagnostic codes, source spans, human-readable hints, safe mapping from common evaluator exceptions, and descriptive type metadata for numbers, booleans, strings, lists, functions, and unknown values. The new module passes **23/23 tests**.

## Stable error codes

| Code | Meaning |
|---|---|
| ARC-PARSE-001 | Parse error |
| ARC-NAME-001 | Unknown name or binding |
| ARC-NAME-002 | Duplicate binding |
| ARC-TYPE-001 | Type mismatch |
| ARC-UNIT-001 | Dimension/unit mismatch |
| ARC-LOOP-001 | Invalid repetition bounds |
| ARC-LOOP-002 | Iteration limit exceeded |
| ARC-MATH-001 | Division by zero |
| ARC-RUNTIME-001 | Call-depth limit |
| ARC-RUNTIME-999 | Unclassified runtime error |

These codes are stable API proposals for the runtime layer. They do not change Arcane language syntax.

## Value typing

`infer_type` distinguishes booleans from numbers (important in Python, where `bool` subclasses `int`), describes numeric dimensions when supplied, identifies functions and strings, and describes homogeneous or heterogeneous collections without coercing values. Empty and heterogeneous collections are reported as `list[unknown]` rather than guessed.

## Important integration boundary

The prior Phase 7H/7I runtime files were not present in the active workspace when this phase began; only the original `Arcana pack.zip` was available. Therefore this phase provides independently tested integration utilities rather than claiming to have wired them into a missing evaluator or rerun the prior 40-test suite. The supplied Phase 5 lexicon and decision ledger are included for reference, but the new error codes and helper module are not canonised language vocabulary.

## Verification

Command: `python -m unittest -v`

Result: **23 tests passed.** Tests cover stable rendering, source-span validation, exception mapping, safe fallback handling, type inference, dimensional descriptors, homogeneous/heterogeneous lists, booleans, functions, and typed values.

## Next build step

Restore the latest Phase 7I runtime package into the active workspace and integrate `diagnostic_for_exception` at the interactive-shell boundary. Then run both Phase 7I regression tests and the new Phase 7J tests together. Do not claim end-to-end integration until that combined suite is passing.
