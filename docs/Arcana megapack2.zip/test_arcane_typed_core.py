import unittest
from decimal import Decimal
from arcane_typed_core import evaluate, parse, format_quantity, ArcaneParseError, ArcaneTypeError, ArcaneEvaluationError
class TypedCoreTests(unittest.TestCase):
    def test_digit_root_dimensionless(self): self.assertEqual(format_quantity(evaluate('KI')), '1 1')
    def test_numeric_literal(self): self.assertEqual(evaluate('3').value, Decimal(3))
    def test_add_dimensionless(self): self.assertEqual(evaluate('FRAPA 3 2').value, Decimal(5))
    def test_add_same_units(self): self.assertEqual(format_quantity(evaluate('FRAPA 2@m 30@cm')), '2.3 m')
    def test_subtract_operand_order(self): self.assertEqual(evaluate('FRATA 1 2').value, Decimal(-1))
    def test_multiply_dimensions(self): self.assertEqual(format_quantity(evaluate('FRAKA 3@m 2@s')), '6 m s')
    def test_divide_dimensions(self): self.assertEqual(format_quantity(evaluate('FRALA 10@m 2@s')), '5 m s^-1')
    def test_cm_normalisation(self): self.assertEqual(evaluate('FRAPA 1@m 100@cm').value, Decimal(2))
    def test_km_normalisation(self): self.assertEqual(evaluate('FRAPA 1@km 500@m').value, Decimal(1500))
    def test_incompatible_add_rejected(self):
        with self.assertRaises(ArcaneTypeError): evaluate('FRAPA 2@m 3@s')
    def test_incompatible_subtract_rejected(self):
        with self.assertRaises(ArcaneTypeError): evaluate('FRATA 2@kg 1@m')
    def test_nested_expression_dimensions(self): self.assertEqual(format_quantity(evaluate('FRAPA FRAKA 2@m 3@s FRAKA 4@m 1@s')), '10 m s')
    def test_division_by_zero(self):
        with self.assertRaises(ArcaneEvaluationError): evaluate('FRALA 1 0')
    def test_unknown_unit_rejected(self):
        with self.assertRaises(ArcaneTypeError): evaluate('3@furlong')
    def test_unknown_operator_rejected(self):
        with self.assertRaises(ArcaneParseError): parse('FRASHA KI')
    def test_extra_tokens_rejected(self):
        with self.assertRaises(ArcaneParseError): parse('FRAPA 1 2 3')
    def test_missing_operand_rejected(self):
        with self.assertRaises(ArcaneParseError): parse('FRAPA 1')
    def test_empty_expression_rejected(self):
        with self.assertRaises(ArcaneParseError): parse(' ')
    def test_bad_numeric_token_rejected(self):
        with self.assertRaises(ArcaneParseError): parse('2..4')
    def test_decimal_arithmetic(self): self.assertEqual(evaluate('FRAPA 0.1 0.2').value, Decimal('0.3'))
    def test_nested_dimension_error_detected_before_eval(self):
        with self.assertRaises(ArcaneTypeError): evaluate('FRAPA FRAKA 2@m 3@s 4@kg')
    def test_time_unit_conversion(self): self.assertEqual(evaluate('FRAPA 1@min 30@s').value, Decimal(90))
    def test_mass_unit_conversion(self): self.assertEqual(evaluate('FRAPA 1@kg 500@g').value, Decimal('1.500'))
if __name__=='__main__': unittest.main(verbosity=2)
