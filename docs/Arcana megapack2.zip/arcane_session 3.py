"""Minimal interactive shell for Phase 7E provisional runtime."""
import copy
from arcane_runtime import Environment,fmt,ArcaneError

def main():
 e=Environment();print('Arcane Phase 7E provisional runtime. :help for help, :quit to exit.')
 while True:
  try:s=input('arcane> ').strip()
  except EOFError:print();break
  if s.casefold() in (':quit',':exit'):break
  if s.casefold()==':help':print('KWAM name = expression | KWAF name(params) => expression | KWAC name(args) | FRASI condition then else | FRAGT/FRALT/FRAEQ comparisons | :quit');continue
  if not s:continue
  snap=copy.deepcopy((e.scopes,e.functions))
  try:
   v=e.execute(s);print(fmt(v) if hasattr(v,'dim') else v)
  except Exception as ex:
   e.scopes,e.functions=snap;print(f'Error: {type(ex).__name__}: {ex}')
if __name__=='__main__':main()
