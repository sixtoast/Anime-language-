import subprocess,sys,tempfile,unittest
from pathlib import Path
from arcane_runtime import ArcaneRuntime,Diagnostic
from arcane_check import check_source
from arcane_semantic import analyze_source
ROOT=Path(__file__).parent
class Phase7W(unittest.TestCase):
 def test_forward_function_call(self):
  self.assertEqual(ArcaneRuntime().run_program("KWAM x => double(4)\nKWAF double(n) => FRATA $n 2\nKWAT x"),[8])
 def test_nested_calls(self):
  self.assertEqual(ArcaneRuntime().run_program("KWAF add(a,b) => $a+$b\nKWAF sq(x) => $x*$x\nKWAM v => add(sq(3),1)\nKWAT v"),[10])
 def test_arity_nested_call(self):
  codes=[x.code for x in analyze_source("KWAF f(x) => $x\nKWAM v => f(g(1,2))").issues]
  self.assertIn("ARC-SEM-006",codes)
 def test_duplicate_functions(self):
  r=ArcaneRuntime().run_program("KWAM x => 1\nKWAF f(x) => $x\nKWAF f(y) => $y")
  self.assertIsInstance(r,Diagnostic); self.assertEqual(r.code,"ARC-SEM-003")
 def test_duplicate_params(self):
  self.assertIn("ARC-SEM-002",[x.code for x in analyze_source("KWAF f(x,x) => $x").issues])
 def test_duplicate_binding(self):
  self.assertIn("ARC-SEM-004",[x.code for x in analyze_source("KWAM x => 1\nKWAM x => 2").issues])
 def test_branch_binding_does_not_escape(self):
  self.assertIn("ARC-SEM-005",[x.code for x in analyze_source("KWAI FRAEQ 1 1 THEN\nKWAM a => 2\nEND\nKWAT a").issues])
 def test_branch_local_binding(self):
  self.assertEqual(ArcaneRuntime().run_program("KWAI FRAEQ 1 1 THEN\nKWAM a => 2\nKWAT a\nEND"),[2])
 def test_checker_and_runtime_share_parser(self):
  s="KWAI FRAEQ 1 1 THEN\nKWAM x => 2"
  self.assertFalse(check_source(s).ok); self.assertIsInstance(ArcaneRuntime().run_program(s),Diagnostic)
 def test_cli_blocks_invalid_program(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/"bad.arc"; p.write_text("KWAM x => 1\nKWAT absent\n")
   r=subprocess.run([sys.executable,str(ROOT/"arcane_cli.py"),"--run",str(p)],capture_output=True,text=True)
   self.assertEqual(r.returncode,1); self.assertIn("ARC-SEM-005",r.stdout); self.assertNotIn("\n1\n",r.stdout)
 def test_recursion_guard(self):
  r=ArcaneRuntime(max_call_depth=4).run_program("KWAF f(x) => f($x)\nKWAM y => f(1)")
  self.assertIsInstance(r,Diagnostic); self.assertEqual(r.code,"ARC-RUN-002")
 def test_step_guard(self):
  r=ArcaneRuntime(max_steps=1).run_program("KWAM a => 1\nKWAT a")
  self.assertIsInstance(r,Diagnostic); self.assertEqual(r.code,"ARC-RUN-003")
 def test_division_by_zero(self):
  r=ArcaneRuntime().run_program("KWAM a => 1/0")
  self.assertIsInstance(r,Diagnostic); self.assertEqual(r.code,"ARC-RUN-001")
 def test_precedence(self):
  self.assertEqual(ArcaneRuntime().run_program("KWAM a => 2+3*4\nKWAT a"),[14])
 def test_comment(self):
  self.assertEqual(ArcaneRuntime().run_program("# hi\nKWAM a => 3\nKWAT a"),[3])
 def test_state_reset(self):
  r=ArcaneRuntime(); self.assertEqual(r.run_program("KWAM a => 1\nKWAT a"),[1]); self.assertEqual(r.run_program("KWAM a => 2\nKWAT a"),[2])
 def test_function_does_not_capture_global(self):
  self.assertIn("ARC-SEM-005",[x.code for x in analyze_source("KWAM g => 9\nKWAF f(x) => $g+$x").issues])
if __name__=="__main__":unittest.main(verbosity=2)
