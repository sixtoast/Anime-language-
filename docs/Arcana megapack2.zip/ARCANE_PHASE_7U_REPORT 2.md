# Arcane Phase 7U — Minimal Runnable Workspace

## Outcome
A fresh, self-contained executable subset has been created because the previous Phase 7R/7T workspace and archives were not present in the active file workspace. This is a reconstruction from the recent documented examples, not a recovery of the missing original runtime.

## Implemented
- A recursive expression evaluator for numeric literals, `$binding` references, parentheses, unary signs, infix arithmetic/comparison operators, nested function calls, and the provisional binary `FR*` operators.
- `KWAM name => expression` binding declarations.
- `KWAF name(params) => expression` expression-bodied functions.
- `KWAT name` output statements.
- Structured `KWAI condition THEN` / optional `ELSE` / `END` blocks, including nesting and branch-local bindings.
- Full block-structure parsing before execution, so malformed blocks do not partially execute prior statements.
- CLI modes: `python arcane_cli.py --check file.arc` and `python arcane_cli.py --run file.arc`.
- Standard-library-only runtime and 12 automated tests.

## Validation
- `python -m unittest -v`: 12 tests passed.
- `python arcane_cli.py --check example.arc`: syntax and semantic checks passed (exit 0).
- `python arcane_cli.py --run example.arc`: printed `49` (exit 0).

## Boundaries and known limitations
- This is a minimal reconstructed subset, not the complete Arcane language or a verified continuation of the unavailable runtime source.
- Keyword spellings, operator meanings, scoping, and function declaration rules remain provisional.
- Function bodies are expressions only; no statements, return statements, modules, imports, or general loops.
- `KWAT` outputs a named binding only.
- The static checker and semantic checker are lightweight; runtime diagnostics remain authoritative for executable behavior.
- The existing 31-test Phase 7T suite could not be preserved because its files were not present in the workspace. The 12 tests in this package are newly runnable and included.

## Run
```bash
python -m unittest -v
python arcane_cli.py --check example.arc
python arcane_cli.py --run example.arc
```
