"""Small recursive-descent expression parser for the provisional Arcane subset."""
from __future__ import annotations
import re
from dataclasses import dataclass

TOKEN_RE = re.compile(r"\s*(\$[A-Za-z_][A-Za-z0-9_]*|(?:\d+\.\d+|\d+)|[A-Za-z_][A-Za-z0-9_]*|==|!=|<=|>=|[()+\-*/%,<>])")
BINARY_PREFIX = {"FRATA", "FRAPA", "FRAMO", "FRADI", "FRAGT", "FRALT", "FRAEQ", "FRANE", "FRAGE", "FRALE"}
PRECEDENCE = {"==": 1, "!=": 1, "<": 1, ">": 1, "<=": 1, ">=": 1, "+": 2, "-": 2, "*": 3, "/": 3, "%": 3}

class ExpressionSyntaxError(ValueError):
    pass

@dataclass
class Parser:
    tokens: list[str]
    pos: int = 0

    def peek(self): return self.tokens[self.pos] if self.pos < len(self.tokens) else None
    def take(self):
        token=self.peek()
        if token is None: raise ExpressionSyntaxError("unexpected end of expression")
        self.pos += 1
        return token

    def parse(self, min_precedence=0):
        token=self.take()
        if token == "(":
            self.parse(0)
            if self.take() != ")": raise ExpressionSyntaxError("expected ')' to close parenthesised expression")
        elif token in ("+", "-"):
            self.parse(4)
        elif token.startswith("$") or re.fullmatch(r"\d+(?:\.\d+)?", token):
            pass
        elif re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", token):
            if token in BINARY_PREFIX:
                self.parse(4)
                self.parse(4)
            elif self.peek() == "(":
                self.take()
                if self.peek() != ")":
                    self.parse(0)
                    while self.peek() == ",":
                        self.take(); self.parse(0)
                if self.take() != ")": raise ExpressionSyntaxError("expected ')' after function arguments")
            else:
                raise ExpressionSyntaxError(f"bare name '{token}' is not an expression; use a binding reference or function call")
        else:
            raise ExpressionSyntaxError(f"unexpected token '{token}'")
        while self.peek() in PRECEDENCE and PRECEDENCE[self.peek()] >= min_precedence:
            op=self.take(); self.parse(PRECEDENCE[op]+1)
        return True

def tokenize(expression: str) -> list[str]:
    tokens=[]; pos=0
    while pos < len(expression):
        match=TOKEN_RE.match(expression,pos)
        if not match:
            if expression[pos:].strip() == "": break
            raise ExpressionSyntaxError(f"unexpected character '{expression[pos]}'")
        tokens.append(match.group(1)); pos=match.end()
    if not tokens: raise ExpressionSyntaxError("expression is empty")
    return tokens

def validate_expression(expression: str) -> None:
    tokens=tokenize(expression)
    parser=Parser(tokens)
    parser.parse()
    if parser.peek() is not None: raise ExpressionSyntaxError(f"unexpected token '{parser.peek()}'")
