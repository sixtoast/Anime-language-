import unittest
from arcane_runtime import Environment,format_quantity,ArcaneBindingError,ArcaneTypeError
class FunctionTests(unittest.TestCase):
 def setUp(self):self.e=Environment()
 def test_function_basic(self):
  self.e.execute('KWAF add(a,b) => FRAPA $a $b');self.assertEqual(format_quantity(self.e.execute('KWAC add(2,3)')),'5 1')
 def test_function_typed_units(self):
  self.e.execute('KWAF extend(a,b) => FRAPA $a $b');self.assertEqual(format_quantity(self.e.execute('KWAC extend(2@m,30@cm)')),'2.3 m')
 def test_function_wrong_dimensions(self):
  self.e.execute('KWAF add(a,b) => FRAPA $a $b')
  with self.assertRaises(ArcaneTypeError):self.e.execute('KWAC add(2@m,3@s)')
 def test_wrong_arity(self):
  self.e.execute('KWAF f(a) => $a')
  with self.assertRaises(ArcaneBindingError):self.e.execute('KWAC f(1,2)')
 def test_unknown_function(self):
  with self.assertRaises(ArcaneBindingError):self.e.execute('KWAC missing(1)')
 def test_duplicate_function(self):
  self.e.execute('KWAF f(a) => $a')
  with self.assertRaises(ArcaneBindingError):self.e.execute('KWAF f(a) => $a')
 def test_duplicate_parameters(self):
  with self.assertRaises(ArcaneBindingError):self.e.execute('KWAF f(a,a) => $a')
 def test_local_parameter_does_not_leak(self):
  self.e.execute('KWAF f(x) => FRAPA $x 1');self.e.execute('KWAC f(2)')
  with self.assertRaises(ArcaneBindingError):self.e.execute('KWAT x')
 def test_function_can_read_global_binding(self):
  self.e.execute('KWAM base = 10');self.e.execute('KWAF addbase(x) => FRAPA $x $base');self.assertEqual(format_quantity(self.e.execute('KWAC addbase(2)')),'12 1')
 def test_function_local_param_shadows_global(self):
  self.e.execute('KWAM x = 99');self.e.execute('KWAF ident(x) => $x');self.assertEqual(format_quantity(self.e.execute('KWAC ident(2)')),'2 1')
 def test_sequential_function_composition(self):
  self.e.execute('KWAF double(x) => FRAKA $x 2');self.e.execute('KWAF plusone(x) => FRAPA $x 1');v=self.e.execute('KWAC double(3)');self.e.create_value('intermediate', format_quantity(v).split()[0]);self.assertEqual(format_quantity(self.e.execute('KWAC plusone($intermediate)')),'7 1')
 def test_regression_state_live(self):
  self.e.execute('KWAS x = 2');self.e.execute('KWAK y = FRAPA $x 3');self.e.execute('KWAS x <- 4');self.assertEqual(format_quantity(self.e.execute('KWAT y')),'7 1')
 def test_bad_function_body_not_registered(self):
  with self.assertRaises(Exception):self.e.execute('KWAF bad(a) => FRAPA $a 2@m')
  with self.assertRaises(ArcaneBindingError):self.e.execute('KWAC bad(1)')
if __name__=='__main__':unittest.main(verbosity=2)
