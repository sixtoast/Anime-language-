# Arcane Phase 7F — Function Composition

## Outcome
Phase 7F advances the runnable provisional Arcane subset by making user-defined function calls valid **expression nodes**. Function results can now feed directly into prefix operators, conditional branches, and other function arguments.

## New capability

```arcane
KWAF increment(x) => FRAPA $x 1
KWAF double(x) => FRAKA $x 2
KWAF add(x,y) => FRAPA $x $y

double(increment(3))
FRAPA increment(4) double(5)
add(double(3), increment(8))
```

Expected results for those three expressions are `8 1`, `15 1`, and `15 1` respectively. Unit-bearing values also pass through calls, for example `twice_distance(3@m)` returns `6 m` when `twice_distance(d)` multiplies `d` by 2.

## Implementation details
- Added a `Call` expression node and parser support for `function_name(expression, ...)`.
- Nested argument lists are parsed structurally instead of split naively on commas.
- Function arguments are evaluated in the caller's environment, then bound in a fresh local scope for the function body.
- Existing statement form `KWAC function(args)` remains supported, including nested calls.
- Function results can appear inside prefix expressions such as `FRAPA inc(2) inc(5)`.
- Existing conditional/comparison behaviour and unit-dimension checks remain covered by regression tests.
- Preserved a maximum active-call-depth guard and the session's per-command rollback behaviour.

## Verification
Automated test suite: **27 tests passed**. Tests cover nested composition, multiple arguments, prefix-expression integration, conditional composition, dimensions, errors, local-scope isolation, and existing Phase 7E conditional/comparison behaviour. The exact run is included in `PHASE_7F_TEST_OUTPUT.txt`.

## Boundaries and known limitations
- The grammar is still a small provisional subset, not the full Arcane grammar or canonical language specification.
- Functions must be defined before other function bodies that refer to them; forward declarations and recursion are not implemented as a supported language feature.
- Function body checking currently evaluates the body using dimensionless placeholder values for parameters. It is not a full static type/dimension inference system, and conditional branches are evaluated lazily at runtime rather than statically unified.
- Booleans are represented as dimensionless numeric 0/1; conditionals use non-zero truthiness.
- The runtime has only a few units (`m`, `cm`, `km`, `s`, `kg`) and operators (`FRAPA`, `FRATA`, `FRAKA`, `FRALA`, `FRASI`, `FRAGT`, `FRALT`, `FRAEQ`).
- This phase does not yet add loops, persistent modules, imports, a debugger, a full standard library, or integration with the complete magic-system model.

## Next implementation step
Phase 7G should add a narrowly scoped, test-backed capability that makes the language more usable—not another specification-only audit. Recommended direction: add logical composition (`AND`/`OR`/`NOT` equivalents) and formal boolean behaviour around comparisons and conditionals, with short-circuit tests and clear semantics, while retaining current arithmetic/function regression coverage. Before adopting spellings as canonical, reconcile them with the project lexicons in the supplied Arcana pack.
