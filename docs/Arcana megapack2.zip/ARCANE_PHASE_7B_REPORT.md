# Arcane Phase 7B — Mutable State and Lexical Scopes

## Delivered
This phase extends the runnable provisional runtime with mutable state, live dependency updates and lexical scope stacks.

- `KWAS name = expression` creates mutable state.
- `KWAS name <- expression` updates the nearest existing mutable binding.
- `KWAK name = expression` remains a live expression and is reevaluated when read.
- `push_scope()` / `pop_scope()` create and remove lexical scopes through the Python API.
- Inner scopes may shadow outer names; after scope exit, the outer binding is visible again.
- Updates preserve the state's dimensional type; invalid updates leave the old value intact.
- Immutable `KWAM` values cannot be updated; unknown names and duplicate declarations are rejected.

## Example
```python
from arcane_runtime import Environment, format_quantity
env = Environment()
env.execute('KWAS distance = 2@m')
env.execute('KWAK total = FRAPA $distance 30@cm')
print(format_quantity(env.execute('KWAT total'))) # 2.3 m
env.execute('KWAS distance <- 5@m')
print(format_quantity(env.execute('KWAT total'))) # 5.3 m
```

Run tests with `python -m unittest -v test_arcane_runtime.py` (Python 3.10+, standard library only).

## Syntax/canon boundary
The command spellings, `<-` assignment notation, `$name` references and API-driven scope entry/exit are provisional implementation syntax, not canonical Arcane grammar. This runtime has no persistent REPL/session protocol, function-local automatic scopes, concurrency model, or full magical feasibility engine. A dimensionally valid calculation does not establish physical or magical feasibility.

## Acceptance
The focused suite covers state updates, reactive live expressions, dimensional preservation, immutability, unknown assignments, duplicate names, shadowing, scope cleanup, outer-state updates, cycle detection and regression arithmetic. Phase 7B is complete for this vertical slice when the included tests pass; the broader Arcane language remains in development.

## Next implementation target
Phase 7C should provide a persistent interactive session and transactional statement execution (a failed statement must not partially alter state), then integrate a small typed function/procedure mechanism if supported by the recovered specification. Avoid broad audits unless they unblock a concrete implementation.
