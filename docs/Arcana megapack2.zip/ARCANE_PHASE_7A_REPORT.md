# Arcane Phase 7A — Typed Bindings and References

## Outcome
A runnable environment now supports `KWAM` value bindings, `KWAT` references, and `KWAK` live-expression bindings using the Phase 6Z dimensional arithmetic evaluator. Expressions can refer to existing bindings with `$name` syntax. This is a working vertical slice, not an audit-only phase.

## Quick start
Requires Python 3.10+ and only the standard library.

```bash
python arcane_runtime.py 'KWAM distance = 3@m'
python arcane_runtime.py 'KWAT distance'  # each CLI invocation has a fresh environment, so use the Python API for multi-statement sessions
python -m unittest -v test_arcane_runtime.py
```

For a multi-statement session:

```python
from arcane_runtime import Environment, format_quantity
env = Environment()
env.execute('KWAM distance = 3@m')
env.execute('KWAM extension = 30@cm')
print(format_quantity(env.evaluate_expr(__import__('arcane_runtime').parse('FRAPA $distance $extension'))))
```

## Implemented
- `KWAM name = expression`: create a value binding, evaluating and validating the expression once.
- `KWAT name`: resolve an existing binding, case-insensitively.
- `KWAK name = expression`: create a live expression binding, re-evaluated on each read.
- `$name`: reference an existing binding inside an expression.
- Binding name validation, duplicate rejection, unknown-reference errors, and a cyclic-live-binding guard.
- Reuses dimensional checks for stored and live expressions; failed type checks do not create a binding.

## Limitations and canon boundary
The syntax and semantics are provisional implementation choices, not canonical Arcane grammar. Value bindings are immutable in this slice, so a live binding currently reevaluates against stable dependencies; meaningful reactive updates require a future assignment/state contract. Forward references are rejected. The CLI creates a fresh environment for each invocation; use the Python `Environment` API for a multi-statement session. No persistence, lexical scopes, functions, control flow, or magic/physical execution is implemented.

## Acceptance result
Focused tests cover binding creation, reference resolution, type failures, invalid names, duplicate names, live expression evaluation and cycle detection. Passing these tests establishes this feature slice only, not full-language completion.

## Next implementation milestone
Phase 7B should add explicit state update and scoped environments, then demonstrate that `KWAK` changes when a dependency changes. Keep that behaviour provisional until its canon contract is recovered or approved. Do not return to broad auditing unless a concrete implementation blocker appears.
