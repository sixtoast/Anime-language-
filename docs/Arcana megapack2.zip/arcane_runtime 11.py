"""Arcane Phase 7L: compact runnable expression runtime with diagnostics.

This is a deliberately small executable subset. Operator spellings and statement
forms marked provisional in the project history remain provisional here.
"""
from dataclasses import dataclass
import re
from arcane_diagnostics import (ArcaneDiagnosticError, Diagnostic, ErrorCode,
    SourceSpan, diagnostic_for_exception)
from arcane_runtime_adapter import EvaluationResult, evaluate_safely

@dataclass(frozen=True)
class Quantity:
    value: float
    dimensions: tuple[int, ...] = ()
    def _same(self, other):
        if not isinstance(other, Quantity): raise TypeError('numeric value required')
        if self.dimensions != other.dimensions: raise ValueError('dimension mismatch')
    def __add__(self, other): self._same(other); return Quantity(self.value+other.value,self.dimensions)
    def __sub__(self, other): self._same(other); return Quantity(self.value-other.value,self.dimensions)
    def __mul__(self, other):
        if not isinstance(other,Quantity): raise TypeError('numeric value required')
        n=max(len(self.dimensions),len(other.dimensions)); a=self.dimensions+(0,)*(n-len(self.dimensions)); b=other.dimensions+(0,)*(n-len(other.dimensions))
        return Quantity(self.value*other.value,tuple(x+y for x,y in zip(a,b)))
    def __truediv__(self, other):
        if not isinstance(other,Quantity): raise TypeError('numeric value required')
        if other.value==0: raise ZeroDivisionError('division by zero')
        n=max(len(self.dimensions),len(other.dimensions)); a=self.dimensions+(0,)*(n-len(self.dimensions)); b=other.dimensions+(0,)*(n-len(other.dimensions))
        return Quantity(self.value/other.value,tuple(x-y for x,y in zip(a,b)))

UNITS={'1':(1.0,()),'m':(1.0,(1,0,0)),'cm':(0.01,(1,0,0)),'km':(1000.0,(1,0,0)),'s':(1.0,(0,1,0)),'kg':(1.0,(0,0,1))}
TOKEN=re.compile(r'\s*(?:(\d+(?:\.\d+)?)|([A-Za-z_][A-Za-z_0-9]*)|(\$[A-Za-z_][A-Za-z_0-9]*)|(\()|(\))|(,))')
class ArcaneRuntime:
    def __init__(self, max_iterations=1000, max_call_depth=64):
        self.bindings={}; self.max_iterations=max_iterations; self.max_call_depth=max_call_depth
    def define(self,name,value):
        if name in self.bindings: raise ValueError(f'duplicate binding {name}')
        self.bindings[name]=value; return value
    def lookup(self,name):
        if name not in self.bindings: raise ValueError(f'unknown binding {name}')
        return self.bindings[name]
    def _tokens(self, source):
        pos=0; out=[]
        while pos<len(source):
            if source[pos:].strip()=='' : break
            m=TOKEN.match(source,pos)
            if not m: raise ValueError(f'unexpected token at column {pos+1}')
            out.append(next((x for x in m.groups() if x is not None)))
            pos=m.end()
        return out
    def evaluate(self, source):
        try: tokens=self._tokens(source)
        except Exception as exc: raise ArcaneDiagnosticError(diagnostic_for_exception(exc)) from None
        i=0
        def expr():
            nonlocal i
            if i>=len(tokens): raise ValueError('unexpected end of expression')
            t=tokens[i]; i+=1
            if t=='(':
                v=expr()
                if i>=len(tokens) or tokens[i]!=')': raise ValueError('unexpected token: expected )')
                i+=1; return v
            if t.startswith('$'): return self.lookup(t[1:])
            if t.replace('.','',1).isdigit(): return Quantity(float(t))
            if t in ('FRNOT','FRAND','FROR'):
                if t=='FRNOT': return not truth(expr())
                left=truth(expr())
                right=truth(expr())
                return bool(left and right) if t=='FRAND' else bool(left or right)
            if t in ('FRAPA','FRALA','FRATA','FRAKA','FRAGT','FRALT','FRAEQ'):
                a=expr(); b=expr()
                if t=='FRAPA': return a+b
                if t=='FRALA': return a-b
                if t=='FRATA': return a*b
                if t=='FRAKA': return a/b
                if not isinstance(a,Quantity) or not isinstance(b,Quantity): raise TypeError('numeric value required')
                a._same(b)
                return a.value>b.value if t=='FRAGT' else a.value<b.value if t=='FRALT' else a.value==b.value
            if t in UNITS:
                factor,dims=UNITS[t]; return Quantity(factor,dims)
            raise ValueError(f'unknown binding {t}')
        try: value=expr()
        except Exception as exc: raise ArcaneDiagnosticError(diagnostic_for_exception(exc)) from None
        if i!=len(tokens): raise ArcaneDiagnosticError(Diagnostic(ErrorCode.PARSE_ERROR,f'unexpected token {tokens[i]}'))
        return value
    def run_line(self,line):
        line=line.strip()
        try:
            m=re.fullmatch(r'KWAM\s+([A-Za-z_]\w*)\s*=>\s*(.+)',line)
            if m: return self.define(m.group(1),self.evaluate(m.group(2)))
            m=re.fullmatch(r'KWAT\s+([A-Za-z_]\w*)',line)
            if m: return self.lookup(m.group(1))
            return self.evaluate(line)
        except ArcaneDiagnosticError as e: return EvaluationResult(diagnostic=e.diagnostic)
        except Exception as e: return evaluate_safely(lambda: (_ for _ in ()).throw(e)).diagnostic

def truth(value):
    if isinstance(value,bool): return value
    if isinstance(value,Quantity) and not value.dimensions and value.value in (0,1): return value.value==1
    raise TypeError('logical operation requires boolean or dimensionless 0/1')
