"""Minimal interactive shell for the Phase 7L Arcane runtime subset."""
from arcane_runtime import ArcaneRuntime, Quantity
from arcane_diagnostics import ArcaneDiagnosticError

def show(value):
    if isinstance(value, Quantity):
        dims = value.dimensions
        unit = ' dimensionless' if not dims else f' dimensions={dims}'
        return f'{value.value:g}{unit}'
    return repr(value)

def main():
    runtime = ArcaneRuntime()
    print('Arcane Phase 7L subset. Type :quit to exit; :help for examples.')
    while True:
        try: line = input('arcane> ').strip()
        except (EOFError, KeyboardInterrupt):
            print(); break
        if not line: continue
        if line == ':quit': break
        if line == ':help':
            print('Examples: FRAPA 2 3 | FRATA m s | KWAM total => FRAPA 2 3 | KWAT total')
            continue
        try:
            result = runtime.run_line(line)
            if hasattr(result, 'render') and hasattr(result, 'diagnostic'):
                print(result.render())
            elif hasattr(result, 'code') and hasattr(result, 'message'):
                print(result.render())
            else: print(show(result))
        except ArcaneDiagnosticError as exc: print(exc.diagnostic.render())
        except Exception as exc: print(f'Runtime error: {exc}')

if __name__ == '__main__': main()
