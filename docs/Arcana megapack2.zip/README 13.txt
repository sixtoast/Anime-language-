ARCANE PHASE 7L — RUNNABLE RUNTIME CONSOLIDATION

Quick start
  python arcane_cli.py

Run all tests
  python -m unittest -v

Runtime features in this small executable subset
- Prefix arithmetic: FRAPA, FRALA, FRATA, FRAKA
- Comparisons: FRAGT, FRALT, FRAEQ
- Logic: FRAND, FROR, FRNOT
- Parenthesised expressions
- Units: 1, m, cm, km, s, kg
- Bindings: KWAM name => expression; KWAT name
- Stable diagnostics from Phase 7J

The runtime is not yet the full Phase 7H/7I evaluator. KWAR, KWAS, functions,
full canonical grammar, short-circuit logic and authoritative vocabulary checks
remain outstanding. Operator spellings and statement syntax are provisional.

Run tests with: python -m unittest -v
Verified suite: 54/54 tests passed.
