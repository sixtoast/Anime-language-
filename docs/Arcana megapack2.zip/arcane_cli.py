import argparse
from pathlib import Path
from arcane_check import check_file
from arcane_semantic import analyze_file
from arcane_runtime import ArcaneRuntime,Diagnostic
def main():
    p=argparse.ArgumentParser(description="Arcane provisional interpreter")
    p.add_argument("file"); g=p.add_mutually_exclusive_group()
    g.add_argument("--check",action="store_true"); g.add_argument("--run",action="store_true")
    a=p.parse_args(); syntax=check_file(a.file); sem=analyze_file(a.file)
    if not a.run:
        print(syntax.render()); print(sem.render())
        raise SystemExit(0 if syntax.ok and sem.ok else 1)
    for r in (syntax,sem):
        if not r.ok: print(r.render())
    if not syntax.ok or not sem.ok: raise SystemExit(1)
    try: source=Path(a.file).read_text(encoding="utf-8")
    except OSError as e: print(f"error ARC-IO-001: {e}"); raise SystemExit(1)
    result=ArcaneRuntime().run_program(source)
    if isinstance(result,Diagnostic): print(result.render(a.file)); raise SystemExit(1)
    for x in result: print(x)
if __name__=="__main__":main()
