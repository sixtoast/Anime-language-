"""Arcane Phase 7R static checker CLI. This does not execute programs."""
import argparse
from arcane_check import check_file

def main():
    parser = argparse.ArgumentParser(description="Check syntax in the provisional Arcane subset")
    parser.add_argument("file", help="Arcane source file (.arc)")
    parser.add_argument("--check", action="store_true", help="check syntax only (the only supported mode)")
    args = parser.parse_args()
    report = check_file(args.file)
    print(report.render())
    raise SystemExit(0 if report.ok else 1)

if __name__ == "__main__": main()
