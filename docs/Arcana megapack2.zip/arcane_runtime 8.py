"""Arcane Phase 7F provisional executable subset: composable function expressions."""
from dataclasses import dataclass
from decimal import Decimal
import re

class ArcaneError(ValueError): pass
class ArcaneParseError(ArcaneError): pass
class ArcaneTypeError(ArcaneError): pass
class ArcaneBindingError(ArcaneError): pass
class ArcaneEvaluationError(ArcaneError): pass

D0=(0,0,0)
UNITS={'1':(Decimal(1),D0),'m':(Decimal(1),(1,0,0)),'cm':(Decimal('.01'),(1,0,0)),'km':(Decimal(1000),(1,0,0)),'s':(Decimal(1),(0,1,0)),'kg':(Decimal(1),(0,0,1))}
# FRAND / FROR / FRNOT are provisional runtime spellings, not asserted as canonical lexicon forms.
ARITY={'FRAPA':2,'FRATA':2,'FRAKA':2,'FRALA':2,'FRASI':3,'FRAGT':2,'FRALT':2,'FRAEQ':2,'FRAND':2,'FROR':2,'FRNOT':1}
@dataclass(frozen=True)
class Q: value:Decimal; dim:tuple[int,int,int]=D0
@dataclass(frozen=True)
class Lit: q:Q
@dataclass(frozen=True)
class Ref: name:str
@dataclass(frozen=True)
class Node: op:str; args:tuple
@dataclass(frozen=True)
class Call: name:str; args:tuple
@dataclass(frozen=True)
class Func: name:str; params:tuple[str,...]; body:object

TOKEN=re.compile(r'\s*(\$[A-Za-z_]\w*|[A-Za-z_]\w*|[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:@[A-Za-z]+)?|[(),])')
def tokens(s):
 out=[];pos=0
 while pos<len(s):
  m=TOKEN.match(s,pos)
  if not m:
   if s[pos:].strip():raise ArcaneParseError(f'unexpected text near {s[pos:pos+16]!r}')
   break
  out.append(m.group(1));pos=m.end()
 return out

class Parser:
 def __init__(self,ts):self.ts=ts;self.i=0
 def peek(self):return self.ts[self.i] if self.i<len(self.ts) else None
 def take(self):
  if self.i>=len(self.ts):raise ArcaneParseError('unexpected end of expression')
  t=self.ts[self.i];self.i+=1;return t
 def expr(self):
  t=self.take()
  op=t.upper()
  if op in ARITY:return Node(op,tuple(self.expr() for _ in range(ARITY[op])))
  if t.startswith('$'):return Ref(t[1:])
  m=re.fullmatch(r'([+-]?(?:\d+(?:\.\d*)?|\.\d+))(?:@([A-Za-z]+))?',t)
  if m:
   n,u=m.groups();u=u or '1'
   if u not in UNITS:raise ArcaneTypeError(f'unknown unit {u}')
   scale,d=UNITS[u];return Lit(Q(Decimal(n)*scale,d))
  if re.fullmatch(r'[A-Za-z_]\w*',t):
   if self.peek()!='(':raise ArcaneParseError(f'unknown expression token {t!r}; function calls require parentheses')
   self.take() # (
   args=[]
   if self.peek()!=')':
    while True:
     args.append(self.expr())
     if self.peek()==',':self.take();continue
     break
   if self.take()!=')':raise ArcaneParseError('expected closing parenthesis')
   return Call(t,tuple(args))
  raise ArcaneParseError(f'unknown expression token {t!r}')

def parse(s):
 p=Parser(tokens(s));e=p.expr()
 if p.i!=len(p.ts):raise ArcaneParseError('extra expression tokens')
 return e

class Environment:
 def __init__(self):self.scopes=[{}];self.functions={};self.depth=0;self.max_depth=64
 def push(self):self.scopes.append({})
 def pop(self):
  if len(self.scopes)==1:raise ArcaneBindingError('cannot pop global scope')
  self.scopes.pop()
 def lookup(self,n):
  for s in reversed(self.scopes):
   if n.casefold() in s:return s[n.casefold()]
  raise ArcaneBindingError(f'unknown binding {n!r}')
 def eval(self,e):
  if isinstance(e,Lit):return e.q
  if isinstance(e,Ref):return self.lookup(e.name)
  if isinstance(e,Call):return self.call_values(e.name,[self.eval(x) for x in e.args])
  op=e.op
  if op=='FRASI':
   condition=self.eval(e.args[0]);return self.eval(e.args[1] if condition.value!=0 else e.args[2])
  if op=='FRNOT':
   a=self.eval(e.args[0])
   if a.dim!=D0:raise ArcaneTypeError('FRNOT requires a dimensionless operand')
   return Q(Decimal(0 if a.value!=0 else 1),D0)
  if op=='FRAND':
   left=self.eval(e.args[0])
   if left.dim!=D0:raise ArcaneTypeError('FRAND requires dimensionless operands')
   if left.value==0:return Q(Decimal(0),D0)
   right=self.eval(e.args[1])
   if right.dim!=D0:raise ArcaneTypeError('FRAND requires dimensionless operands')
   return Q(Decimal(1 if right.value!=0 else 0),D0)
  if op=='FROR':
   left=self.eval(e.args[0])
   if left.dim!=D0:raise ArcaneTypeError('FROR requires dimensionless operands')
   if left.value!=0:return Q(Decimal(1),D0)
   right=self.eval(e.args[1])
   if right.dim!=D0:raise ArcaneTypeError('FROR requires dimensionless operands')
   return Q(Decimal(1 if right.value!=0 else 0),D0)
  a=[self.eval(x) for x in e.args]
  if op in ('FRAPA','FRATA','FRAGT','FRALT','FRAEQ') and a[0].dim!=a[1].dim:raise ArcaneTypeError(f'{op} requires matching dimensions')
  if op=='FRAGT':return Q(Decimal(a[0].value>a[1].value),D0)
  if op=='FRALT':return Q(Decimal(a[0].value<a[1].value),D0)
  if op=='FRAEQ':return Q(Decimal(a[0].value==a[1].value),D0)
  if op=='FRAPA':return Q(a[0].value+a[1].value,a[0].dim)
  if op=='FRATA':return Q(a[0].value-a[1].value,a[0].dim)
  if op=='FRAKA':return Q(a[0].value*a[1].value,tuple(x+y for x,y in zip(a[0].dim,a[1].dim)))
  if not a[1].value:raise ArcaneEvaluationError('division by zero')
  return Q(a[0].value/a[1].value,tuple(x-y for x,y in zip(a[0].dim,a[1].dim)))
 def define(self,name,params,body):
  k=name.casefold()
  if k in self.functions:raise ArcaneBindingError(f'function {name} already defined')
  if len(set(p.casefold() for p in params))!=len(params):raise ArcaneBindingError('duplicate parameter')
  if any(not re.fullmatch(r'[A-Za-z_]\w*',p) for p in params):raise ArcaneParseError('invalid parameter name')
  tree=parse(body);self.push()
  try:
   for p in params:self.scopes[-1][p.casefold()]=Q(Decimal(1))
   self.eval(tree)
  finally:self.pop()
  self.functions[k]=Func(name,tuple(params),tree)
  return f'function {name} defined'
 def call_values(self,name,vals):
  f=self.functions.get(name.casefold())
  if not f:raise ArcaneBindingError(f'unknown function {name!r}')
  if len(vals)!=len(f.params):raise ArcaneBindingError(f'{name} expects {len(f.params)} argument(s), got {len(vals)}')
  if self.depth>=self.max_depth:raise ArcaneEvaluationError('maximum call depth exceeded')
  self.push();self.depth+=1
  try:
   for p,v in zip(f.params,vals):self.scopes[-1][p.casefold()]=v
   return self.eval(f.body)
  finally:self.depth-=1;self.pop()
 def call(self,name,args):
  # Backwards-compatible API for callers passing argument expressions as strings.
  return self.call_values(name,[self.eval(parse(x)) for x in args])
 def execute(self,s):
  m=re.fullmatch(r'KWAM\s+(\w+)\s*=\s*(.+)',s,re.I)
  if m:
   k=m[1].casefold()
   if k in self.scopes[-1]:raise ArcaneBindingError('duplicate binding')
   v=self.eval(parse(m[2]));self.scopes[-1][k]=v;return v
  m=re.fullmatch(r'KWAF\s+(\w+)\s*\((.*?)\)\s*=>\s*(.+)',s,re.I)
  if m:return self.define(m[1],[p.strip() for p in m[2].split(',') if p.strip()],m[3])
  m=re.fullmatch(r'KWAC\s+(\w+)\s*\((.*)\)',s,re.I)
  if m:
   # Parse the complete call, so nested calls and comma-containing arguments work.
   tree=parse(m[1]+'('+m[2]+')')
   if not isinstance(tree,Call):raise ArcaneParseError('expected function call')
   return self.eval(tree)
  m=re.fullmatch(r'KWAT\s+(\w+)',s,re.I)
  if m:return self.lookup(m[1])
  return self.eval(parse(s))

def fmt(q):
 v=format(q.value.normalize(),'f') if q.value else '0';d=q.dim
 u=' '.join(sym if p==1 else f'{sym}^{p}' for sym,p in zip(('m','s','kg'),d) if p) or '1'
 return f'{v} {u}'
