import unittest
from arcane_diagnostics import (ErrorCode, SourceSpan, Diagnostic, ArcaneDiagnosticError,
    ValueKind, ValueType, TypedValue, infer_type, diagnostic_for_exception)

class DiagnosticTests(unittest.TestCase):
 def test_stable_render(self):
  d=Diagnostic(ErrorCode.UNKNOWN_NAME,'unknown binding x',SourceSpan(3,5),'Check scope.')
  self.assertEqual(d.render(),'ARC-NAME-001 at 3:5: unknown binding x\n  hint: Check scope.')
 def test_source_positions_are_one_based(self):
  with self.assertRaises(ValueError):SourceSpan(0,1)
  with self.assertRaises(ValueError):SourceSpan(1,0)
 def test_end_line_cannot_precede_start(self):
  with self.assertRaises(ValueError):SourceSpan(4,1,3,2)
 def test_exception_wrap(self):
  e=ArcaneDiagnosticError(Diagnostic(ErrorCode.PARSE_ERROR,'unexpected token'))
  self.assertEqual(e.diagnostic.code,ErrorCode.PARSE_ERROR)
 def test_division_mapping(self):self.assertEqual(diagnostic_for_exception(ZeroDivisionError('division by zero')).code,ErrorCode.DIVISION_BY_ZERO)
 def test_unknown_name_mapping(self):self.assertEqual(diagnostic_for_exception(ValueError('unknown binding x')).code,ErrorCode.UNKNOWN_NAME)
 def test_duplicate_mapping(self):self.assertEqual(diagnostic_for_exception(ValueError('duplicate binding')).code,ErrorCode.DUPLICATE_BINDING)
 def test_dimension_mapping(self):self.assertEqual(diagnostic_for_exception(ValueError('dimension mismatch')).code,ErrorCode.DIMENSION_MISMATCH)
 def test_bounds_mapping(self):self.assertEqual(diagnostic_for_exception(ValueError('bounds must be integers')).code,ErrorCode.INVALID_BOUNDS)
 def test_iteration_mapping(self):self.assertEqual(diagnostic_for_exception(ValueError('maximum iteration count exceeded')).code,ErrorCode.ITERATION_LIMIT)
 def test_type_mapping(self):self.assertEqual(diagnostic_for_exception(TypeError('numeric value required')).code,ErrorCode.TYPE_MISMATCH)
 def test_parse_mapping(self):self.assertEqual(diagnostic_for_exception(ValueError('unexpected token')).code,ErrorCode.PARSE_ERROR)
 def test_unknown_mapping_is_safe(self):self.assertEqual(diagnostic_for_exception(RuntimeError('oops')).code,ErrorCode.INTERNAL_ERROR)

class ValueTypingTests(unittest.TestCase):
 def test_bool_is_not_number(self):self.assertEqual(infer_type(True).kind,ValueKind.BOOLEAN)
 def test_int_number(self):self.assertEqual(infer_type(4).kind,ValueKind.NUMBER)
 def test_dimension_descriptor(self):self.assertEqual(infer_type(4,(1,0,0)).describe(),'number[1,0,0]')
 def test_string(self):self.assertEqual(infer_type('arcane').kind,ValueKind.STRING)
 def test_homogeneous_list(self):self.assertEqual(infer_type([1,2]).describe(),'list[number]')
 def test_empty_list(self):self.assertEqual(infer_type([]).describe(),'list[unknown]')
 def test_heterogeneous_list(self):self.assertEqual(infer_type([1,'x']).describe(),'list[unknown]')
 def test_function(self):self.assertEqual(infer_type(lambda x:x).kind,ValueKind.FUNCTION)
 def test_unknown_object(self):self.assertEqual(infer_type(object()).kind,ValueKind.UNKNOWN)
 def test_typed_value(self):
  v=TypedValue(7,ValueType(ValueKind.NUMBER));self.assertEqual(v.value,7);self.assertEqual(v.type.kind,ValueKind.NUMBER)

if __name__=='__main__':unittest.main(verbosity=2)
