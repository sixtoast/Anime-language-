"""Phase 7U: minimal executable Arcane subset. Grammar is provisional."""
from __future__ import annotations
from dataclasses import dataclass
import re
from typing import Any

@dataclass(frozen=True)
class Diagnostic:
    code: str
    message: str
    line: int = 1
    hint: str = ""
    def render(self, filename="<source>"):
        return f"{filename}:{self.line}: error {self.code}: {self.message}" + (f" Hint: {self.hint}" if self.hint else "")

class ArcaneFailure(Exception):
    def __init__(self, code, message, line=1, hint=""):
        super().__init__(message); self.code=code; self.message=message; self.line=line; self.hint=hint
    def diagnostic(self): return Diagnostic(self.code,self.message,self.line,self.hint)

TOKEN = re.compile(r"\s*(\$[A-Za-z_][A-Za-z0-9_]*|(?:\d+\.\d+|\d+)|[A-Za-z_][A-Za-z0-9_]*|==|!=|<=|>=|[()+\-*/%,<>])")
PREFIX = {'FRATA':lambda a,b:a*b, 'FRAPA':lambda a,b:a+b, 'FRAMO':lambda a,b:a-b, 'FRADI':lambda a,b:a/b, 'FRAGT':lambda a,b:a>b, 'FRALT':lambda a,b:a<b, 'FRAEQ':lambda a,b:a==b, 'FRANE':lambda a,b:a!=b, 'FRAGE':lambda a,b:a>=b, 'FRALE':lambda a,b:a<=b}
PREC={'==':1,'!=':1,'<':1,'>':1,'<=':1,'>=':1,'+':2,'-':2,'*':3,'/':3,'%':3}

def tokens(src,line):
    out=[]; p=0
    while p<len(src):
        m=TOKEN.match(src,p)
        if not m:
            if src[p:].strip()=='' : break
            raise ArcaneFailure('ARC-EXPR-001',f"unexpected character {src[p]!r}",line)
        out.append(m.group(1)); p=m.end()
    if not out: raise ArcaneFailure('ARC-EXPR-001','empty expression',line)
    return out

class Expr:
    def __init__(self,ts,scope,functions,line): self.ts=ts; self.i=0; self.scope=scope; self.functions=functions; self.line=line
    def peek(self): return self.ts[self.i] if self.i<len(self.ts) else None
    def take(self):
        t=self.peek()
        if t is None: raise ArcaneFailure('ARC-EXPR-001','unexpected end of expression',self.line)
        self.i+=1; return t
    def parse(self,minp=0):
        t=self.take()
        if t=='(':
            v=self.parse()
            if self.take()!=')': raise ArcaneFailure('ARC-EXPR-001',"expected ')'",self.line)
        elif t in ('+','-'):
            v=self.parse(4); v=+v if t=='+' else -v
        elif t.startswith('$'):
            name=t[1:]
            try: v=self.scope[name]
            except KeyError: raise ArcaneFailure('ARC-SEM-005',f"unresolved binding '${name}'",self.line,"Declare it before use in the current scope or an enclosing scope.")
        elif re.fullmatch(r'\d+(?:\.\d+)?',t): v=float(t) if '.' in t else int(t)
        elif re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*',t):
            if t in PREFIX:
                a=self.parse(4); b=self.parse(4); v=PREFIX[t](a,b)
            elif self.peek()=='(':
                self.take(); args=[]
                if self.peek()!=')':
                    args.append(self.parse())
                    while self.peek()==',': self.take(); args.append(self.parse())
                if self.take()!=')': raise ArcaneFailure('ARC-EXPR-001',"expected ')' after arguments",self.line)
                if t not in self.functions: raise ArcaneFailure('ARC-SEM-006',f"undefined function '{t}'",self.line)
                fn=self.functions[t]
                if len(args)!=len(fn[0]): raise ArcaneFailure('ARC-SEM-007',f"function '{t}' expects {len(fn[0])} argument(s), got {len(args)}",self.line)
                local=dict(zip(fn[0],args)); v=self.eval_function(fn[1],local,t)
            else: raise ArcaneFailure('ARC-EXPR-002',f"bare name '{t}' is not a value",self.line,"Use $binding or a function call.")
        else: raise ArcaneFailure('ARC-EXPR-001',f"unexpected token {t!r}",self.line)
        while self.peek() in PREC and PREC[self.peek()]>=minp:
            op=self.take(); rhs=self.parse(PREC[op]+1)
            try:
                if op=='+': v=v+rhs
                elif op=='-': v=v-rhs
                elif op=='*': v=v*rhs
                elif op=='/': v=v/rhs
                elif op=='%': v=v%rhs
                elif op=='==': v=v==rhs
                elif op=='!=': v=v!=rhs
                elif op=='<': v=v<rhs
                elif op=='>': v=v>rhs
                elif op=='<=': v=v<=rhs
                elif op=='>=': v=v>=rhs
            except (TypeError,ZeroDivisionError) as e: raise ArcaneFailure('ARC-RUN-001',f"operator {op!r} failed: {e}",self.line)
        return v
    def eval_function(self,body,local,name):
        # Function body expression uses a fresh scope containing its parameters.
        return evaluate(body,local,self.functions,self.line)

def evaluate(src,scope,functions,line):
    ts=tokens(src,line); p=Expr(ts,scope,functions,line); value=p.parse()
    if p.peek() is not None: raise ArcaneFailure('ARC-EXPR-001',f"unexpected token {p.peek()!r}",line)
    return value

class ArcaneRuntime:
    def __init__(self): self.globals={}; self.functions={}; self.output=[]
    def run_program(self,source):
        # Parse all block structure before running any statements.
        lines=[(n,raw.strip()) for n,raw in enumerate(source.splitlines(),1) if raw.strip() and not raw.strip().startswith('#')]
        def parse_seq(i,stops=()):
            nodes=[]
            while i<len(lines):
                n,s=lines[i]
                if s in stops: return nodes,i,s
                m=re.fullmatch(r'KWAI\s+(.+?)\s+THEN',s)
                if m:
                    yes,i,stop=parse_seq(i+1,('ELSE','END'))
                    if stop=='ELSE': no,i,stop=parse_seq(i+1,('END',))
                    else: no=[]
                    if stop!='END': raise ArcaneFailure('ARC-PARSE-001','conditional block missing END',n)
                    nodes.append(('if',n,m.group(1),yes,no)); i+=1; continue
                if s in ('ELSE','END'): raise ArcaneFailure('ARC-PARSE-002',f'unexpected {s}',n)
                if s.startswith('KWAI '): raise ArcaneFailure('ARC-PARSE-003','malformed conditional header; expected KWAI condition THEN',n)
                nodes.append(('stmt',n,s)); i+=1
            return nodes,i,None
        try:
            ast,i,stop=parse_seq(0)
            if stop: raise ArcaneFailure('ARC-PARSE-002',f'unexpected {stop}')
            self.output=[]; self._exec(ast,self.globals)
            return list(self.output)
        except ArcaneFailure as e: return e.diagnostic()
    def _exec(self,nodes,scope):
        for node in nodes:
            if node[0]=='if':
                _,line,condition,yes,no=node
                truth=evaluate(condition,scope,self.functions,line)
                branch=yes if truth else no
                self._exec(branch,dict(scope))
                continue
            _,line,s=node
            fm=re.fullmatch(r'KWAF\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(([^()]*)\)\s*=>\s*(.+)',s)
            if fm:
                name,raw,body=fm.groups(); params=tuple(x.strip().lstrip('$') for x in raw.split(',') if x.strip())
                if len(set(params))!=len(params): raise ArcaneFailure('ARC-SEM-002',f'duplicate parameter in function {name}',line)
                if name in self.functions: raise ArcaneFailure('ARC-SEM-003',f"function '{name}' defined more than once",line)
                self.functions[name]=(params,body); continue
            bm=re.fullmatch(r'KWAM\s+([A-Za-z_][A-Za-z0-9_]*)\s*=>\s*(.+)',s)
            if bm:
                name,expr=bm.groups()
                if name in scope: raise ArcaneFailure('ARC-SEM-004',f"binding '{name}' already exists in this scope",line)
                scope[name]=evaluate(expr,scope,self.functions,line); continue
            om=re.fullmatch(r'KWAT\s+([A-Za-z_][A-Za-z0-9_]*)',s)
            if om:
                name=om.group(1)
                if name not in scope: raise ArcaneFailure('ARC-SEM-005',f"unresolved binding '{name}'",line)
                self.output.append(scope[name]); continue
            raise ArcaneFailure('ARC-PARSE-004',f"unsupported statement: {s}",line,"Supported: KWAM, KWAF, KWAT and structured KWAI blocks.")
