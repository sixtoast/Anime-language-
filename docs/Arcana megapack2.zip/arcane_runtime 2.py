"""Arcane Phase 7A: provisional typed quantities + bindings runtime.

Binding syntax here is an implementation profile, not a canon change:
  KWAM name = expression   create an immutable value binding
  KWAT name                reference a binding
  KWAK name = expression   create a live expression binding, reevaluated on read
Expression literals: 3, 2.5, 3@m, 30@cm, 2@s, ZA..PE
Arithmetic operators: FRAPA, FRATA, FRAKA, FRALA (binary prefix forms)
"""
from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
import re

class ArcaneError(ValueError): pass
class ArcaneParseError(ArcaneError): pass
class ArcaneTypeError(ArcaneError): pass
class ArcaneEvaluationError(ArcaneError): pass
class ArcaneBindingError(ArcaneError): pass

DIMENSIONLESS=(0,0,0)
UNITS={"1":(Decimal(1),DIMENSIONLESS),"m":(Decimal(1),(1,0,0)),"cm":(Decimal('.01'),(1,0,0)),"km":(Decimal(1000),(1,0,0)),"s":(Decimal(1),(0,1,0)),"min":(Decimal(60),(0,1,0)),"h":(Decimal(3600),(0,1,0)),"kg":(Decimal(1),(0,0,1)),"g":(Decimal('.001'),(0,0,1))}
DIGITS={"ZA":0,"KI":1,"TO":2,"MU":3,"RE":4,"SA":5,"FI":6,"DU":7,"GO":8,"PE":9}
ARITY={"FRAPA":2,"FRATA":2,"FRAKA":2,"FRALA":2}
_NUM_UNIT=re.compile(r"^([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)(?:@([A-Za-z0-9]+))?$")
_NAME=re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

@dataclass(frozen=True)
class Quantity:
    value: Decimal
    dimension: tuple[int,int,int]
@dataclass(frozen=True)
class Literal:
    quantity: Quantity
@dataclass(frozen=True)
class Reference:
    name: str
@dataclass(frozen=True)
class Call:
    op: str
    args: tuple['Expr',...]
Expr=Literal|Reference|Call

def _adddim(a,b): return tuple(x+y for x,y in zip(a,b))
def _subdim(a,b): return tuple(x-y for x,y in zip(a,b))
def _literal(token):
    if token in DIGITS: return Literal(Quantity(Decimal(DIGITS[token]),DIMENSIONLESS))
    m=_NUM_UNIT.fullmatch(token)
    if not m: return None
    raw,unit=m.groups(); unit=unit or '1'
    if unit not in UNITS: raise ArcaneTypeError(f"unknown unit {unit!r}")
    try: val=Decimal(raw)
    except InvalidOperation as e: raise ArcaneParseError(f"invalid number {token!r}") from e
    scale,dim=UNITS[unit]
    return Literal(Quantity(val*scale,dim))

class _Parser:
    def __init__(self,tokens): self.tokens=tokens; self.i=0
    def expr(self):
        if self.i>=len(self.tokens): raise ArcaneParseError('unexpected end; expected operand')
        tok=self.tokens[self.i]; self.i+=1
        lit=_literal(tok)
        if lit is not None: return lit
        if tok.startswith('$') and _NAME.fullmatch(tok[1:]): return Reference(tok[1:])
        if tok in ARITY: return Call(tok,tuple(self.expr() for _ in range(ARITY[tok])))
        raise ArcaneParseError(f"unknown form or malformed literal {tok!r}")

def parse(source):
    if not isinstance(source,str) or not source.strip(): raise ArcaneParseError('expression must not be empty')
    p=_Parser(source.split()); tree=p.expr()
    if p.i!=len(p.tokens): raise ArcaneParseError('extra tokens: '+' '.join(p.tokens[p.i:]))
    return tree

@dataclass
class Binding:
    kind: str
    expression: Expr|None=None
    value: Quantity|None=None

class Environment:
    def __init__(self): self._bindings={}; self._resolving=[]
    def create_value(self,name,expression):
        self._validate_name(name); key=name.casefold()
        if key in self._bindings: raise ArcaneBindingError(f"binding {name!r} already exists")
        tree=parse(expression); value=self.evaluate_expr(tree)
        self._bindings[key]=Binding('value',value=value)
        return value
    def create_live(self,name,expression):
        self._validate_name(name); key=name.casefold()
        if key in self._bindings: raise ArcaneBindingError(f"binding {name!r} already exists")
        tree=parse(expression)
        # Validate references and type semantics now, but do not store evaluated result.
        self.evaluate_expr(tree)
        self._bindings[key]=Binding('live',expression=tree)
        return self.resolve(name)
    def _validate_name(self,name):
        if not isinstance(name,str) or not _NAME.fullmatch(name): raise ArcaneBindingError(f"invalid binding name {name!r}")
    def resolve(self,name):
        key=name.casefold()
        if key not in self._bindings: raise ArcaneBindingError(f"unknown binding {name!r}")
        if key in self._resolving: raise ArcaneBindingError('cyclic live binding: '+' -> '.join(self._resolving+[key]))
        b=self._bindings[key]
        if b.kind=='value': return b.value
        self._resolving.append(key)
        try: return self.evaluate_expr(b.expression)
        finally: self._resolving.pop()
    def evaluate_expr(self,tree):
        if isinstance(tree,Literal): return tree.quantity
        if isinstance(tree,Reference): return self.resolve(tree.name)
        a,b=(self.evaluate_expr(x) for x in tree.args)
        if tree.op in ('FRAPA','FRATA') and a.dimension!=b.dimension:
            raise ArcaneTypeError(f"{tree.op} requires matching dimensions; got {a.dimension} and {b.dimension}")
        if tree.op=='FRAPA': return Quantity(a.value+b.value,a.dimension)
        if tree.op=='FRATA': return Quantity(a.value-b.value,a.dimension)
        if tree.op=='FRAKA': return Quantity(a.value*b.value,_adddim(a.dimension,b.dimension))
        if tree.op=='FRALA':
            if b.value==0: raise ArcaneEvaluationError('FRALA: division by zero')
            return Quantity(a.value/b.value,_subdim(a.dimension,b.dimension))
        raise ArcaneParseError(f"unsupported operator {tree.op}")
    def execute(self,statement):
        """Execute one statement in provisional command syntax."""
        s=statement.strip()
        m=re.fullmatch(r'KWAM\s+([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+)',s,re.I)
        if m: return self.create_value(m.group(1),m.group(2))
        m=re.fullmatch(r'KWAK\s+([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.+)',s,re.I)
        if m: return self.create_live(m.group(1),m.group(2))
        m=re.fullmatch(r'KWAT\s+([A-Za-z_][A-Za-z0-9_]*)',s,re.I)
        if m: return self.resolve(m.group(1))
        raise ArcaneParseError('expected KWAM name = expression, KWAK name = expression, or KWAT name')

def format_quantity(q):
    v=format(q.value.normalize(),'f') if q.value else '0'; l,t,m=q.dimension
    if (l,t,m)==DIMENSIONLESS: unit='1'
    else:
        bits=[]
        for symbol,power in [('m',l),('s',t),('kg',m)]:
            if power: bits.append(symbol if power==1 else f'{symbol}^{power}')
        unit=' '.join(bits)
    return f'{v} {unit}'

if __name__=='__main__':
    import argparse
    cli=argparse.ArgumentParser(description='Arcane provisional typed bindings runtime')
    cli.add_argument('statement',nargs='+'); ns=cli.parse_args(); env=Environment()
    try: print(format_quantity(env.execute(' '.join(ns.statement))))
    except ArcaneError as exc: raise SystemExit(f'Arcane error: {exc}')
