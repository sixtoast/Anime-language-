"""Static syntax checker for the provisional, line-oriented Arcane subset.

This checker validates block structure and recognises known statement shapes.
It deliberately does not execute programs or claim to be the canonical grammar.
"""
from __future__ import annotations
from dataclasses import dataclass
import re
from pathlib import Path
from arcane_expr import validate_expression, ExpressionSyntaxError

@dataclass(frozen=True)
class Issue:
    code: str
    message: str
    line: int
    hint: str = ""
    def render(self, filename: str = "<source>") -> str:
        suffix = f" Hint: {self.hint}" if self.hint else ""
        return f"{filename}:{self.line}: error {self.code}: {self.message}{suffix}"

@dataclass(frozen=True)
class Report:
    filename: str
    lines_checked: int
    issues: tuple[Issue, ...]
    @property
    def ok(self) -> bool: return not self.issues
    def render(self) -> str:
        if self.ok: return f"{self.filename}: syntax OK ({self.lines_checked} non-blank, non-comment lines checked)"
        return "\n".join(i.render(self.filename) for i in self.issues)

NAME = r"[A-Za-z_][A-Za-z0-9_]*"
# These forms are intentionally provisional and based on the reconstructed subset.
STATEMENT_PATTERNS = [
    re.compile(rf"KWAM\s+{NAME}\s*=>\s*.+"),
    re.compile(rf"KWAT\s+{NAME}"),
    re.compile(rf"KWAF\s+{NAME}\s*\([^()]*\)\s*=>\s*.+"),
    re.compile(r"KWAR\s+.+\s+FROM\s+.+\s+TO\s+.+\s+=>\s*.+"),
    re.compile(r"KWAS\s+.+\s+FROM\s+.+\s+TO\s+.+\s+=>\s*.+"),
    re.compile(r"KWAI\s+.+\s+THEN\s+.+\s+ELSE\s+.+"),
]

def check_source(source: str, filename: str = "<source>") -> Report:
    issues: list[Issue] = []
    stack: list[tuple[int, bool]] = []  # header line, has ELSE
    checked = 0
    for lineno, raw in enumerate(source.splitlines(), 1):
        text = raw.strip()
        if not text or text.startswith("#"):
            continue
        checked += 1
        if text.startswith("KWAI ") and text.endswith(" THEN"):
            condition = text[5:-5].strip()
            if not condition:
                issues.append(Issue("ARC-PARSE-001", "conditional condition is empty", lineno, "Add a condition before THEN."))
            else:
                try: validate_expression(condition)
                except ExpressionSyntaxError as exc: issues.append(Issue("ARC-EXPR-001", str(exc), lineno, "Check operators, operands, and parentheses."))
            stack.append((lineno, False)); continue
        if text == "ELSE":
            if not stack:
                issues.append(Issue("ARC-PARSE-002", "ELSE without an open conditional", lineno, "Add a matching KWAI ... THEN block."))
            elif stack[-1][1]:
                issues.append(Issue("ARC-PARSE-003", "duplicate ELSE in conditional", lineno, "Each conditional can have at most one ELSE."))
            else:
                header, _ = stack[-1]; stack[-1] = (header, True)
            continue
        if text == "END":
            if not stack: issues.append(Issue("ARC-PARSE-004", "END without an open block", lineno, "Remove END or add the matching conditional header."))
            else: stack.pop()
            continue
        if text.startswith("KWAI "):
            issues.append(Issue("ARC-PARSE-005", "malformed conditional header", lineno, "Block form: KWAI condition THEN on its own line.")); continue
        if text.startswith(("ELSE ", "END ")):
            issues.append(Issue("ARC-PARSE-006", "block delimiter must appear alone on its line", lineno)); continue
        matched = next((pattern for pattern in STATEMENT_PATTERNS if pattern.fullmatch(text)), None)
        if matched:
            rhs = None
            if text.startswith("KWAM "): rhs = text.split("=>", 1)[1].strip()
            elif text.startswith("KWAF "): rhs = text.split("=>", 1)[1].strip()
            elif text.startswith("KWAT "): rhs = "$" + text.split(None, 1)[1].strip()
            elif text.startswith(("KWAR ", "KWAS ")): rhs = text.split("=>", 1)[1].strip()
            elif text.startswith("KWAI "):
                inline = re.fullmatch(r"KWAI\s+(.+?)\s+THEN\s+(.+?)\s+ELSE\s+(.+)", text)
                if inline:
                    for expression in inline.groups():
                        try: validate_expression(expression)
                        except ExpressionSyntaxError as exc: issues.append(Issue("ARC-EXPR-001", str(exc), lineno, "Check operators, operands, and parentheses."))
            if rhs is not None:
                try: validate_expression(rhs)
                except ExpressionSyntaxError as exc: issues.append(Issue("ARC-EXPR-001", str(exc), lineno, "Check operators, operands, and parentheses."))
            continue
        if not any(pattern.fullmatch(text) for pattern in STATEMENT_PATTERNS):
            # Inline conditional and ordinary expressions are recognised as expression-like
            # only when they don't resemble a misspelled statement keyword.
            if re.match(r"^KW[A-Z]+\b", text):
                issues.append(Issue("ARC-PARSE-007", "unrecognised or malformed statement", lineno, "Check the keyword and required separators; syntax is provisional."))
            elif not text.startswith("$") and not re.fullmatch(rf"{NAME}\s*\(.*\)|[-+]?\d+(?:\.\d+)?", text):
                issues.append(Issue("ARC-PARSE-008", "unrecognised expression or statement shape", lineno, "Use a supported statement, function call, binding reference or numeric literal."))
    for header_line, has_else in reversed(stack):
        issues.append(Issue("ARC-PARSE-009", "conditional block is missing END", header_line, "Close the block with END."))
    issues.sort(key=lambda issue: issue.line)
    return Report(filename, checked, tuple(issues))

def check_file(path: str | Path) -> Report:
    p = Path(path)
    try: source = p.read_text(encoding="utf-8")
    except OSError as exc: return Report(str(p), 0, (Issue("ARC-IO-001", f"cannot read file: {exc}", 1),))
    return check_source(source, str(p))
