import unittest
from arcane_diagnostics import ErrorCode, SourceSpan, Diagnostic, ArcaneDiagnosticError, ValueKind
from arcane_runtime_adapter import evaluate_safely, require_success

class RuntimeAdapterTests(unittest.TestCase):
    def test_success_wraps_number(self):
        result = evaluate_safely(lambda: 12)
        self.assertTrue(result.ok)
        self.assertEqual(result.typed_value.type.kind, ValueKind.NUMBER)
        self.assertEqual(result.typed_value.value, 12)

    def test_success_preserves_dimension_metadata(self):
        result = evaluate_safely(lambda: 2.5, dimensions=(1, 0, -1))
        self.assertEqual(result.typed_value.type.dimensions, (1, 0, -1))

    def test_bool_is_not_number(self):
        self.assertEqual(evaluate_safely(lambda: True).typed_value.type.kind, ValueKind.BOOLEAN)

    def test_list_typed(self):
        self.assertEqual(evaluate_safely(lambda: [1, 2]).typed_value.type.describe(), 'list[number]')

    def test_unknown_name_maps_with_source_location(self):
        result = evaluate_safely(lambda: (_ for _ in ()).throw(NameError('unknown name: x')), SourceSpan(4, 7))
        self.assertFalse(result.ok)
        self.assertEqual(result.diagnostic.code, ErrorCode.UNKNOWN_NAME)
        self.assertIn('4:7', result.render())

    def test_zero_division_maps(self):
        result = evaluate_safely(lambda: 1 / 0)
        self.assertEqual(result.diagnostic.code, ErrorCode.DIVISION_BY_ZERO)
        self.assertIn('hint:', result.render())

    def test_existing_diagnostic_is_preserved(self):
        diagnostic = Diagnostic(ErrorCode.PARSE_ERROR, 'bad expression', SourceSpan(2, 3), 'check syntax')
        result = evaluate_safely(lambda: (_ for _ in ()).throw(ArcaneDiagnosticError(diagnostic)))
        self.assertEqual(result.diagnostic, diagnostic)

    def test_unexpected_exception_is_sanitised(self):
        result = evaluate_safely(lambda: (_ for _ in ()).throw(RuntimeError('opaque runtime failure')))
        self.assertEqual(result.diagnostic.code, ErrorCode.INTERNAL_ERROR)
        self.assertNotIn('Traceback', result.render())

    def test_require_success_returns_value(self):
        typed = require_success(evaluate_safely(lambda: 'hello'))
        self.assertEqual(typed.value, 'hello')

    def test_require_success_raises_structured_error(self):
        result = evaluate_safely(lambda: 1 / 0)
        with self.assertRaises(ArcaneDiagnosticError) as ctx:
            require_success(result)
        self.assertEqual(ctx.exception.diagnostic.code, ErrorCode.DIVISION_BY_ZERO)

if __name__ == '__main__':
    unittest.main()
