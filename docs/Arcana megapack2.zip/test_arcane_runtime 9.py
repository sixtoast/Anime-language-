import unittest
from arcane_runtime import Environment,fmt,ArcaneTypeError,ArcaneBindingError,ArcaneEvaluationError,ArcaneParseError
class BoundedRepeatTests(unittest.TestCase):
 def setUp(self):self.e=Environment()
 def test_inclusive_range(self):self.assertEqual(fmt(self.e.execute('KWAR i FROM 1 TO 3 => $i')),'[1 1, 2 1, 3 1]')
 def test_single_iteration(self):self.assertEqual(fmt(self.e.execute('KWAR i FROM 4 TO 4 => FRAKA $i 2')),'[8 1]')
 def test_empty_range(self):self.assertEqual(fmt(self.e.execute('KWAR i FROM 4 TO 2 => $i')),'[]')
 def test_negative_range(self):self.assertEqual(fmt(self.e.execute('KWAR i FROM -2 TO 0 => $i')),'[-2 1, -1 1, 0 1]')
 def test_body_arithmetic(self):self.assertEqual(fmt(self.e.execute('KWAR i FROM 1 TO 3 => FRAKA $i $i')),'[1 1, 4 1, 9 1]')
 def test_body_function(self):
  self.e.execute('KWAF double(x) => FRAKA $x 2');self.assertEqual(fmt(self.e.execute('KWAR i FROM 1 TO 3 => double($i)')),'[2 1, 4 1, 6 1]')
 def test_body_logic(self):self.assertEqual(fmt(self.e.execute('KWAR i FROM 1 TO 3 => FRAGT $i 1')),'[0 1, 1 1, 1 1]')
 def test_dimensioned_bounds_rejected(self):
  with self.assertRaises(ArcaneTypeError):self.e.execute('KWAR i FROM 1@m TO 3 => $i')
 def test_fractional_bounds_rejected(self):
  with self.assertRaises(ArcaneTypeError):self.e.execute('KWAR i FROM 1.5 TO 3 => $i')
 def test_excessive_iterations_rejected(self):
  with self.assertRaises(ArcaneEvaluationError):self.e.execute('KWAR i FROM 1 TO 1001 => $i')
 def test_loop_variable_does_not_leak(self):
  self.e.execute('KWAR i FROM 1 TO 2 => $i')
  with self.assertRaises(ArcaneBindingError):self.e.execute('KWAT i')
 def test_outer_binding_survives(self):
  self.e.execute('KWAM i = 99');self.e.execute('KWAR i FROM 1 TO 2 => $i');self.assertEqual(fmt(self.e.execute('KWAT i')),'99 1')
 def test_bounds_evaluated_in_outer_scope(self):
  self.e.execute('KWAM start = 2');self.e.execute('KWAM finish = 3');self.assertEqual(fmt(self.e.execute('KWAR i FROM $start TO $finish => $i')),'[2 1, 3 1]')
 def test_error_cleans_loop_scope(self):
  with self.assertRaises(ArcaneBindingError):self.e.execute('KWAR i FROM 1 TO 2 => $missing')
  self.assertEqual(len(self.e.scopes),1)
 def test_case_insensitive_keyword(self):self.assertEqual(fmt(self.e.execute('kwar i from 1 to 2 => $i')),'[1 1, 2 1]')
 def test_non_numeric_result_is_not_claimed(self):
  with self.assertRaises(ArcaneBindingError):self.e.execute('KWAR i FROM 1 TO 2 => $missing')
class RegressionTests(unittest.TestCase):
 def setUp(self):self.e=Environment()
 def test_nested_function_composition(self):
  self.e.execute('KWAF inc(x) => FRAPA $x 1');self.e.execute('KWAF double(x) => FRAKA $x 2');self.assertEqual(fmt(self.e.execute('double(inc(3))')),'8 1')
 def test_and_short_circuit(self):self.assertEqual(fmt(self.e.execute('FRAND 0 FRALA 1 0')),'0 1')
 def test_or_short_circuit(self):self.assertEqual(fmt(self.e.execute('FROR 1 FRALA 1 0')),'1 1')
 def test_conditional_lazy(self):self.assertEqual(fmt(self.e.execute('FRASI 1 4 $missing')),'4 1')
 def test_unit_arithmetic(self):self.assertEqual(fmt(self.e.execute('FRAPA 2@m 3@m')),'5 m')
 def test_division_zero(self):
  with self.assertRaises(ArcaneEvaluationError):self.e.execute('FRALA 1 0')
 def test_dimension_mismatch(self):
  with self.assertRaises(ArcaneTypeError):self.e.execute('FRAGT 1@m 1@s')
 def test_unknown_binding(self):
  with self.assertRaises(ArcaneBindingError):self.e.execute('$missing')
if __name__=='__main__':unittest.main(verbosity=2)

class AggregationTests(unittest.TestCase):
 def setUp(self):self.e=Environment()
 def test_sum_repeated_squares(self):
  self.assertEqual(fmt(self.e.execute('KWAS total FROM 1 TO 5 => FRAKA $total $total')),'55 1')
  self.assertEqual(fmt(self.e.execute('KWAT total')),'55 1')
 def test_sum_simple_range(self):self.assertEqual(fmt(self.e.execute('KWAS total FROM 1 TO 4 => $total')),'10 1')
 def test_sum_empty_range_is_zero(self):self.assertEqual(fmt(self.e.execute('KWAS total FROM 4 TO 2 => $total')),'0 1')
 def test_sum_single_value(self):self.assertEqual(fmt(self.e.execute('KWAS total FROM 7 TO 7 => FRAKA $total 3')),'21 1')
 def test_sum_decimal_body(self):self.assertEqual(fmt(self.e.execute('KWAS total FROM 1 TO 3 => FRALA $total 2')),'3 1')
 def test_sum_dimensioned_body(self):self.assertEqual(fmt(self.e.execute('KWAS distance FROM 1 TO 3 => FRAKA $distance 1@m')),'6 m')
 def test_sum_preserves_dimensions(self):self.assertEqual(fmt(self.e.execute('KWAS distance FROM 1 TO 2 => FRAPA 2@m 3@m')),'10 m')
 def test_sum_result_can_be_used(self):
  self.e.execute('KWAS total FROM 1 TO 3 => $total')
  self.assertEqual(fmt(self.e.execute('FRAKA $total 2')),'12 1')
 def test_duplicate_sum_binding_rejected(self):
  self.e.execute('KWAM total = 2')
  with self.assertRaises(ArcaneBindingError):self.e.execute('KWAS total FROM 1 TO 2 => $total')
 def test_sum_scope_cleanup_on_error(self):
  with self.assertRaises(ArcaneBindingError):self.e.execute('KWAS total FROM 1 TO 2 => $missing')
  self.assertEqual(len(self.e.scopes),1)
 def test_sum_does_not_leak_iteration_variable(self):
  self.e.execute('KWAS total FROM 1 TO 2 => $total')
  with self.assertRaises(ArcaneBindingError):self.e.lookup('i')
 def test_sum_function_body(self):
  self.e.execute('KWAF double(x) => FRAKA $x 2')
  self.assertEqual(fmt(self.e.execute('KWAS total FROM 1 TO 3 => double($total)')),'12 1')
 def test_sum_excessive_repeat_rejected(self):
  with self.assertRaises(ArcaneEvaluationError):self.e.execute('KWAS total FROM 1 TO 1001 => $total')
 def test_sum_bounds_must_be_integers(self):
  with self.assertRaises(ArcaneTypeError):self.e.execute('KWAS total FROM 1.5 TO 3 => $total')
 def test_sum_dimensioned_bounds_rejected(self):
  with self.assertRaises(ArcaneTypeError):self.e.execute('KWAS total FROM 1@m TO 3 => $total')
 def test_sum_case_insensitive(self):self.assertEqual(fmt(self.e.execute('kwas total from 1 to 3 => $total')),'6 1')
