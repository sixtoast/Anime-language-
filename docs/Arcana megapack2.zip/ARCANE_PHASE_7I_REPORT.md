# Arcane Phase 7I — Bounded Aggregation

## Outcome

Phase 7I adds a usable aggregation operation to the reconstructed Phase 7H runtime. `KWAS` evaluates a numeric expression over an inclusive bounded integer range and sums the results into a named binding. The existing `KWAR` list-producing operation remains available. The full regression suite passes **40/40 tests**.

## Provisional syntax

```arcane
KWAS total FROM 1 TO 5 => FRAKA $total $total
KWAT total
```

The first line sums the squares 1² + 2² + 3² + 4² + 5² and binds `total` to `55 1`.

This spelling is an implementation convenience, not approved canonical Arcane vocabulary. It must be reconciled with the authoritative decision ledger and lexicon before canonisation.

## Semantics and safeguards

- Bounds are evaluated once in the surrounding scope, must be dimensionless integers, and are inclusive.
- The existing 1,000-iteration cap is enforced before evaluation.
- Each iteration uses an isolated scope, cleaned up even if evaluation fails.
- The expression must return numeric quantities. All results must have matching dimensions.
- The sum preserves the common dimension: summing metres returns metres.
- An empty range returns dimensionless zero (`0 1`). This is an explicit provisional convention; it cannot infer the dimension of a body that was never evaluated.
- The final sum is stored under the requested binding name. Duplicate bindings in the current scope are rejected.
- Existing `KWAR`, arithmetic, functions, logic, units and error behaviour remain covered by regression tests.

## Verification

Command: `python -m unittest -v`

Result: **40 tests passed** — 24 existing tests plus 16 aggregation tests. Coverage includes empty/single/multi-item ranges, sums of squares, function bodies, decimal results, dimension preservation, bounds validation, iteration caps, case-insensitivity, duplicate binding rejection and scope cleanup.

## Scope and limitations

This is a small reconstructed executable subset, not the full Arcane compiler or a claim that the grammar is canon. The current numeric model has three base dimensions and a limited unit/operator set. Empty aggregation currently returns dimensionless zero. General list literals, arbitrary collection reductions, mutable accumulators, and multi-statement blocks are not implemented.

## Next build step

Phase 7J should make the runtime easier to use and verify: add explicit value/result typing and stable error reporting, while checking all new syntax against the decision ledger before treating any spelling as canonical. Avoid reopening completed phases unless a concrete regression is found.
