"""Arcane static checker CLI: syntax and provisional semantic validation; never executes."""
import argparse
from arcane_check import check_file
from arcane_semantic import analyze_file

def main():
    parser = argparse.ArgumentParser(description="Check syntax and semantics in the provisional Arcane subset")
    parser.add_argument("file", help="Arcane source file (.arc)")
    parser.add_argument("--syntax-only", action="store_true", help="run syntax checks only")
    parser.add_argument("--semantic-only", action="store_true", help="run semantic checks only (syntax should already be valid)")
    args = parser.parse_args()
    if args.syntax_only and args.semantic_only:
        parser.error("--syntax-only and --semantic-only cannot be used together")
    reports = []
    if not args.semantic_only:
        reports.append(check_file(args.file))
    if not args.syntax_only:
        reports.append(analyze_file(args.file))
    for report in reports:
        print(report.render())
    raise SystemExit(0 if all(report.ok for report in reports) else 1)

if __name__ == "__main__": main()
