ARCANE PHASE 7B — MUTABLE STATE AND SCOPES

Contents:
- arcane_runtime.py: runnable provisional runtime
- test_arcane_runtime.py: 15 focused tests
- ARCANE_PHASE_7B_REPORT.md: implementation summary and boundaries
- PHASE_7B_STATUS.csv: acceptance register
- PHASE_7B_TEST_OUTPUT.txt: actual test output

Run tests (Python 3.10+, standard library only):
python -m unittest -v test_arcane_runtime.py

This is a provisional implementation profile, not a canonical grammar change.
