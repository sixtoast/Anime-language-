# Arcane Phase 7N — User-Defined Functions

## Delivered

Phase 7N adds user-defined functions to the compact runnable Arcane subset. Functions have named parameters, local parameter bindings, return the value of their expression body, can call other functions, and support recursive calls guarded by a configurable maximum call depth.

Provisional syntax:

```text
KWAF square(x) => FRATA $x $x
square(4)
KWAF add(x, y) => FRAPA $x $y
add(4, 5)
```

Function parameters are local to a call and do not create global bindings. The runtime checks arity, duplicate function names, duplicate parameters, unknown names during evaluation, dimensional operations, and call-depth limits. Functions can be used in bounded repetition and aggregation expressions.

## Verification

`python -m unittest -v`: **21 tests passed**. Tests cover function declaration/calls, multiple parameters, nesting, local scope, wrong arity, duplicate declarations/parameters, units, recursion limits, integration with repetition and aggregation, diagnostics, and short-circuit logic.

## Limits and honesty

This is still a small executable subset, not a complete Arcane implementation. `KWAF` and call syntax are provisional implementation choices, not canonised language grammar. Function bodies are validated when called rather than fully type-checked at declaration. The active workspace only contained the supplied historical Arcana pack; the earlier Phase 7M runtime archive was not present, so this package is a consolidated reconstruction based on the implemented subset described in the project conversation, not a claim of exact source recovery. The supplied draft lexicon is included as a reference, not treated as proof that provisional syntax is approved.

## Run

```bash
python arcane_cli.py
python -m unittest -v
```
