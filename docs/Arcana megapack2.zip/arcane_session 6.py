"""Interactive shell for the Phase 7H provisional Arcane runtime."""
import copy
from arcane_runtime import Environment,fmt

def main():
 e=Environment();print('Arcane Phase 7H provisional runtime. :help for help, :quit to exit.')
 while True:
  try:s=input('arcane> ').strip()
  except EOFError:print();break
  if s.casefold() in (':quit',':exit'):break
  if s.casefold()==':help':
   print('KWAM name = expression | KWAF name(params) => expression | KWAC name(args) | KWAT name | KWAR i FROM start TO end => expression | FRASI/FRAGT/FRALT/FRAEQ | FRAND/FROR/FRNOT | :quit');continue
  if not s:continue
  snap=copy.deepcopy((e.scopes,e.functions))
  try:
   v=e.execute(s);print(fmt(v) if isinstance(v,list) or hasattr(v,'dim') else v)
  except Exception as ex:
   e.scopes,e.functions=snap;print(f'Error: {type(ex).__name__}: {ex}')
if __name__=='__main__':main()
