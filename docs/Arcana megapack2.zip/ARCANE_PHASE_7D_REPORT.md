# Arcane Phase 7D — Typed Functions and Reusable Computation

## Delivered
This implementation adds reusable named functions to the existing provisional runtime.

- `KWAF name(p1,p2) => expression` defines a function.
- `KWAC name(arg1,arg2)` calls it.
- Parameters are evaluated arguments bound in a temporary local scope.
- Function bodies reuse the dimensional arithmetic evaluator.
- Wrong arity, unknown functions, duplicate names/parameters and invalid function bodies are rejected.
- A bounded call-depth guard is included for future recursive call paths.
- Function-local parameters do not leak, and they can shadow global names safely.
- Existing mutable state and live-expression evaluation remain integrated.

## Example
```text
KWAF extend(distance, addition) => FRAPA $distance $addition
KWAC extend(2@m, 30@cm)
# 2.3 m
```

## Run
Python 3.10+; standard library only.
```bash
python -m unittest -v test_arcane_runtime.py
python arcane_session.py
```

## Syntax/canon boundary and limitations
`KWAF`, `KWAC`, `=>`, comma-separated arguments and `$name` are provisional implementation syntax, not a canon change. Function bodies currently contain a single arithmetic/reference expression; function calls are not yet part of the expression grammar, so function composition is possible across statements but not nested inline calls. Return values are typed quantities. Function definitions are stored in the environment but are not yet scoped or persisted separately from the process. No branching, loops, user-defined return statements, overloading, or magic execution is implemented.

## Verification
13 focused tests pass, covering ordinary calls, dimensional unit arithmetic, mismatched dimensions, arity errors, unknown and duplicate functions, duplicate parameters, local scope isolation, global lookup, shadowing, state/live regression and invalid declaration rollback when used through the session manager.

## Next milestone
Phase 7E should add structured control flow and function-call expressions only after designing their grammar and evaluation rules in a small executable profile. Keep extending this runtime; do not restart the broad audit.
