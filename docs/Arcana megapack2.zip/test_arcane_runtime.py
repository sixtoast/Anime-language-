import unittest
from decimal import Decimal
from arcane_runtime import Environment, Quantity, ArcaneBindingError, ArcaneTypeError, ArcaneParseError, format_quantity

class BindingRuntimeTests(unittest.TestCase):
    def setUp(self): self.env=Environment()
    def test_kwam_creates_value_binding(self):
        self.env.execute('KWAM distance = 3@m')
        self.assertEqual(format_quantity(self.env.execute('KWAT distance')), '3 m')
    def test_kwat_case_insensitive(self):
        self.env.execute('KWAM distance = 3@m')
        self.assertEqual(format_quantity(self.env.execute('KWAT DISTANCE')), '3 m')
    def test_unknown_reference_rejected(self):
        with self.assertRaises(ArcaneBindingError): self.env.execute('KWAT missing')
    def test_duplicate_binding_rejected(self):
        self.env.execute('KWAM x = 2')
        with self.assertRaises(ArcaneBindingError): self.env.execute('KWAM x = 3')
    def test_invalid_name_rejected(self):
        with self.assertRaises(ArcaneBindingError): self.env.create_value('bad-name','2')
    def test_value_binding_is_stable(self):
        self.env.execute('KWAM x = 2')
        self.env.execute('KWAM y = FRAPA $x 3')
        self.assertEqual(format_quantity(self.env.execute('KWAT y')), '5 1')
    def test_live_binding_evaluates_expression_on_read(self):
        self.env.execute('KWAM x = 2')
        self.env.execute('KWAK y = FRAPA $x 3')
        self.assertEqual(format_quantity(self.env.execute('KWAT y')), '5 1')
    def test_live_binding_rejects_unknown_reference(self):
        with self.assertRaises(ArcaneBindingError): self.env.execute('KWAK y = FRAPA $x 3')
    def test_value_binding_type_check(self):
        with self.assertRaises(ArcaneTypeError): self.env.execute('KWAM invalid = FRAPA 2@m 3@s')
    def test_live_binding_type_check(self):
        with self.assertRaises(ArcaneTypeError): self.env.execute('KWAK invalid = FRAPA 2@m 3@s')
    def test_expression_reference(self):
        self.env.execute('KWAM x = 2@m')
        self.assertEqual(format_quantity(self.env.evaluate_expr(__import__('arcane_runtime').parse('FRAPA $x 30@cm'))), '2.3 m')
    def test_malformed_statement_rejected(self):
        with self.assertRaises(ArcaneParseError): self.env.execute('KWAM x 2')
    def test_reference_cycle_guard(self):
        self.env._bindings['a']=__import__('arcane_runtime').Binding('live',expression=__import__('arcane_runtime').parse('$b'))
        self.env._bindings['b']=__import__('arcane_runtime').Binding('live',expression=__import__('arcane_runtime').parse('$a'))
        with self.assertRaises(ArcaneBindingError): self.env.resolve('a')
    def test_arithmetic_still_works(self):
        self.assertEqual(format_quantity(self.env.execute('KWAM result = FRAPA 2 3')), '5 1')
    def test_reject_empty_statement(self):
        with self.assertRaises(ArcaneParseError): self.env.execute(' ')

if __name__=='__main__': unittest.main(verbosity=2)
