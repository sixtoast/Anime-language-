ARCANE PHASE 7R — SYNTAX CHECKING AND DEVELOPER TOOLING

This standalone package adds a static checker for the reconstructed provisional
Arcane subset. It does not execute programs and is not a full compiler.

Run tests:
  python -m unittest -v

Check a valid example:
  python arcane_cli.py example_valid.arc

Check an intentionally invalid example:
  python arcane_cli.py example_invalid.arc

Exit status: 0 means the checker found no supported-shape or block-structure
errors; 1 means it reported an issue. Passing does not guarantee runtime success.
All syntax remains provisional pending reconciliation with canonical decisions.
