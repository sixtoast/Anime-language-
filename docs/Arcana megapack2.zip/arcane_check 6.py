"""Static syntax checks using the same parser as the runtime."""
from dataclasses import dataclass
from pathlib import Path
from arcane_runtime import ArcaneFailure, parse_program

@dataclass(frozen=True)
class Issue:
    code: str
    message: str
    line: int
    def render(self, filename='<source>'):
        return f'{filename}:{self.line}: error {self.code}: {self.message}'

@dataclass(frozen=True)
class Report:
    filename: str
    issues: tuple
    checked: int
    @property
    def ok(self): return not self.issues
    def render(self):
        return f'{self.filename}: syntax OK ({self.checked} lines checked)' if self.ok else '\n'.join(x.render(self.filename) for x in self.issues)

def check_source(src, filename='<source>'):
    checked=sum(1 for raw in src.splitlines() if raw.strip() and not raw.strip().startswith('#'))
    try:
        _, parsed=parse_program(src)
        return Report(filename,(),parsed)
    except ArcaneFailure as e:
        return Report(filename,(Issue(e.code,e.message,e.line),),checked)

def check_file(path):
    p=Path(path)
    try: return check_source(p.read_text(encoding='utf-8'),str(p))
    except OSError as e: return Report(str(p),(Issue('ARC-IO-001',str(e),1),),0)
