# Arcane Phase 7K — Runtime Diagnostic Adapter

## Delivered

Phase 7K adds `arcane_runtime_adapter.py`, a small adapter that connects any existing evaluator callable to the Phase 7J diagnostic catalogue and descriptive type system. It returns a structured `EvaluationResult`, preserves already-structured Arcane diagnostics, maps common exceptions to stable codes, attaches source positions, avoids traceback leakage in user-facing messages, and offers `require_success` for callers that prefer exceptions.

## Verification

- 33/33 combined tests passed: 23 Phase 7J diagnostic/type tests and 10 adapter integration tests.
- Python standard library only.
- The adapter's dimensions argument is metadata supplied by the caller; it does not perform unit arithmetic or infer dimensions from an evaluator-specific quantity class.

## Integration boundary / limitation

The prior provisional Phase 7H/7I evaluator source was not available in the active workspace. Therefore this phase provides and tests an integration adapter, but does not claim the adapter has been wired into the missing evaluator or that bounded repetition/aggregation have been regression-tested here. The user's supplied `Arcana pack.zip` contains historical language-audit assets and a Phase 5 lexicon generator, not the Phase 7H/7I runtime.

## Compatibility and canonical language

No Arcane syntax, spelling, grammar, or canonical vocabulary is changed by this phase. Diagnostic codes and type descriptors are implementation utilities, not language vocabulary decisions.

## Next build-forward step

Recover the actual latest Phase 7I runtime package into the workspace, wire `evaluate_safely` into its session/evaluator boundary, and run the complete runtime regression suite plus these adapter tests in one package.
