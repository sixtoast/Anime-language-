# Arcane Phase 7E — Conditional Expressions and Comparisons

## Delivered
This phase extends a runnable provisional runtime with three comparison operators and lazy conditional selection.

- `FRAGT a b`: greater-than comparison; returns dimensionless `1` or `0`.
- `FRALT a b`: less-than comparison; returns dimensionless `1` or `0`.
- `FRAEQ a b`: equality comparison; returns dimensionless `1` or `0`.
- `FRASI condition then_expr else_expr`: evaluates the condition, then evaluates only the selected branch. A zero condition is false; any non-zero condition is true.
- Functions may use conditional expressions in their body.
- The interactive shell snapshots state and rolls back failed statements.

## Example
```text
KWAF clamp_positive(x) => FRASI FRAGT $x 0 $x 0
KWAC clamp_positive(-3)
# 0 1
FRASI FRAGT 12 10 100 200
# 100 1
```

## Tests and running
Python 3.10+; standard library only.
```bash
python -m unittest -v test_arcane_runtime.py
python arcane_session.py
```
The included 12 tests pass, covering branch selection, lazy evaluation, comparisons, dimensional constraints, function integration and arity errors.

## Boundaries
All spellings and semantics added here are provisional implementation syntax, not a canon change. Function calls are still statements, not general expression nodes, so nested inline calls are not supported. `FRASI` dynamically evaluates only the selected branch; this means an invalid or unknown reference in an unselected branch is not evaluated. The current conditional truth rule is non-zero versus zero. Boolean types, static branch type inference, logical operators, loops, return statements, and full magic-system integration remain unimplemented.
