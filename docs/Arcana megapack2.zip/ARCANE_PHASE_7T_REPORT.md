# Arcane Phase 7T — Symbol Tables and Semantic Analysis

## Outcome

Phase 7T adds a standalone semantic-analysis pass and integrates it into the existing static-checking CLI. It remains a checker, not an interpreter or compiler. It does not execute source programs.

## Checks implemented

- Resolve `$binding` references against the current scope and enclosing scopes.
- Detect duplicate `KWAM` binding declarations in the same scope.
- Collect `KWAF` function declarations so forward function calls can be resolved.
- Detect duplicate function definitions and duplicate function parameters.
- Detect calls to undefined functions.
- Check function-call argument counts against declared parameter counts.
- Treat conditional branches as separate provisional scopes; branch-local bindings do not escape the block.
- Give function parameters their own expression scope.
- Preserve line-specific diagnostics with codes `ARC-SEM-001` through `ARC-SEM-007`.

## CLI

```bash
python arcane_cli.py example_valid.arc
python arcane_cli.py example_invalid.arc
python arcane_cli.py --syntax-only example_valid.arc
python arcane_cli.py --semantic-only example_valid.arc
python -m unittest -v
```

The default CLI runs syntax and semantic checks. `--syntax-only` and `--semantic-only` are available for focused diagnostics; they cannot be combined.

## Verification

- 31 unit tests passed across syntax and semantic suites.
- The valid example passed syntax and semantic checks.
- The deliberately invalid example failed with non-zero exit status and diagnostics.
- Archive integrity checked after packaging.

## Explicit boundaries

This is based on the reconstructed provisional subset. Scope rules are implemented as a testable working policy, not declared canon. In particular, branch-local scope, declaration ordering, function visibility, recursion, and whether `KWAT` is definitively a binding-use statement must be reconciled against the full canonical specification. Type checking, dimensional/constraint analysis, control-flow guarantees, runtime integration, and execution remain out of scope. The historical archive available in this workspace did not include the prior reconstructed Phase 7 runtime, so this phase does not claim runtime integration.

## Next phase recommendation

Phase 7U should recover/reconstruct a single runnable workspace and define a minimal end-to-end contract: parse source, run static checks, then execute a small supported program subset. This is more valuable than adding more isolated checks indefinitely. Before promoting the provisional syntax to canonical status, reconcile the checker against the decision ledger and grammar consistency register.
