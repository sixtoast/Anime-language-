import unittest
from arcane_runtime import ArcaneRuntime, Quantity
from arcane_diagnostics import ArcaneDiagnosticError, ErrorCode

class RuntimeTests(unittest.TestCase):
 def setUp(self): self.r=ArcaneRuntime()
 def test_number(self): self.assertEqual(self.r.evaluate('4').value,4)
 def test_add(self): self.assertEqual(self.r.evaluate('FRAPA 2 3').value,5)
 def test_subtract(self): self.assertEqual(self.r.evaluate('FRALA 8 3').value,5)
 def test_multiply(self): self.assertEqual(self.r.evaluate('FRATA 2 3').value,6)
 def test_divide(self): self.assertEqual(self.r.evaluate('FRAKA 8 2').value,4)
 def test_divide_zero_diagnostic(self):
  with self.assertRaises(ArcaneDiagnosticError) as e: self.r.evaluate('FRAKA 1 0')
  self.assertEqual(e.exception.diagnostic.code,ErrorCode.DIVISION_BY_ZERO)
 def test_unknown_name_diagnostic(self):
  with self.assertRaises(ArcaneDiagnosticError) as e: self.r.evaluate('$missing')
  self.assertEqual(e.exception.diagnostic.code,ErrorCode.UNKNOWN_NAME)
 def test_units_add_same(self): self.assertEqual(self.r.evaluate('FRAPA m cm').dimensions,(1,0,0))
 def test_units_mismatch(self):
  with self.assertRaises(ArcaneDiagnosticError) as e: self.r.evaluate('FRAPA m s')
  self.assertEqual(e.exception.diagnostic.code,ErrorCode.DIMENSION_MISMATCH)
 def test_product_dimensions(self): self.assertEqual(self.r.evaluate('FRATA m s').dimensions,(1,1,0))
 def test_comparison(self): self.assertTrue(self.r.evaluate('FRAGT 3 2'))
 def test_equality(self): self.assertTrue(self.r.evaluate('FRAEQ 3 3'))
 def test_logic(self): self.assertTrue(self.r.evaluate('FRAND 1 1'))
 def test_not(self): self.assertTrue(self.r.evaluate('FRNOT 0'))
 def test_parentheses(self): self.assertEqual(self.r.evaluate('( FRAPA 2 3 )').value,5)
 def test_define_and_lookup(self):
  self.r.run_line('KWAM total => FRAPA 2 3'); self.assertEqual(self.r.run_line('KWAT total').value,5)
 def test_duplicate_binding(self):
  self.r.run_line('KWAM x => 1'); out=self.r.run_line('KWAM x => 2'); self.assertEqual(out.code,ErrorCode.DUPLICATE_BINDING)
 def test_trailing_token(self):
  with self.assertRaises(ArcaneDiagnosticError) as e: self.r.evaluate('1 2')
  self.assertEqual(e.exception.diagnostic.code,ErrorCode.PARSE_ERROR)
 def test_invalid_token(self):
  with self.assertRaises(ArcaneDiagnosticError): self.r.evaluate('@')
 def test_dimensionless_one_truth(self): self.assertTrue(self.r.evaluate('FRNOT 0'))
 def test_zero_is_not_true(self): self.assertFalse(self.r.evaluate('FRAND 0 1'))

if __name__=='__main__': unittest.main()

class Phase7MIntegrationTests(unittest.TestCase):
 def setUp(self): self.r=ArcaneRuntime()
 def test_bounded_repetition(self):
  out=self.r.run_line('KWAR i FROM 1 TO 3 => FRATA $i $i')
  self.assertEqual([x.value for x in out],[1,4,9])
 def test_repetition_empty_range(self): self.assertEqual(self.r.run_line('KWAR i FROM 3 TO 1 => $i'),[])
 def test_repetition_scope_does_not_leak(self):
  self.r.run_line('KWAR i FROM 1 TO 2 => $i')
  out=self.r.run_line('KWAT i'); self.assertEqual(out.code,ErrorCode.UNKNOWN_NAME)
 def test_bounded_aggregation(self): self.assertEqual(self.r.run_line('KWAS total FROM 1 TO 5 => $total').value,15)
 def test_aggregation_squares(self): self.assertEqual(self.r.run_line('KWAS total FROM 1 TO 3 => FRATA $total $total').value,14)
 def test_aggregation_empty_range(self): self.assertEqual(self.r.run_line('KWAS total FROM 3 TO 1 => $total').value,0)
 def test_aggregation_iteration_limit(self):
  self.r.max_iterations=3
  out=self.r.run_line('KWAR i FROM 1 TO 4 => $i'); self.assertEqual(out.code,ErrorCode.ITERATION_LIMIT)
 def test_invalid_bound(self):
  out=self.r.run_line('KWAR i FROM m TO 3 => $i'); self.assertEqual(out.code,ErrorCode.INVALID_BOUNDS)
 def test_and_short_circuits(self): self.assertFalse(self.r.evaluate('FRAND 0 $missing'))
 def test_or_short_circuits(self): self.assertTrue(self.r.evaluate('FROR 1 $missing'))
 def test_aggregation_preserves_dimensions(self): self.assertEqual(self.r.run_line('KWAS total FROM 1 TO 3 => FRATA $total m').dimensions,(1,0,0))
