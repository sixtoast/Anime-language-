ARCANE PHASE 7U — MINIMAL RUNNABLE WORKSPACE

Python 3.10+; standard library only.

Run regression tests:
  python -m unittest -v

Static checks:
  python arcane_cli.py --check example.arc

Execute program:
  python arcane_cli.py --run example.arc

Expected example output: 49

This package is a fresh reconstruction because the prior Phase 7R/7T workspace
was not available. It implements a small executable subset, not the complete
Arcane language. Grammar and semantics remain provisional. See
ARCANE_PHASE_7U_REPORT.md for detailed scope and limitations.
