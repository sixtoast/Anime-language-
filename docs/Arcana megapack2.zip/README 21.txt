ARCANE PHASE 7T — SYMBOL TABLES AND SEMANTIC ANALYSIS

Contents:
- arcane_check.py: syntax and expression-shape checking (Phase 7R/7S)
- arcane_expr.py: provisional expression parser
- arcane_semantic.py: Phase 7T scope, binding, and function checks
- arcane_cli.py: integrated syntax + semantic CLI (no execution)
- test_arcane_check.py and test_arcane_semantic.py: automated regression tests
- example_valid.arc and example_invalid.arc: smoke-test fixtures
- ARCANE_PHASE_7T_REPORT.md: implementation details and limitations
- PHASE_7T_TEST_OUTPUT.txt: full test log

Run from this directory:
  python -m unittest -v
  python arcane_cli.py example_valid.arc
  python arcane_cli.py example_invalid.arc

The syntax and semantic rules are provisional, not canonical. This package does not execute Arcane programs.
