ARCANE PHASE 7M — RUNTIME INTEGRATION

Quick start:
  python arcane_cli.py

Run the complete suite:
  python -m unittest -v

Runnable subset includes:
- Prefix arithmetic: FRAPA, FRALA, FRATA, FRAKA
- Comparisons: FRAGT, FRALT, FRAEQ
- Short-circuit logic: FRAND, FROR, FRNOT
- Parenthesised expressions
- Units: 1, m, cm, km, s, kg
- Bindings: KWAM name => expression; KWAT name
- Bounded repetition: KWAR i FROM start TO end => expression
- Bounded aggregation: KWAS total FROM start TO end => expression
- Stable diagnostics and descriptive typing utilities

Example commands:
  FRAPA 2 3
  KWAR i FROM 1 TO 3 => FRATA $i $i
  KWAS total FROM 1 TO 5 => $total

The grammar/operator spellings and statement forms are provisional, not canonical
language decisions. This is not yet the full Arcane implementation.
