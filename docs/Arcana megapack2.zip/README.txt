ARCANE PHASE 7W — FUNCTION AND SEMANTIC CONSISTENCY
Python 3.10+; standard library only.
Tests: python -m unittest -v
Check: python arcane_cli.py --check example.arc
Run:   python arcane_cli.py --run example.arc
Expected example output: 13
See ARCANE_PHASE_7W_REPORT.md. This is a provisional reconstructed subset.
