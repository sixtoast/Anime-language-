ARCANE PHASE 7G — LOGICAL EXPRESSIONS

This package extends the provisional Phase 7F runtime with short-circuit logical operations:
  FRAND <left> <right>  logical conjunction
  FROR  <left> <right>  logical disjunction
  FRNOT <value>          logical negation

These spellings are provisional implementation tokens only. They have not been established as canonical forms in the Arcane lexicon. All three operators return dimensionless numeric truth values (1 for true, 0 for false). Any non-zero dimensionless operand is treated as true. FRAND and FROR short-circuit. Logical operands must be dimensionless.

Requirements: Python 3.10+ (standard library only).
Run tests: python -m unittest -v
Start interactive session: python arcane_session.py

This is a tested executable subset, not a claim that the complete Arcane language/runtime is finished.
