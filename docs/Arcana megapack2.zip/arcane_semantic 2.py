"""Phase 7T semantic checks for the provisional Arcane subset.

This module does not execute programs and does not define canonical scope rules.
It implements an explicit, documented provisional policy for bindings and functions.
"""
from __future__ import annotations
from dataclasses import dataclass
import re
from pathlib import Path
from arcane_expr import tokenize, BINARY_PREFIX

NAME = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
FUNCTION = re.compile(r"^KWAF\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(([^()]*)\)\s*=>\s*(.+)$")
BINDING = re.compile(r"^KWAM\s+([A-Za-z_][A-Za-z0-9_]*)\s*=>\s*(.+)$")

@dataclass(frozen=True)
class SemanticIssue:
    code: str
    message: str
    line: int
    hint: str = ""
    def render(self, filename="<source>"):
        extra = f" Hint: {self.hint}" if self.hint else ""
        return f"{filename}:{self.line}: error {self.code}: {self.message}{extra}"

@dataclass
class Scope:
    bindings: dict[str, int]
    params: set[str]
    kind: str = "block"
    def resolve(self, name: str) -> bool:
        scope: Scope | None = self
        while scope is not None:
            if name in scope.bindings or name in scope.params:
                return True
            scope = getattr(scope, "parent", None)
        return False

@dataclass(frozen=True)
class FunctionInfo:
    params: tuple[str, ...]
    line: int

@dataclass(frozen=True)
class SemanticReport:
    filename: str
    issues: tuple[SemanticIssue, ...]
    @property
    def ok(self): return not self.issues
    def render(self):
        if self.ok: return f"{self.filename}: semantic checks OK"
        return "\n".join(i.render(self.filename) for i in self.issues)

def _parent_scope(bindings=None, params=None, kind="block", parent=None):
    s = Scope(bindings or {}, params or set(), kind)
    s.parent = parent
    return s

def _calls_and_refs(expression: str):
    """Return binding refs and named calls, excluding Arcane prefix operators."""
    tokens = tokenize(expression)
    refs = [t[1:] for t in tokens if t.startswith("$")]
    calls = []
    for i, tok in enumerate(tokens[:-1]):
        if NAME.fullmatch(tok) and tokens[i+1] == "(" and tok not in BINARY_PREFIX:
            # Count top-level comma-separated arguments in this call.
            depth, commas, has_arg = 0, 0, False
            j = i + 2
            if j < len(tokens) and tokens[j] == ")":
                arity = 0
            else:
                arity = 1
                while j < len(tokens):
                    t = tokens[j]
                    if t == "(": depth += 1
                    elif t == ")":
                        if depth == 0: break
                        depth -= 1
                    elif t == "," and depth == 0: commas += 1
                    j += 1
                arity += commas
            calls.append((tok, arity))
    return refs, calls

def analyze_source(source: str, filename: str = "<source>") -> SemanticReport:
    issues: list[SemanticIssue] = []
    lines = [(i, raw.strip()) for i, raw in enumerate(source.splitlines(), 1)
             if raw.strip() and not raw.strip().startswith("#")]
    functions: dict[str, FunctionInfo] = {}
    # First pass: function declarations are globally visible (including forward calls).
    for line, text in lines:
        m = FUNCTION.fullmatch(text)
        if not m: continue
        name, raw_params, _ = m.groups()
        params = tuple(p.strip().lstrip("$") for p in raw_params.split(",") if p.strip())
        if any(not NAME.fullmatch(p) for p in params):
            issues.append(SemanticIssue("ARC-SEM-001", f"invalid parameter list for function '{name}'", line,
                                        "Use comma-separated identifier names."))
            continue
        if len(set(params)) != len(params):
            issues.append(SemanticIssue("ARC-SEM-002", f"duplicate parameter in function '{name}'", line))
        if name in functions:
            issues.append(SemanticIssue("ARC-SEM-003", f"function '{name}' is defined more than once", line,
                                        "Give each function one definition."))
        else: functions[name] = FunctionInfo(params, line)

    root = _parent_scope(kind="global")
    # Function parameters belong to their own expression scope; function bodies are expression-only here.
    scopes = [root]
    block_frames = []  # stores parent scope and whether currently in ELSE branch
    for line, text in lines:
        if text.startswith("KWAI ") and text.endswith(" THEN"):
            expr = text[5:-5].strip()
            _check_expr(expr, line, scopes[-1], functions, issues)
            parent = scopes[-1]
            child = _parent_scope(kind="branch", parent=parent)
            scopes.append(child); block_frames.append((parent, False))
            continue
        if text == "ELSE":
            if block_frames and scopes:
                parent, _ = block_frames[-1]
                scopes[-1] = _parent_scope(kind="branch", parent=parent)
                block_frames[-1] = (parent, True)
            continue
        if text == "END":
            if block_frames and len(scopes) > 1:
                scopes.pop(); block_frames.pop()
            continue
        fm = FUNCTION.fullmatch(text)
        if fm:
            name, raw_params, expr = fm.groups()
            params = set(p.strip().lstrip("$") for p in raw_params.split(",") if p.strip())
            fn_scope = _parent_scope(params=params, kind="function", parent=root)
            _check_expr(expr, line, fn_scope, functions, issues, current_function=name)
            continue
        bm = BINDING.fullmatch(text)
        if bm:
            name, expr = bm.groups()
            _check_expr(expr, line, scopes[-1], functions, issues)
            if name in scopes[-1].bindings:
                issues.append(SemanticIssue("ARC-SEM-004", f"binding '{name}' is declared more than once in the same scope", line,
                                            "Use a new name or assign through a separately specified update construct."))
            else:
                scopes[-1].bindings[name] = line
            continue
        # KWAT is treated as a reference/use in the reconstructed subset.
        if text.startswith("KWAT "):
            name = text.split(None, 1)[1].strip()
            if not scopes[-1].resolve(name):
                issues.append(SemanticIssue("ARC-SEM-005", f"unresolved binding '{name}'", line,
                                            "Declare it with KWAM in an enclosing scope."))
            continue
        # Check expressions embedded in the remaining recognised provisional forms.
        if text.startswith(("KWAR ", "KWAS ")) and "=>" in text:
            _check_expr(text.split("=>", 1)[1].strip(), line, scopes[-1], functions, issues)
        elif text.startswith("KWAI ") and " THEN " in text and " ELSE " in text:
            m = re.fullmatch(r"KWAI\s+(.+?)\s+THEN\s+(.+?)\s+ELSE\s+(.+)", text)
            if m:
                for expr in m.groups(): _check_expr(expr, line, scopes[-1], functions, issues)
    issues.sort(key=lambda i: (i.line, i.code, i.message))
    return SemanticReport(filename, tuple(issues))

def _check_expr(expr, line, scope, functions, issues, current_function=None):
    try: refs, calls = _calls_and_refs(expr)
    except Exception: return  # syntax checker owns parse diagnostics
    for name in refs:
        if not scope.resolve(name):
            issues.append(SemanticIssue("ARC-SEM-005", f"unresolved binding '${name}'", line,
                                        "Declare the binding in this scope or an enclosing scope."))
    for name, arity in calls:
        if name not in functions:
            issues.append(SemanticIssue("ARC-SEM-006", f"call to undefined function '{name}'", line,
                                        "Define the function with KWAF before using it, or correct the name."))
        elif len(functions[name].params) != arity:
            issues.append(SemanticIssue("ARC-SEM-007", f"function '{name}' expects {len(functions[name].params)} argument(s), got {arity}", line,
                                        "Match the call's argument count to the function definition."))
        if current_function and name == current_function:
            # Recursion is not prohibited; leave it permitted pending canonical call rules.
            pass

def analyze_file(path: str | Path) -> SemanticReport:
    p = Path(path)
    try: source = p.read_text(encoding="utf-8")
    except OSError as exc: return SemanticReport(str(p), (SemanticIssue("ARC-IO-001", f"cannot read file: {exc}", 1),))
    return analyze_source(source, str(p))
