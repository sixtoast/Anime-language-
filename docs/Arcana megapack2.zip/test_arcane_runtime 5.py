import unittest
from arcane_runtime import Environment,fmt,ArcaneTypeError,ArcaneBindingError,ArcaneEvaluationError
class StructuredExecutionTests(unittest.TestCase):
 def setUp(self):self.e=Environment()
 def test_conditional_true_branch(self):self.assertEqual(fmt(self.e.execute('FRASI 1 12 20')),'12 1')
 def test_conditional_false_branch(self):self.assertEqual(fmt(self.e.execute('FRASI 0 12 20')),'20 1')
 def test_lazy_conditional_does_not_evaluate_unselected_division(self):self.assertEqual(fmt(self.e.execute('FRASI 1 8 FRALA 1 0')),'8 1')
 def test_greater_than(self):self.assertEqual(fmt(self.e.execute('FRAGT 3 2')),'1 1')
 def test_less_than_false(self):self.assertEqual(fmt(self.e.execute('FRALT 3 2')),'0 1')
 def test_equal(self):self.assertEqual(fmt(self.e.execute('FRAEQ 4 4')),'1 1')
 def test_comparison_dimensions(self):
  with self.assertRaises(ArcaneTypeError):self.e.execute('FRAGT 1@m 2@s')
 def test_conditional_returns_selected_branch_type(self):self.assertEqual(fmt(self.e.execute('FRASI 1 1@m 2@s')),'1 m')
 def test_function_can_use_conditional(self):
  self.e.execute('KWAF clamp_positive(x) => FRASI FRAGT $x 0 $x 0');self.assertEqual(fmt(self.e.execute('KWAC clamp_positive(5)')),'5 1');self.assertEqual(fmt(self.e.execute('KWAC clamp_positive(-2)')),'0 1')
 def test_function_arity(self):
  self.e.execute('KWAF ident(x) => $x')
  with self.assertRaises(ArcaneBindingError):self.e.execute('KWAC ident(1,2)')
 def test_division_by_zero_in_selected_branch(self):
  with self.assertRaises(ArcaneEvaluationError):self.e.execute('FRASI 0 9 FRALA 1 0')
 def test_unselected_branch_is_not_evaluated(self):self.assertEqual(fmt(self.e.execute('FRASI 1 4 $missing')),'4 1')
if __name__=='__main__':unittest.main(verbosity=2)
