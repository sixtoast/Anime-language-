"""Static structural checks for the executable provisional subset."""
import re
from dataclasses import dataclass
from pathlib import Path
@dataclass(frozen=True)
class Issue:
    code:str; message:str; line:int
    def render(self,filename='<source>'): return f'{filename}:{self.line}: error {self.code}: {self.message}'
@dataclass(frozen=True)
class Report:
    filename:str; issues:tuple; checked:int
    @property
    def ok(self): return not self.issues
    def render(self): return f'{self.filename}: syntax OK ({self.checked} lines checked)' if self.ok else '\n'.join(x.render(self.filename) for x in self.issues)
def check_source(src,filename='<source>'):
    stack=[]; issues=[]; checked=0
    for n,raw in enumerate(src.splitlines(),1):
        s=raw.strip()
        if not s or s.startswith('#'): continue
        checked+=1
        if re.fullmatch(r'KWAI\s+.+\s+THEN',s): stack.append(n)
        elif s=='ELSE':
            if not stack: issues.append(Issue('ARC-PARSE-002','ELSE without open conditional',n))
        elif s=='END':
            if not stack: issues.append(Issue('ARC-PARSE-002','END without open conditional',n))
            else: stack.pop()
        elif s.startswith('KWAI '): issues.append(Issue('ARC-PARSE-003','malformed conditional header',n))
        elif not (s.startswith('KWAM ') or s.startswith('KWAF ') or s.startswith('KWAT ')):
            issues.append(Issue('ARC-PARSE-004','unsupported statement shape',n))
    for n in stack: issues.append(Issue('ARC-PARSE-001','conditional missing END',n))
    return Report(filename,tuple(issues),checked)
def check_file(path):
    p=Path(path)
    try: return check_source(p.read_text(encoding='utf-8'),str(p))
    except OSError as e: return Report(str(p),(Issue('ARC-IO-001',str(e),1),),0)
