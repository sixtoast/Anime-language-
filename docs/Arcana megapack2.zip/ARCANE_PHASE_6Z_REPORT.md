# Arcane Phase 6Z — Typed Quantities and Dimensional Validation

## Deliverable
A runnable arithmetic core now supports decimal numeric literals, a starter unit set, base-unit normalisation, dimensional inference, pre-evaluation type checking and informative failures. This is an implementation milestone, not another audit-only phase.

## Run
Requires Python 3.10+ and only the Python standard library.

```bash
python arcane_typed_core.py FRAPA 3 2
# 5 1
python arcane_typed_core.py FRAPA 2@m 30@cm
# 2.3 m
python arcane_typed_core.py FRAKA 3@m 2@s
# 6 m s
python arcane_typed_core.py FRAPA 2@m 3@s
# Arcane error: FRAPA requires matching dimensions; ...
python -m unittest -v test_arcane_typed_core.py
```

## Implemented
- Numeric literals including decimals and exponent notation.
- Units: dimensionless `1`, `m`, `cm`, `km`, `s`, `min`, `h`, `kg`, `g`.
- Addition/subtraction require equal dimensions.
- Multiplication adds dimension exponents; division subtracts them.
- Type checking is performed on the whole expression before numeric evaluation.
- Clear errors for unknown units/forms, malformed syntax, arity errors and division by zero.
- Decimal arithmetic avoids common binary floating-point surprises.

## Non-canonical boundary
Whitespace-separated prefix notation and `number@unit` literal notation are provisional implementation syntax, not canon. The dimension basis is currently length/time/mass only. It does not yet model temperature, electric current, angle, information, mana, uncertainty, affine units, vector/tensor types or physical feasibility. Arithmetic operator signatures remain an implementation profile pending canon approval. A dimensionally valid expression is not proof of physical or magical possibility.

## Phase exit result
The prior arithmetic-only core is extended with numeric and unit-bearing literals and a dimensional type checker. The tests in `test_arcane_typed_core.py` exercise successful calculations and invalid expressions through the same parser and evaluator. Future phases should build on this runtime rather than creating parallel prototypes.
