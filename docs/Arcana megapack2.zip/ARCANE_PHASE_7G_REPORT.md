# Arcane Phase 7G — Logical Expressions and Boolean Semantics

## Outcome

Phase 7G extends the reconstructed provisional Phase 7F runtime with three logical expression operators and short-circuit evaluation. The implementation is runnable and the test suite passes **37/37 tests**.

## New operations

| Operator | Meaning | Arity |
|---|---|---:|
| `FRAND` | Logical conjunction | 2 |
| `FROR` | Logical disjunction | 2 |
| `FRNOT` | Logical negation | 1 |

**Lexicon status:** these operator spellings are provisional implementation choices. They have not been verified as canonical Arcane words and must not be silently promoted to canonical vocabulary.

## Semantics implemented

- Logical operations return dimensionless numeric truth values: `1` means true and `0` means false.
- Any non-zero dimensionless operand is interpreted as true; zero is false.
- `FRAND` stops after a false left operand and does not evaluate its right operand.
- `FROR` stops after a true left operand and does not evaluate its right operand.
- `FRNOT` maps false to true and any true value to false.
- Logical operands must be dimensionless. Dimensional operands raise `ArcaneTypeError`.
- Logical operations compose with comparisons, conditionals, and user-defined function calls.
- Operator spelling is case-insensitive.

## Verification

Command: `python -m unittest -v`

Result: **Ran 37 tests — OK.** The suite covers truth tables, negation, short-circuit behaviour, dimensional validation, comparisons composed with logic, conditional integration, function composition, case-insensitivity, arity and regression behaviour from Phase 7F.

## Known limitations

- This is still a deliberately small executable subset, not a complete Arcane runtime.
- Truth values are represented as dimensionless quantities, not a distinct static Boolean type.
- Existing `FRASI` still accepts any quantity as a condition using non-zero truthiness, including dimensional values; a future compatibility decision should define whether to tighten this.
- Static type inference, complete branch-type checking, forward declarations, loops, modules and broad standard-library integration are not supplied by this phase.
- The new spellings need review against the project's authoritative lexicon/decision ledger before being considered canonical.
- The phase builds on the current reconstructed Phase 7F package and the supplied `Arcana pack.zip`; it does not claim to recover missing historical workspace state.

## Files

- `arcane_runtime.py` — runtime implementation
- `arcane_session.py` — interactive session
- `test_arcane_runtime.py` — automated tests
- `example.arc` — logical-expression examples
- `PHASE_7G_TEST_OUTPUT.txt` — test output
- `PHASE_7G_STATUS.csv` — implementation status
- `README.txt` — usage notes
