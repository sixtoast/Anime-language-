ARCANE PHASE 7E — CONDITIONALS AND COMPARISONS

Run tests: python -m unittest -v test_arcane_runtime.py
Run shell: python arcane_session.py
Example file: example.arc
Python 3.10+, standard library only.
Syntax is provisional and does not alter canonical Arcane grammar.
