KWAM score => 8
KWAI FRAGT $score 5 THEN
KWAM answer => 42
ELSE
ELSE
