import unittest
from arcane_runtime import Environment, format_quantity, ArcaneBindingError, ArcaneTypeError, ArcaneParseError
class StateScopeTests(unittest.TestCase):
 def setUp(self): self.e=Environment()
 def test_state_updates(self):
  self.e.execute('KWAS x = 2'); self.e.execute('KWAS x <- 5'); self.assertEqual(format_quantity(self.e.execute('KWAT x')),'5 1')
 def test_live_reacts_to_update(self):
  self.e.execute('KWAS x = 2'); self.e.execute('KWAK y = FRAPA $x 3'); self.assertEqual(format_quantity(self.e.execute('KWAT y')),'5 1'); self.e.execute('KWAS x <- 7'); self.assertEqual(format_quantity(self.e.execute('KWAT y')),'10 1')
 def test_state_dimension_cannot_change(self):
  self.e.execute('KWAS d = 2@m')
  with self.assertRaises(ArcaneTypeError): self.e.execute('KWAS d <- 4@s')
  self.assertEqual(format_quantity(self.e.execute('KWAT d')),'2 m')
 def test_immutable_value_cannot_update(self):
  self.e.execute('KWAM x = 2')
  with self.assertRaises(ArcaneBindingError): self.e.execute('KWAS x <- 3')
 def test_unknown_assignment_rejected(self):
  with self.assertRaises(ArcaneBindingError): self.e.execute('KWAS missing <- 3')
 def test_duplicate_same_scope_rejected(self):
  self.e.execute('KWAS x = 1')
  with self.assertRaises(ArcaneBindingError): self.e.execute('KWAM x = 2')
 def test_scope_shadowing(self):
  self.e.execute('KWAS x = 1'); self.e.push_scope(); self.e.execute('KWAM x = 2'); self.assertEqual(format_quantity(self.e.execute('KWAT x')),'2 1'); self.e.pop_scope(); self.assertEqual(format_quantity(self.e.execute('KWAT x')),'1 1')
 def test_outer_state_can_update_from_inner_scope(self):
  self.e.execute('KWAS x = 1'); self.e.push_scope(); self.e.execute('KWAS x <- 8'); self.e.pop_scope(); self.assertEqual(format_quantity(self.e.execute('KWAT x')),'8 1')
 def test_pop_global_scope_rejected(self):
  with self.assertRaises(ArcaneBindingError): self.e.pop_scope()
 def test_inner_scope_disappears(self):
  self.e.push_scope(); self.e.execute('KWAM local = 4'); self.e.pop_scope()
  with self.assertRaises(ArcaneBindingError): self.e.execute('KWAT local')
 def test_live_binding_in_inner_scope_sees_outer_state(self):
  self.e.execute('KWAS x = 2'); self.e.push_scope(); self.e.execute('KWAK y = FRAKA $x 3'); self.assertEqual(format_quantity(self.e.execute('KWAT y')),'6 1'); self.e.pop_scope()
 def test_failed_declaration_not_created(self):
  with self.assertRaises(ArcaneTypeError): self.e.execute('KWAM bad = FRAPA 1@m 2@s')
  with self.assertRaises(ArcaneBindingError): self.e.execute('KWAT bad')
 def test_live_cycle_detected(self):
  self.e._scopes[0]['a']=__import__('arcane_runtime').Binding('live',expression=__import__('arcane_runtime').parse('$b'))
  self.e._scopes[0]['b']=__import__('arcane_runtime').Binding('live',expression=__import__('arcane_runtime').parse('$a'))
  with self.assertRaises(ArcaneBindingError): self.e.resolve('a')
 def test_case_insensitive_names(self):
  self.e.execute('KWAS Count = 3'); self.e.execute('KWAS count <- 4'); self.assertEqual(format_quantity(self.e.execute('KWAT COUNT')),'4 1')
 def test_arithmetic_still_works(self): self.assertEqual(format_quantity(self.e.execute('FRAPA 2 3')),'5 1')
if __name__=='__main__': unittest.main(verbosity=2)
