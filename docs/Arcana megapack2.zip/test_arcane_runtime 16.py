import unittest
from arcane_runtime import ArcaneRuntime, Diagnostic
class RuntimeTests(unittest.TestCase):
 def runp(self,s): return ArcaneRuntime().run_program(s)
 def test_binding_arithmetic_output(self): self.assertEqual(self.runp('KWAM x => (4 + 3) * 2\nKWAT x'),[14])
 def test_function_call(self): self.assertEqual(self.runp('KWAF square(x) => FRATA $x $x\nKWAM result => square(5)\nKWAT result'),[25])
 def test_conditional_true(self): self.assertEqual(self.runp('KWAM x => 7\nKWAI FRAGT $x 5 THEN\nKWAT x\nELSE\nKWAT x\nEND'),[7])
 def test_conditional_false(self): self.assertEqual(self.runp('KWAI FRAGT 2 5 THEN\nKWAM x => 1\nELSE\nKWAM y => 9\nKWAT y\nEND'),[9])
 def test_nested_conditional(self): self.assertEqual(self.runp('KWAI FRAEQ 1 1 THEN\nKWAI FRAGT 3 2 THEN\nKWAM inner => 4\nKWAT inner\nEND\nEND'),[4])
 def test_missing_end(self): self.assertEqual(self.runp('KWAI FRAEQ 1 1 THEN\nKWAM x => 2').code,'ARC-PARSE-001')
 def test_unresolved_binding(self): self.assertEqual(self.runp('KWAM x => $nope').code,'ARC-SEM-005')
 def test_wrong_arity(self): self.assertEqual(self.runp('KWAF f(x) => $x\nKWAM result => f(1,2)').code,'ARC-SEM-007')
 def test_undefined_function(self): self.assertEqual(self.runp('KWAM x => missing(1)').code,'ARC-SEM-006')
 def test_parse_before_execution(self):
  rt=ArcaneRuntime(); out=rt.run_program('KWAM x => 1\nKWAI FRAEQ 1 1 THEN')
  self.assertEqual(out.code,'ARC-PARSE-001'); self.assertNotIn('x',rt.globals)
 def test_division_by_zero(self): self.assertEqual(self.runp('KWAM x => 1 / 0').code,'ARC-RUN-001')
 def test_comments(self): self.assertEqual(self.runp('# hi\nKWAM x => 2\nKWAT x'),[2])
if __name__=='__main__': unittest.main(verbosity=2)
