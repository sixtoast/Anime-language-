"""Arcane Phase 6Z: provisional dimensional type-checking arithmetic runtime.

This implementation profile is deliberately non-canonical. It makes numeric
literals and units executable while preserving the recovered operator names.
No physical/magical feasibility is inferred from dimensional validity.
"""
from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation, DivisionByZero
import re
from typing import Mapping

class ArcaneError(ValueError): pass
class ArcaneParseError(ArcaneError): pass
class ArcaneTypeError(ArcaneError): pass
class ArcaneEvaluationError(ArcaneError): pass

# Dimension vector order: length, time, mass. This is a small starter set.
DIMENSIONLESS = (0, 0, 0)
UNITS: Mapping[str, tuple[Decimal, tuple[int,int,int]]] = {
    "1": (Decimal(1), DIMENSIONLESS),
    "m": (Decimal(1), (1,0,0)),
    "cm": (Decimal("0.01"), (1,0,0)),
    "km": (Decimal(1000), (1,0,0)),
    "s": (Decimal(1), (0,1,0)),
    "min": (Decimal(60), (0,1,0)),
    "h": (Decimal(3600), (0,1,0)),
    "kg": (Decimal(1), (0,0,1)),
    "g": (Decimal("0.001"), (0,0,1)),
}
DIGITS = {"ZA":0,"KI":1,"TO":2,"MU":3,"RE":4,"SA":5,"FI":6,"DU":7,"GO":8,"PE":9}

@dataclass(frozen=True)
class Quantity:
    value: Decimal  # normalised to SI base units for this supported dimension set
    dimension: tuple[int,int,int]
    def __str__(self):
        return f"{self.value} [L^{self.dimension[0]} T^{self.dimension[1]} M^{self.dimension[2]}]"

@dataclass(frozen=True)
class Literal:
    quantity: Quantity
    source: str
@dataclass(frozen=True)
class Call:
    op: str
    args: tuple['Expr', ...]
Expr = Literal | Call
ARITY = {"FRAPA":2, "FRATA":2, "FRAKA":2, "FRALA":2}

# Supported provisional literal spellings: 3, 3@m, 25@cm, 2@s, and digit roots.
_NUM_UNIT = re.compile(r"^([+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?)(?:@([A-Za-z0-9]+))?$")

def _dims_add(a,b): return tuple(x+y for x,y in zip(a,b))
def _dims_sub(a,b): return tuple(x-y for x,y in zip(a,b))

def _literal(token: str) -> Literal | None:
    if token in DIGITS:
        return Literal(Quantity(Decimal(DIGITS[token]), DIMENSIONLESS), token)
    match = _NUM_UNIT.fullmatch(token)
    if not match: return None
    raw, unit = match.groups(); unit = unit or "1"
    if unit not in UNITS: raise ArcaneTypeError(f"unknown unit {unit!r}; supported units: {', '.join(UNITS)}")
    try: value = Decimal(raw)
    except InvalidOperation as exc: raise ArcaneParseError(f"invalid numeric literal {token!r}") from exc
    scale, dims = UNITS[unit]
    return Literal(Quantity(value*scale, dims), token)

class _Parser:
    def __init__(self, tokens): self.tokens=tokens; self.i=0
    def expr(self):
        if self.i >= len(self.tokens): raise ArcaneParseError("unexpected end of expression; expected an operand")
        token=self.tokens[self.i]; self.i += 1
        lit=_literal(token)
        if lit is not None: return lit
        if token in ARITY:
            return Call(token, tuple(self.expr() for _ in range(ARITY[token])))
        if token in ("FRASHA", "SIMA", "GAMA", "DAVE", "KWAM", "KWAT", "KWAK"):
            raise ArcaneParseError(f"{token} is not implemented in this arithmetic profile; refusing to guess its semantics")
        raise ArcaneParseError(f"unknown form or malformed literal {token!r}")

def parse(source: str) -> Expr:
    if not isinstance(source,str) or not source.strip(): raise ArcaneParseError("expression must be a non-empty string")
    p=_Parser(source.split()); tree=p.expr()
    if p.i != len(p.tokens): raise ArcaneParseError("extra token(s) after complete expression: "+' '.join(p.tokens[p.i:]))
    return tree

def infer_dimension(expr: Expr) -> tuple[int,int,int]:
    if isinstance(expr, Literal): return expr.quantity.dimension
    a,b=(infer_dimension(x) for x in expr.args)
    if expr.op in ("FRAPA","FRATA"):
        if a != b: raise ArcaneTypeError(f"{expr.op} requires matching dimensions; got {a} and {b}")
        return a
    if expr.op == "FRAKA": return _dims_add(a,b)
    if expr.op == "FRALA": return _dims_sub(a,b)
    raise ArcaneTypeError(f"no type rule for {expr.op}")

def evaluate_expr(expr: Expr) -> Quantity:
    # Type-check the whole expression before performing arithmetic.
    infer_dimension(expr)
    if isinstance(expr, Literal): return expr.quantity
    a,b=(evaluate_expr(x) for x in expr.args)
    if expr.op == "FRAPA": value=a.value+b.value; dims=a.dimension
    elif expr.op == "FRATA": value=a.value-b.value; dims=a.dimension
    elif expr.op == "FRAKA": value=a.value*b.value; dims=_dims_add(a.dimension,b.dimension)
    elif expr.op == "FRALA":
        if b.value == 0: raise ArcaneEvaluationError("FRALA: division by zero")
        value=a.value/b.value; dims=_dims_sub(a.dimension,b.dimension)
    else: raise ArcaneTypeError(f"operator {expr.op} is not implemented")
    return Quantity(value,dims)

def evaluate(source: str) -> Quantity: return evaluate_expr(parse(source))
def format_quantity(q: Quantity) -> str:
    val=format(q.value.normalize(),'f') if q.value else '0'
    l,t,m=q.dimension
    if (l,t,m)==DIMENSIONLESS: unit='1'
    else:
        factors=[]
        for symbol,power in (("m",l),("s",t),("kg",m)):
            if power: factors.append(symbol if power==1 else f"{symbol}^{power}")
        unit=' '.join(factors)
    return f"{val} {unit}"

if __name__ == '__main__':
    import argparse
    cli=argparse.ArgumentParser(description='Arcane provisional dimensional arithmetic core')
    cli.add_argument('expression', nargs='+'); args=cli.parse_args()
    try: print(format_quantity(evaluate(' '.join(args.expression))))
    except ArcaneError as exc: raise SystemExit(f"Arcane error: {exc}")
