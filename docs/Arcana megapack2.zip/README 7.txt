ARCANE PHASE 7F — FUNCTION COMPOSITION

Contents
- arcane_runtime.py: executable provisional subset and parser
- arcane_session.py: interactive command-line session
- test_arcane_runtime.py: regression and feature tests
- example.arc: sample programs (run line-by-line in the session; comments are explanatory)
- PHASE_7F_TEST_OUTPUT.txt: captured automated test output
- ARCANE_PHASE_7F_REPORT.md: implementation notes, limits, and next step
- PHASE_7F_STATUS.csv: compact delivery status

Run
  python -m unittest -v
  python arcane_session.py

Language examples
  KWAF increment(x) => FRAPA $x 1
  KWAF double(x) => FRAKA $x 2
  double(increment(3))
  FRAPA increment(4) double(5)

The expression-call form name(expr, ...) is new in Phase 7F. Function calls can now appear wherever an expression is accepted, including inside prefix operations, conditionals, and other function arguments.

This is a provisional implementation subset, not a claim that the entire Arcane language specification is complete or canonical. It supports a small dimensional quantity system and a limited set of prefix operators. See the report for limitations.
