"""Phase 7V integration and safety regressions."""
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from arcane_check import check_source
from arcane_runtime import ArcaneRuntime, Diagnostic

ROOT = Path(__file__).resolve().parent

class Phase7VIntegrationTests(unittest.TestCase):
    def test_checker_and_runtime_share_block_parser(self):
        source = 'KWAM x => 1\nKWAI FRAEQ 1 1 THEN\nKWAT x'
        checked = check_source(source)
        executed = ArcaneRuntime().run_program(source)
        self.assertFalse(checked.ok)
        self.assertIsInstance(executed, Diagnostic)
        self.assertEqual(checked.issues[0].code, executed.code)

    def test_checker_rejects_malformed_statement_shapes(self):
        for source in ('KWAM x 1', 'KWAF f(x) $x', 'KWAT x(1)'):
            with self.subTest(source=source):
                self.assertFalse(check_source(source).ok)

    def test_recursive_function_hits_guard_not_python_recursion_error(self):
        result = ArcaneRuntime(max_call_depth=4).run_program(
            'KWAF loop(x) => loop($x)\nKWAM y => loop(1)'
        )
        self.assertIsInstance(result, Diagnostic)
        self.assertEqual(result.code, 'ARC-RUN-002')

    def test_runtime_state_resets_between_runs(self):
        runtime = ArcaneRuntime()
        self.assertEqual(runtime.run_program('KWAM x => 3\nKWAT x'), [3])
        self.assertEqual(runtime.run_program('KWAM x => 4\nKWAT x'), [4])

    def test_cli_does_not_execute_semantically_invalid_program(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'bad.arc'
            path.write_text('KWAM x => 1\nKWAT missing\n', encoding='utf-8')
            result = subprocess.run(
                [sys.executable, str(ROOT / 'arcane_cli.py'), '--run', str(path)],
                capture_output=True, text=True, cwd=ROOT
            )
            self.assertEqual(result.returncode, 1)
            self.assertIn('ARC-SEM-005', result.stdout)
            self.assertNotIn('\n1\n', result.stdout)

if __name__ == '__main__':
    unittest.main(verbosity=2)
