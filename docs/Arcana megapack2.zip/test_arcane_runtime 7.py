import unittest
from arcane_runtime import Environment,fmt,ArcaneTypeError,ArcaneBindingError,ArcaneEvaluationError,ArcaneParseError

class LogicTests(unittest.TestCase):
 def setUp(self): self.e=Environment()
 def test_and_true_true(self): self.assertEqual(fmt(self.e.execute('FRAND 1 1')),'1 1')
 def test_and_true_false(self): self.assertEqual(fmt(self.e.execute('FRAND 1 0')),'0 1')
 def test_and_false_true(self): self.assertEqual(fmt(self.e.execute('FRAND 0 1')),'0 1')
 def test_and_false_false(self): self.assertEqual(fmt(self.e.execute('FRAND 0 0')),'0 1')
 def test_or_true_true(self): self.assertEqual(fmt(self.e.execute('FROR 1 1')),'1 1')
 def test_or_true_false(self): self.assertEqual(fmt(self.e.execute('FROR 1 0')),'1 1')
 def test_or_false_true(self): self.assertEqual(fmt(self.e.execute('FROR 0 1')),'1 1')
 def test_or_false_false(self): self.assertEqual(fmt(self.e.execute('FROR 0 0')),'0 1')
 def test_not_true(self): self.assertEqual(fmt(self.e.execute('FRNOT 1')),'0 1')
 def test_not_false(self): self.assertEqual(fmt(self.e.execute('FRNOT 0')),'1 1')
 def test_not_normalizes_nonzero_truth(self): self.assertEqual(fmt(self.e.execute('FRNOT -5')),'0 1')
 def test_and_short_circuits_false_left(self): self.assertEqual(fmt(self.e.execute('FRAND 0 FRALA 1 0')),'0 1')
 def test_or_short_circuits_true_left(self): self.assertEqual(fmt(self.e.execute('FROR 7 FRALA 1 0')),'1 1')
 def test_and_evaluates_right_when_needed(self):
  with self.assertRaises(ArcaneEvaluationError): self.e.execute('FRAND 1 FRALA 1 0')
 def test_or_evaluates_right_when_needed(self):
  with self.assertRaises(ArcaneEvaluationError): self.e.execute('FROR 0 FRALA 1 0')
 def test_and_requires_dimensionless_left(self):
  with self.assertRaises(ArcaneTypeError): self.e.execute('FRAND 1@m 1')
 def test_and_requires_dimensionless_right(self):
  with self.assertRaises(ArcaneTypeError): self.e.execute('FRAND 1 1@s')
 def test_or_requires_dimensionless_left(self):
  with self.assertRaises(ArcaneTypeError): self.e.execute('FROR 1@m 0')
 def test_or_requires_dimensionless_right(self):
  with self.assertRaises(ArcaneTypeError): self.e.execute('FROR 0 1@kg')
 def test_not_requires_dimensionless(self):
  with self.assertRaises(ArcaneTypeError): self.e.execute('FRNOT 2@m')
 def test_comparisons_compose_with_logic(self): self.assertEqual(fmt(self.e.execute('FRAND FRAGT 3 2 FRALT 4 5')),'1 1')
 def test_nested_logic(self): self.assertEqual(fmt(self.e.execute('FROR FRAND 1 0 FRNOT 0')),'1 1')
 def test_logic_inside_conditional(self): self.assertEqual(fmt(self.e.execute('FRASI FRAND FRAGT 3 2 FRALT 1 2 10 20')),'10 1')
 def test_logic_with_function_composition(self):
  self.e.execute('KWAF greater(x,y) => FRAGT $x $y')
  self.assertEqual(fmt(self.e.execute('FRAND greater(8,3) greater(4,1)')),'1 1')
 def test_logic_is_case_insensitive(self): self.assertEqual(fmt(self.e.execute('frand 1 1')),'1 1')
 def test_logic_arity_error(self):
  with self.assertRaises(ArcaneParseError): self.e.execute('FRAND 1')

class FunctionCompositionRegressionTests(unittest.TestCase):
 def setUp(self): self.e=Environment()
 def test_nested_function_calls(self):
  self.e.execute('KWAF increment(x) => FRAPA $x 1');self.e.execute('KWAF double(x) => FRAKA $x 2')
  self.assertEqual(fmt(self.e.execute('double(increment(3))')),'8 1')
 def test_multiple_nested_arguments(self):
  self.e.execute('KWAF add(x,y) => FRAPA $x $y');self.e.execute('KWAF square(x) => FRAKA $x $x')
  self.assertEqual(fmt(self.e.execute('add(square(3), square(4))')),'25 1')
 def test_nested_calls_preserve_dimensions(self):
  self.e.execute('KWAF twice_distance(d) => FRAKA $d 2');self.assertEqual(fmt(self.e.execute('twice_distance(3@m)')),'6 m')
 def test_conditional_is_lazy(self): self.assertEqual(fmt(self.e.execute('FRASI 1 4 $missing')),'4 1')
 def test_dimension_mismatch_is_rejected(self):
  with self.assertRaises(ArcaneTypeError): self.e.execute('FRAGT 1@m 2@s')
 def test_division_by_zero_is_rejected(self):
  with self.assertRaises(ArcaneEvaluationError): self.e.execute('FRALA 1 0')
 def test_unknown_binding_is_rejected(self):
  with self.assertRaises(ArcaneBindingError): self.e.execute('$missing')
 def test_wrong_arity_is_rejected(self):
  self.e.execute('KWAF ident(x) => $x')
  with self.assertRaises(ArcaneBindingError): self.e.execute('ident(1,2)')
 def test_local_scope_does_not_leak(self):
  self.e.execute('KWAF ident(x) => $x');self.e.execute('ident(5)')
  with self.assertRaises(ArcaneBindingError): self.e.execute('KWAT x')
 def test_conditional_true_branch(self): self.assertEqual(fmt(self.e.execute('FRASI 1 12 20')),'12 1')
 def test_conditional_false_branch(self): self.assertEqual(fmt(self.e.execute('FRASI 0 12 20')),'20 1')

if __name__=='__main__': unittest.main(verbosity=2)
