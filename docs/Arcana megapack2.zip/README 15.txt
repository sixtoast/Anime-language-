ARCANE PHASE 7N — FUNCTIONS AND COMPOSITION

Run the interactive shell:
  python arcane_cli.py

Run tests:
  python -m unittest -v

Examples:
  KWAF square(x) => FRATA $x $x
  square(4)
  KWAF add(x, y) => FRAPA $x $y
  add(4, 5)
  KWAR i FROM 1 TO 3 => square($i)
  KWAS total FROM 1 TO 5 => $total

Features: prefix arithmetic and comparisons, short-circuit logic, dimensional
quantities, bindings, bounded repetition, aggregation, user-defined functions,
local parameter scope, and recursion depth protection.

Important: this is a compact runnable subset. KWAF and the statement/operator
forms are provisional until reconciled with the authoritative grammar and decision
ledger. Python standard library only.
