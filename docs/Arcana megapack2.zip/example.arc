# Forward declarations and nested function calls
KWAM answer => add(square(3), 4)
KWAF add(a, b) => $a + $b
KWAF square(x) => FRATA $x $x
KWAT answer
